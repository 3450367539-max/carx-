import express, { Application } from 'express'
import cors from 'cors'
import compression from 'compression'
import path from 'path'
import fs from 'fs'
import 'express-async-errors'
import { env } from './config/env'
import { errorHandler } from './middleware/errorHandler'
import { httpLogger } from './middleware/logger'
import { systemRouter } from './modules/system'
import { authRouter } from './modules/auth'
import { publicRouter } from './modules/public'
import { memberRouter } from './modules/member'
import { agentRouter } from './modules/agent'
import { adminRouter } from './modules/admin'

export const createApp = (): Application => {
  const app = express()

  // HTTP request logging
  app.use(httpLogger)

  app.use(
    cors({
      origin: env.CORS_ORIGIN === '*' ? '*' : env.CORS_ORIGIN,
      credentials: env.CORS_ORIGIN !== '*',
    })
  )

  // Body parsing and compression
  app.use(express.json())
  app.use(express.urlencoded({ extended: true }))
  app.use(compression())

  // API routes - System & Health
  app.use(env.API_PREFIX, systemRouter)

  // Auth & account (captcha / login / register / me / change-password)
  app.use(`${env.API_PREFIX}/users`, authRouter)

  // Public catalog (display config, announcements, products, points shop, finished profiles)
  app.use(`${env.API_PREFIX}/public`, publicRouter)

  // Authenticated member center (orders, cards, finished accounts, vip, warranty, points)
  app.use(env.API_PREFIX, memberRouter)

  // Agent business center (dashboard, prices, customers, debt, settlements, inject, ...)
  app.use(`${env.API_PREFIX}/agent`, agentRouter)

  // Admin management center (stats, finance, users, agents, orders, products, cards, ...)
  app.use(`${env.API_PREFIX}/admin`, adminRouter)

  // Error handling
  app.use(errorHandler)

  // Production: serve the built frontend as a single process (SPA + API on one port).
  const webDist = path.resolve(__dirname, '../../frontend/dist')
  if (fs.existsSync(webDist)) {
    app.use(express.static(webDist))
    app.get('*', (req, res, next) => {
      if (req.path.startsWith('/api')) return next()
      res.sendFile(path.join(webDist, 'index.html'))
    })
  }

  return app
}
