import fs from 'fs'
import path from 'path'
import { hashPassword } from './auth/password'

// ---------------------------------------------------------------------------
// Domain models — CarX 游戏账号 / 代刷 / 授权交易 SaaS（对齐真实接口字段）
// ---------------------------------------------------------------------------

export type UserRole = 'user' | 'agent' | 'admin'
export type UserStatus = 'active' | 'disabled' | 'banned'

// VIP 备份点（真实字段：backup_type/status/size_bytes/is_latest）
export interface VipBackup {
  id: number
  created_at: string
  backup_type: 'auto' | 'manual'
  backup_type_label: string
  status: 'AVAILABLE' | 'EXPIRED'
  status_label: string
  note: string
  is_latest: boolean
  size_bytes: number
}

export interface User {
  id: number
  username: string
  email: string
  passwordHash: string
  carx_email: string
  carx_password: string
  role: UserRole
  status: UserStatus
  credit_score: number
  single_car_points: number
  has_carx_bound: boolean
  agent_code: string
  amount_owed: number
  vip_expires_at: string | null
  vip_backups: VipBackup[]
  createdAt: string
}

export interface Product {
  id: number
  name: string
  description: string
  icon: string | null
  color: string | null
  is_combo: boolean
  delivery_label: string
  base_price: number
  warranty_days: number
  is_active: boolean
  points_redeem_price: number | null
  grants_vip: boolean
  vip_days: number
  // 代理价格体系
  settlement_cost: number
  allow_white_account_delivery: boolean
  createdAt: string
}

// 订单状态（真实：PENDING 待发货 / COMPLETED 已完成 / 可售后 / 已过期 / REFUNDED）
export type OrderStatus = 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'CANCELLED' | 'REFUNDED'
export type OrderType = 'product_delivery' | 'agent_inject' | 'card_redeem' | 'points_redeem'

export interface Order {
  order_id: number
  display_no: string
  user_id: number
  customer_username: string
  product_name: string
  amount: number
  selling_price: number
  status: OrderStatus
  order_type: OrderType
  order_type_label: string
  source_type: 'user' | 'agent'
  delivery_mode: string
  agent_code: string
  created_at: string
  warranty_expires_at: string | null
  is_expired: boolean
}

export interface Announcement {
  id: number
  title: string
  content: string
  target_role: 'all' | 'user' | 'agent' | 'admin'
  is_active: boolean
  read_by: number[]
  expires_at: string | null
  createdAt: string
}

// 卡密（CDK）
export interface CardCode {
  id: number
  code: string
  sku_id: number
  batch_id: number
  status: 'UNUSED' | 'REDEEMING' | 'REDEEMED' | 'DISABLED'
  redeemed_by: number | null
  redeemed_at: string | null
}
export interface CardBatch {
  id: number
  batch_name: string
  sku_id: number
  product_id: number
  agent_id: number | null
  quantity: number
  note: string
  created_at: string
}
export interface CardSku {
  id: number
  name: string
  allow_batch_generation: boolean
  redeem_enabled: boolean
  warranty_enabled: boolean
  grants_vip: boolean
  warranty_days: number
  vip_days: number
  points_value: number
  notes: string
  is_active: boolean
}

// 代理商
export interface Agent {
  id: number
  username: string
  passwordHash: string
  promo_code: string
  agent_code: string
  tier: 'standard' | 'sales' | 'senior' | 'aftersales'
  commission_rate: number
  status: 'active' | 'suspended' | 'archived'
  amount_owed: number
  max_debt_limit: number
  max_daily_orders: number
  business_start_date: string
  last_settlement_at: string | null
  createdAt: string
}

// 代理欠款台账
export interface DebtEntry {
  id: number
  agent_code: string
  entry_type: 'order_receivable' | 'settlement' | 'adjustment'
  entry_type_label: string
  amount_delta: number
  balance_after: number
  order_id: number | null
  order_product_name: string
  customer_username: string
  created_at: string
}

// 代理结算记录
export interface Settlement {
  id: number
  agent_code: string
  amount_paid: number
  previous_debt: number
  new_debt: number
  notes: string
  created_at: string
}

// 代理商品价格表
export interface AgentPrice {
  product_id: number
  agent_code: string
  agent_price: number
  has_custom_price: boolean
}

// 代理客户
export interface AgentCustomer {
  id: number
  agent_code: string
  user_id: number
  remark: string
  tags: string[]
}

// 质保/售后理赔
export type WarrantyStatus = 'pending' | 'processing' | 'resolved' | 'rejected'
export interface WarrantyClaim {
  id: number
  user_id: number
  carx_email: string
  order_id: number | null
  claim_type: 'ban_recover' | 'warranty'
  status: WarrantyStatus
  note: string
  new_carx_email: string
  new_carx_password: string
  created_at: string
}

// 成品号
export interface FinishedAccountProfile {
  id: number
  code: string
  name: string
  product_id: number
  email_prefix: string
  email_domain: string
  password_length: number
  warranty_days_default: number
  description: string
  is_active: boolean
}
export interface FinishedAccountOwnership {
  id: number
  user_id: number
  profile_id: number
  code: string
  claimed_at: string
}

// 积分商城
export interface PointsProduct {
  id: number
  product_id: number | null
  name: string
  description: string
  delivery_label: string
  package_summary: string
  category: string
  price: number
  icon: string | null
  color: string | null
  image_url: string | null
}
export interface PointsCar {
  id: number
  car_id: string
  name: string
  model: string
  category: string
  price: number
  image_url: string | null
}

// 客户端授权 CDK
export interface ClientLicenseCode {
  id: number
  code: string
  kind: 'version' | 'feature'
  kind_label: string
  status: 'UNUSED' | 'ACTIVATED' | 'REVOKED' | 'EXPIRED'
  days: number
  activated_by: number | null
  activated_at: string | null
  created_at: string
}

export interface DisplayConfig {
  site_name: string
  slogan: string
  showroom_background_images: string[]
  console_hero_images: string[]
  finished_account_hero_images: string[]
  registration_invite_required: boolean
}

export interface ConfigValues {
  display: DisplayConfig
  points_shop_enabled: boolean
  cards_enabled: boolean
  agent_application_open: boolean
}

interface DB {
  users: User[]
  products: Product[]
  orders: Order[]
  announcements: Announcement[]
  card_skus: CardSku[]
  card_batches: CardBatch[]
  card_codes: CardCode[]
  agents: Agent[]
  agent_prices: AgentPrice[]
  agent_customers: AgentCustomer[]
  debt_ledger: DebtEntry[]
  settlements: Settlement[]
  warranty_claims: WarrantyClaim[]
  finished_profiles: FinishedAccountProfile[]
  finished_ownerships: FinishedAccountOwnership[]
  points_products: PointsProduct[]
  points_cars: PointsCar[]
  client_license_codes: ClientLicenseCode[]
  config: ConfigValues
  inviteCodes: string[]
  _seq: Record<string, number>
}

const DATA_DIR = path.join(process.cwd(), 'data')
const DB_PATH = path.join(DATA_DIR, 'db.json')

let cache: DB | null = null

function daysFromNow(d: number): string {
  const t = new Date()
  t.setDate(t.getDate() + d)
  return t.toISOString().slice(0, 19).replace('T', ' ')
}

function makeBackup(id: number, daysAgo: number, type: 'auto' | 'manual', isLatest: boolean): VipBackup {
  return {
    id,
    created_at: daysFromNow(-daysAgo),
    backup_type: type,
    backup_type_label: type === 'auto' ? '自动备份' : '手动备份',
    status: 'AVAILABLE',
    status_label: '可恢复',
    note: type === 'auto' ? '系统定时备份' : '用户手动备份',
    is_latest: isLatest,
    size_bytes: 531320 - daysAgo * 1200,
  }
}

function seed(): DB {
  const now = new Date().toISOString()
  const agentPw = hashPassword('Zzk1909..')
  const userPw = hashPassword('ikMfuXl7Mxer')

  const users: User[] = [
    {
      id: 1001, username: 'admin', email: 'admin@carx.dev', passwordHash: hashPassword('Admin@2026'),
      carx_email: 'admin@carx.dev', carx_password: '', role: 'admin', status: 'active',
      credit_score: 100, single_car_points: 0, has_carx_bound: false, agent_code: '',
      amount_owed: 0, vip_expires_at: null, vip_backups: [], createdAt: now,
    },
    {
      id: 4776, username: 'lzk323700', email: 'lzk323700@carx.dev', passwordHash: agentPw,
      carx_email: 'lzk323700@carx.dev', carx_password: 'Zzk1909..', role: 'agent', status: 'active',
      credit_score: 100, single_car_points: 0, has_carx_bound: true, agent_code: '柯达',
      amount_owed: 482.07, vip_expires_at: null, vip_backups: [], createdAt: now,
    },
    {
      id: 6183, username: 'ci3mr3kb9x@gmail.com', email: 'ci3mr3kb9x@gmail.com', passwordHash: userPw,
      carx_email: 'ci3mr3kb9x@gmail.com', carx_password: 'ikMfuXl7Mxer', role: 'user', status: 'active',
      credit_score: 100, single_car_points: 1680, has_carx_bound: true, agent_code: '',
      amount_owed: 0, vip_expires_at: daysFromNow(27),
      vip_backups: Array.from({ length: 7 }, (_, i) => makeBackup(189675 - (6 - i), 6 - i, 'auto', i === 6)),
      createdAt: now,
    },
    {
      id: 4004, username: '5jlzplrewz@gmail.com', email: '5jlzplrewz@gmail.com', passwordHash: hashPassword('user123'),
      carx_email: '5jlzplrewz@gmail.com', carx_password: 'user123', role: 'user', status: 'active',
      credit_score: 100, single_car_points: 12, has_carx_bound: true, agent_code: '柯达',
      amount_owed: 0, vip_expires_at: daysFromNow(15), vip_backups: [makeBackup(189100, 1, 'auto', true)], createdAt: now,
    },
    {
      id: 5982, username: 'm13148838508@163.com', email: 'm13148838508@163.com', passwordHash: hashPassword('user123'),
      carx_email: 'm13148838508@163.com', carx_password: 'user123', role: 'user', status: 'active',
      credit_score: 100, single_car_points: 5, has_carx_bound: false, agent_code: '柯达',
      amount_owed: 0, vip_expires_at: null, vip_backups: [], createdAt: now,
    },
  ]

  const products: Product[] = [
    { id: 54, name: '五号套餐', description: '包含：不封号满等级、全付费车、地图、600万银币、2000金币、180天高级会员；不送平台VIP。', icon: 'ph-shopping-bag-open', color: 'rose', is_combo: true, delivery_label: '内购套餐：满级 + 全图 + 全付费车 + 2000 金币 + 6000000 银币 + 高级账号同步', base_price: 145.99, warranty_days: 30, is_active: true, points_redeem_price: null, grants_vip: true, vip_days: 180, settlement_cost: 58.4, allow_white_account_delivery: true, createdAt: now },
    { id: 11, name: '四刷', description: '', icon: null, color: null, is_combo: true, delivery_label: '组合套餐：银币 + 金币 + 满级 + 全图', base_price: 35.0, warranty_days: 30, is_active: true, points_redeem_price: null, grants_vip: false, vip_days: 0, settlement_cost: 14.0, allow_white_account_delivery: true, createdAt: now },
    { id: 13, name: '六刷', description: '', icon: null, color: null, is_combo: true, delivery_label: '组合套餐：银币 + 金币 + 满级 + 全图 + 全付费车 + 隐藏车', base_price: 55.0, warranty_days: 30, is_active: true, points_redeem_price: null, grants_vip: false, vip_days: 0, settlement_cost: 22.0, allow_white_account_delivery: true, createdAt: now },
    { id: 15, name: '八刷', description: '', icon: null, color: null, is_combo: true, delivery_label: '组合套餐：银币 + 金币 + 满级 + 全图 + 全车解锁', base_price: 75.0, warranty_days: 30, is_active: true, points_redeem_price: null, grants_vip: false, vip_days: 0, settlement_cost: 30.0, allow_white_account_delivery: true, createdAt: now },
    { id: 5, name: '全付费车', description: '', icon: 'ph-car', color: 'rose', is_combo: true, delivery_label: '组合套餐：全付费车解锁', base_price: 130.99, warranty_days: 30, is_active: true, points_redeem_price: null, grants_vip: false, vip_days: 0, settlement_cost: 52.4, allow_white_account_delivery: true, createdAt: now },
    { id: 48, name: '金币礼包', description: '2000 金币', icon: 'ph-coins', color: '#ffb020', is_combo: false, delivery_label: '权益同步：2000 金币', base_price: 70, warranty_days: 0, is_active: true, points_redeem_price: 70, grants_vip: false, vip_days: 0, settlement_cost: 28.0, allow_white_account_delivery: false, createdAt: now },
    { id: 49, name: '通行证一键满级', description: '通行证满级', icon: 'ph-gift', color: '#ff6a2b', is_combo: false, delivery_label: '权益同步：通行证满级', base_price: 35, warranty_days: 0, is_active: true, points_redeem_price: 35, grants_vip: false, vip_days: 0, settlement_cost: 14.0, allow_white_account_delivery: false, createdAt: now },
  ]

  const orders: Order[] = [
    { order_id: 11503, display_no: '普通发货-08181300', user_id: 6183, customer_username: 'ci3mr3kb9x@gmail.com', product_name: '五刷', amount: 88, selling_price: 49.9, status: 'COMPLETED', order_type: 'product_delivery', order_type_label: '普通发货', source_type: 'agent', delivery_mode: 'template_delivery', agent_code: '柯达', created_at: daysFromNow(-2), warranty_expires_at: daysFromNow(28), is_expired: false },
    { order_id: 11620, display_no: '普通发货-08202227', user_id: 4004, customer_username: '5jlzplrewz@gmail.com', product_name: '五刷', amount: 88, selling_price: 49.9, status: 'COMPLETED', order_type: 'product_delivery', order_type_label: '普通发货', source_type: 'agent', delivery_mode: 'template_delivery', agent_code: '柯达', created_at: daysFromNow(0), warranty_expires_at: daysFromNow(30), is_expired: false },
    { order_id: 11587, display_no: '普通发货-08201142', user_id: 5982, customer_username: 'm13148838508@163.com', product_name: '四号套餐', amount: 168, selling_price: 130.99, status: 'COMPLETED', order_type: 'product_delivery', order_type_label: '普通发货', source_type: 'agent', delivery_mode: 'template_delivery', agent_code: '柯达', created_at: daysFromNow(0), warranty_expires_at: daysFromNow(30), is_expired: false },
    { order_id: 11510, display_no: '卡密兑换-08190120', user_id: 6183, customer_username: 'ci3mr3kb9x@gmail.com', product_name: '全付费车', amount: 128, selling_price: 128, status: 'COMPLETED', order_type: 'card_redeem', order_type_label: '卡密兑换', source_type: 'user', delivery_mode: 'card_redeem', agent_code: '', created_at: daysFromNow(-1), warranty_expires_at: daysFromNow(29), is_expired: false },
    { order_id: 11522, display_no: '普通发货-08201130', user_id: 6183, customer_username: 'ci3mr3kb9x@gmail.com', product_name: '八刷', amount: 108, selling_price: 108, status: 'PENDING', order_type: 'product_delivery', order_type_label: '普通发货', source_type: 'agent', delivery_mode: 'template_delivery', agent_code: '柯达', created_at: daysFromNow(0), warranty_expires_at: null, is_expired: false },
  ]

  const announcements: Announcement[] = [
    {
      id: 3, title: '封号解封说明',
      content: '1. 千万不要改游戏密码，更改游戏密码等于自动放弃售后。\n\n2. 购买代刷的客户自动赠送售后平台 30 天 VIP（仅第一次购买套餐的账号会免费赠送），登陆时代刷账号登录平台即可。购买成品号的客户使用成品号卡密登录售后平台。\n\n3. 售后平台 VIP 用户每天凌晨 5 点自动备份账户数据，游戏账号被屏蔽点击「封禁恢复」即可解除屏蔽。',
      target_role: 'all', is_active: true, read_by: [], expires_at: null, createdAt: now,
    },
    {
      id: 4, title: '积分商城上新：涂装车专区',
      content: '积分商城新增涂装车专区，使用单车轮点数即可兑换海量涂装车与通行证车，详情见「积分商城」。',
      target_role: 'all', is_active: true, read_by: [], expires_at: null, createdAt: now,
    },
  ]

  const card_skus: CardSku[] = [
    { id: 1, name: '成品号-标准版', allow_batch_generation: true, redeem_enabled: true, warranty_enabled: true, grants_vip: false, warranty_days: 30, vip_days: 0, points_value: 0, notes: '标准成品号卡密', is_active: true },
    { id: 2, name: '客户端CDK-30天', allow_batch_generation: true, redeem_enabled: true, warranty_enabled: false, grants_vip: false, warranty_days: 0, vip_days: 0, points_value: 0, notes: '游戏客户端授权', is_active: true },
  ]
  const card_batches: CardBatch[] = [
    { id: 1, batch_name: '批次-标准成品号-001', sku_id: 1, product_id: 5, agent_id: 4776, quantity: 5, note: '首批', created_at: daysFromNow(-10) },
  ]
  const card_codes: CardCode[] = [
    { id: 1, code: 'CARX-STD-AB12CD', sku_id: 1, batch_id: 1, status: 'UNUSED', redeemed_by: null, redeemed_at: null },
    { id: 2, code: 'CARX-STD-EF34GH', sku_id: 1, batch_id: 1, status: 'UNUSED', redeemed_by: null, redeemed_at: null },
    { id: 3, code: 'CARX-STD-IJ56KL', sku_id: 1, batch_id: 1, status: 'REDEEMED', redeemed_by: 6183, redeemed_at: daysFromNow(-1) },
  ]

  const agents: Agent[] = [
    { id: 4776, username: 'lzk323700', passwordHash: agentPw, promo_code: 'KODA', agent_code: '柯达', tier: 'sales', commission_rate: 0.6, status: 'active', amount_owed: 482.07, max_debt_limit: 500, max_daily_orders: 200, business_start_date: '2026-07-23', last_settlement_at: daysFromNow(-10), createdAt: now },
    { id: 9002, username: 'rushseller', passwordHash: hashPassword('agent123'), promo_code: 'RUSH2024', agent_code: 'RUSH', tier: 'standard', commission_rate: 0.5, status: 'active', amount_owed: 320, max_debt_limit: 1000, max_daily_orders: 150, business_start_date: '2026-06-01', last_settlement_at: null, createdAt: now },
  ]

  const agent_prices: AgentPrice[] = products.map((p) => ({
    product_id: p.id, agent_code: '柯达', agent_price: p.base_price, has_custom_price: true,
  }))

  const agent_customers: AgentCustomer[] = [
    { id: 1, agent_code: '柯达', user_id: 4004, remark: '', tags: [] },
    { id: 2, agent_code: '柯达', user_id: 5982, remark: '', tags: [] },
  ]

  const debt_ledger: DebtEntry[] = [
    { id: 9714, agent_code: '柯达', entry_type: 'order_receivable', entry_type_label: '订单应收', amount_delta: 19.96, balance_after: 482.07, order_id: 11620, order_product_name: '五刷', customer_username: '5jlzplrewz@gmail.com', created_at: daysFromNow(0) },
    { id: 9701, agent_code: '柯达', entry_type: 'order_receivable', entry_type_label: '订单应收', amount_delta: 52.4, balance_after: 462.11, order_id: 11587, order_product_name: '四号套餐', customer_username: 'm13148838508@163.com', created_at: daysFromNow(0) },
  ]

  const settlements: Settlement[] = [
    { id: 839, agent_code: '柯达', amount_paid: 490.65, previous_debt: 490.65, new_debt: 0, notes: 'Admin lpor settled', created_at: daysFromNow(-10) },
    { id: 807, agent_code: '柯达', amount_paid: 481.31, previous_debt: 481.31, new_debt: 0, notes: 'Admin lpor settled', created_at: daysFromNow(-18) },
    { id: 747, agent_code: '柯达', amount_paid: 10.0, previous_debt: 79.47, new_debt: 69.47, notes: 'Admin lpor settled', created_at: daysFromNow(-25) },
  ]

  const warranty_claims: WarrantyClaim[] = [
    { id: 1, user_id: 6183, carx_email: 'ci3mr3kb9x@gmail.com', order_id: 11503, claim_type: 'ban_recover', status: 'resolved', note: '账号被误封，已恢复', new_carx_email: '', new_carx_password: '', created_at: daysFromNow(-3) },
  ]

  const finished_profiles: FinishedAccountProfile[] = [
    { id: 1, code: 'FA-STD-001', name: '满级全图成品号', product_id: 5, email_prefix: 'carx', email_domain: 'mailhub.com', password_length: 12, warranty_days_default: 30, description: '已代刷完成，可直接登录', is_active: true },
    { id: 2, code: 'FA-STD-002', name: '高金币成品号', product_id: 15, email_prefix: 'carx', email_domain: 'mailhub.com', password_length: 12, warranty_days_default: 30, description: '含 2000 金币', is_active: true },
  ]
  const finished_ownerships: FinishedAccountOwnership[] = []

  const points_products: PointsProduct[] = [
    { id: 49, product_id: 49, name: '通行证一键满级', description: '通行证满级', delivery_label: '权益同步：通行证满级', package_summary: '通行证满级', category: '权益同步', price: 35, icon: 'ph-gift', color: '#ff6a2b', image_url: null },
    { id: 48, product_id: 48, name: '金币礼包', description: '2000 金币', delivery_label: '权益同步：2000 金币', package_summary: '2000 金币', category: '内购礼包', price: 70, icon: 'ph-coins', color: '#ffb020', image_url: null },
  ]
  const points_cars: PointsCar[] = [
    { id: 1, car_id: '1', name: 'Z37', model: 'Z37', category: '银币车', price: 2, image_url: 'https://pan.lpor.fun/file/%E6%B6%82%E8%A3%85%E5%BA%93/1%20Z37.webp' },
    { id: 2, car_id: '2', name: 'P64', model: 'P64', category: '金币车', price: 4, image_url: 'https://pan.lpor.fun/file/%E6%B6%82%E8%A3%85%E5%BA%93/2%20P64.webp' },
    { id: 5, car_id: '5', name: 'RX-7', model: 'RX-7', category: '付费车', price: 5, image_url: null },
    { id: 9, car_id: '9', name: 'GT-R', model: 'GT-R', category: '人机车', price: 5, image_url: null },
    { id: 12, car_id: '12', name: '隐藏车 A', model: 'Hidden-A', category: '隐藏车', price: 10, image_url: null },
    { id: 20, car_id: '20', name: '通行证车 S', model: 'Pass-S', category: '通行证车', price: 15, image_url: null },
    { id: 33, car_id: '33', name: '涂装车 X', model: 'Livery-X', category: '涂装车', price: 20, image_url: null },
  ]

  const client_license_codes: ClientLicenseCode[] = [
    { id: 1, code: 'CDK-VER-AA11BB22', kind: 'version', kind_label: '版本卡密', status: 'UNUSED', days: 0, activated_by: null, activated_at: null, created_at: daysFromNow(-5) },
    { id: 2, code: 'CDK-FEAT-CC33DD44', kind: 'feature', kind_label: '功能月卡', status: 'ACTIVATED', days: 30, activated_by: 6183, activated_at: daysFromNow(-2), created_at: daysFromNow(-6) },
    { id: 3, code: 'CDK-FEAT-EE55FF66', kind: 'feature', kind_label: '功能月卡', status: 'UNUSED', days: 30, activated_by: null, activated_at: null, created_at: daysFromNow(-1) },
  ]

  const config: ConfigValues = {
    display: {
      site_name: 'CARX售后中心',
      slogan: '兑换、会员、订单与售后统一管理',
      showroom_background_images: ['assets/img/public-v2/auth-hero.webp'],
      console_hero_images: [],
      finished_account_hero_images: [],
      registration_invite_required: false,
    },
    points_shop_enabled: true,
    cards_enabled: true,
    agent_application_open: true,
  }

  return {
    users, products, orders, announcements, card_skus, card_batches, card_codes,
    agents, agent_prices, agent_customers, debt_ledger, settlements, warranty_claims,
    finished_profiles, finished_ownerships, points_products, points_cars, client_license_codes,
    config,
    inviteCodes: ['CARX2024', 'VIP888', 'TOPAGENT'],
    _seq: { user: 9100, order: 11630, announcement: 5, agent: 9003, warranty: 2, finished_ownership: 1, finished_profile: 3, card_code: 4, card_batch: 2, card_sku: 3, product: 60, points_product: 50, points_car: 40, debt: 9715, settlement: 840, client_license: 4, agent_customer: 3 },
  }
}

function load(): DB {
  if (cache) return cache
  try {
    if (fs.existsSync(DB_PATH)) {
      const parsed = JSON.parse(fs.readFileSync(DB_PATH, 'utf-8')) as DB
      if (!('agent_prices' in parsed) || !('client_license_codes' in parsed)) {
        cache = seed()
        persist()
      } else {
        cache = parsed
      }
    } else {
      cache = seed()
      persist()
    }
  } catch {
    cache = seed()
    persist()
  }
  return cache!
}

function persist(): void {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true })
  fs.writeFileSync(DB_PATH, JSON.stringify(cache, null, 2), 'utf-8')
}

export function nextId(key: string): number {
  const db = load()
  db._seq[key] = (db._seq[key] ?? 0) + 1
  return db._seq[key]
}

export function publicUser(u: User) {
  const { passwordHash, carx_password, ...rest } = u
  return rest
}

export const store = {
  get db(): DB {
    return load()
  },
  save(): void {
    persist()
  },
}
