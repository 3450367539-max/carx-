import { Router, Request, Response, NextFunction } from 'express'
import { z } from 'zod'
import { store, nextId, publicUser, Order, WarrantyClaim, VipBackup } from '../store'
import { requireAuth, AuthRequest } from '../middleware/auth'
import { AppError } from '../middleware/errorHandler'

/** 会员中心接口（对齐真实返回结构）。 */
export const memberRouter: Router = Router()
memberRouter.use(requireAuth)

function uid(req: Request): number {
  return Number((req as AuthRequest).auth!.userId)
}

function getUser(req: Request) {
  const u = store.db.users.find((x) => x.id === uid(req))
  if (!u) throw new AppError(404, '用户不存在')
  return u
}

function decorateOrder(o: Order) {
  const expired = o.warranty_expires_at
    ? new Date(o.warranty_expires_at.replace(' ', 'T')).getTime() < Date.now()
    : false
  return { ...o, is_expired: expired }
}

function vipActive(u: { vip_expires_at: string | null }): boolean {
  return !!u.vip_expires_at && new Date(u.vip_expires_at.replace(' ', 'T')) > new Date()
}

// ================================================================ orders ===
// GET /api/orders/my-orders
memberRouter.get('/orders/my-orders', (req: Request, res: Response) => {
  const list = store.db.orders
    .filter((o) => o.user_id === uid(req))
    .sort((a, b) => (a.created_at < b.created_at ? 1 : -1))
    .map(decorateOrder)
  res.json(list)
})

const createOrderSchema = z.object({
  product_id: z.number().int(),
  delivery_mode: z.string().optional().default('template_delivery'),
})

// POST /api/orders  — 购买代刷套餐
memberRouter.post('/orders', (req: Request, res: Response, next: NextFunction) => {
  try {
    const body = createOrderSchema.parse(req.body)
    const product = store.db.products.find((p) => p.id === body.product_id && p.is_active)
    if (!product) throw new AppError(404, '商品不存在或已下架')
    const user = getUser(req)
    const now = new Date().toISOString().slice(0, 19).replace('T', ' ')
    const orderId = nextId('order')
    const warrantyUntil = new Date()
    warrantyUntil.setDate(warrantyUntil.getDate() + (product.warranty_days || 0))
    const order: Order = {
      order_id: orderId,
      display_no: `普通发货-${String(orderId).slice(-8)}`,
      user_id: user.id,
      customer_username: user.username,
      product_name: product.name,
      amount: product.base_price,
      selling_price: product.base_price,
      status: 'PENDING',
      order_type: 'product_delivery',
      order_type_label: '普通发货',
      source_type: 'user',
      delivery_mode: body.delivery_mode,
      agent_code: user.agent_code,
      created_at: now,
      warranty_expires_at: product.warranty_days ? warrantyUntil.toISOString().slice(0, 19).replace('T', ' ') : null,
      is_expired: false,
    }
    store.db.orders.push(order)
    if (product.grants_vip && product.vip_days > 0) {
      const base = vipActive(user) ? new Date(user.vip_expires_at!.replace(' ', 'T')) : new Date()
      base.setDate(base.getDate() + product.vip_days)
      user.vip_expires_at = base.toISOString().slice(0, 19).replace('T', ' ')
    }
    store.save()
    res.status(201).json(decorateOrder(order))
  } catch (e) {
    next(e)
  }
})

// ================================================================= cards ===
// GET /api/cards/my-redemptions
memberRouter.get('/cards/my-redemptions', (req: Request, res: Response) => {
  const list = store.db.card_codes
    .filter((c) => c.redeemed_by === uid(req))
    .map((c) => ({ ...c, sku_name: store.db.card_skus.find((s) => s.id === c.sku_id)?.name ?? '卡密' }))
    .sort((a, b) => ((a.redeemed_at ?? '') < (b.redeemed_at ?? '') ? 1 : -1))
  res.json(list)
})

const redeemSchema = z.object({ code: z.string().min(4, '请输入卡密') })

// POST /api/cards/redeem
memberRouter.post('/cards/redeem', (req: Request, res: Response, next: NextFunction) => {
  try {
    if (!store.db.config.cards_enabled) throw new AppError(403, '卡密兑换功能未开启')
    const { code } = redeemSchema.parse(req.body)
    const card = store.db.card_codes.find((c) => c.code.toUpperCase() === code.toUpperCase())
    if (!card) throw new AppError(404, '卡密不存在')
    if (card.status === 'REDEEMED') throw new AppError(400, '该卡密已被兑换')
    if (card.status === 'DISABLED') throw new AppError(400, '该卡密已停用')
    const sku = store.db.card_skus.find((s) => s.id === card.sku_id)
    const user = getUser(req)
    const now = new Date().toISOString().slice(0, 19).replace('T', ' ')
    card.status = 'REDEEMED'
    card.redeemed_by = user.id
    card.redeemed_at = now
    if (sku) {
      if (sku.points_value > 0) user.single_car_points += sku.points_value
      if (sku.grants_vip && sku.vip_days > 0) {
        const base = vipActive(user) ? new Date(user.vip_expires_at!.replace(' ', 'T')) : new Date()
        base.setDate(base.getDate() + sku.vip_days)
        user.vip_expires_at = base.toISOString().slice(0, 19).replace('T', ' ')
      }
    }
    store.save()
    res.json({ success: true, sku_name: sku?.name ?? '卡密', redeemed_at: now, user: publicUser(user) })
  } catch (e) {
    next(e)
  }
})

// ====================================================== finished accounts ===
// GET /api/finished-accounts/my  — { ownerships, claims }
memberRouter.get('/finished-accounts/my', (req: Request, res: Response) => {
  const ownerships = store.db.finished_ownerships
    .filter((o) => o.user_id === uid(req))
    .map((o) => ({ ...o, profile: store.db.finished_profiles.find((p) => p.id === o.profile_id) }))
    .sort((a, b) => (a.claimed_at < b.claimed_at ? 1 : -1))
  const claims = store.db.warranty_claims.filter((c) => c.user_id === uid(req))
  res.json({ ownerships, claims })
})

const claimSchema = z.object({ code: z.string().min(4, '请输入成品号卡密') })

// POST /api/finished-accounts/claim
memberRouter.post('/finished-accounts/claim', (req: Request, res: Response, next: NextFunction) => {
  try {
    const { code } = claimSchema.parse(req.body)
    const profile = store.db.finished_profiles.find((p) => p.code.toUpperCase() === code.toUpperCase() && p.is_active)
    if (!profile) throw new AppError(404, '成品号卡密无效')
    if (store.db.finished_ownerships.some((o) => o.profile_id === profile.id)) throw new AppError(400, '该成品号已被领取')
    const ownership = {
      id: nextId('finished_ownership'),
      user_id: uid(req),
      profile_id: profile.id,
      code: profile.code,
      claimed_at: new Date().toISOString().slice(0, 19).replace('T', ' '),
    }
    store.db.finished_ownerships.push(ownership)
    store.save()
    res.status(201).json({ ...ownership, profile })
  } catch (e) {
    next(e)
  }
})

// ================================================================== VIP ====
// GET /api/vip/status — { is_vip, days_remaining, expires_at, has_backup, last_backup, latest_backup_id, backup_count, backup_limit }
memberRouter.get('/vip/status', (req: Request, res: Response) => {
  const user = getUser(req)
  const active = vipActive(user)
  const backups = user.vip_backups.slice().sort((a, b) => (a.created_at < b.created_at ? 1 : -1))
  const latest = backups[0]
  let daysRemaining = 0
  if (active && user.vip_expires_at) {
    daysRemaining = Math.max(0, Math.ceil((new Date(user.vip_expires_at.replace(' ', 'T')).getTime() - Date.now()) / 86400000))
  }
  res.json({
    is_vip: active,
    days_remaining: daysRemaining,
    expires_at: user.vip_expires_at,
    has_backup: backups.length > 0,
    last_backup: latest?.created_at ?? null,
    latest_backup_id: latest?.id ?? null,
    backup_count: backups.length,
    backup_limit: 7,
  })
})

// GET /api/vip/backups — { items: [...] }
memberRouter.get('/vip/backups', (req: Request, res: Response) => {
  const user = getUser(req)
  const items = user.vip_backups.slice().sort((a, b) => (a.created_at < b.created_at ? 1 : -1))
  res.json({ items })
})

// POST /api/vip/backup — 立即备份
memberRouter.post('/vip/backup', (req: Request, res: Response, next: NextFunction) => {
  try {
    const user = getUser(req)
    if (!vipActive(user)) throw new AppError(403, '仅 VIP 用户可创建备份')
    const LIMIT = 7
    user.vip_backups.forEach((b) => (b.is_latest = false))
    const backup: VipBackup = {
      id: nextId('backup'),
      created_at: new Date().toISOString().slice(0, 19).replace('T', ' '),
      backup_type: 'manual',
      backup_type_label: '手动备份',
      status: 'AVAILABLE',
      status_label: '可恢复',
      note: '用户手动备份',
      is_latest: true,
      size_bytes: 530000 + Math.floor(Math.random() * 3000),
    }
    user.vip_backups.push(backup)
    user.vip_backups.sort((a, b) => (a.created_at < b.created_at ? 1 : -1))
    if (user.vip_backups.length > LIMIT) {
      user.vip_backups = user.vip_backups.slice(0, LIMIT)
    }
    store.save()
    res.status(201).json(backup)
  } catch (e) {
    next(e)
  }
})

const restoreSchema = z.object({ backup_id: z.number().int().optional() })

// POST /api/vip/restore — 恢复数据
memberRouter.post('/vip/restore', (req: Request, res: Response, next: NextFunction) => {
  try {
    const user = getUser(req)
    if (!vipActive(user)) throw new AppError(403, '仅 VIP 用户可恢复数据')
    const body = restoreSchema.parse(req.body ?? {})
    const backups = user.vip_backups.slice().sort((a, b) => (a.created_at < b.created_at ? 1 : -1))
    const target = body.backup_id ? backups.find((b) => b.id === body.backup_id) : backups[0]
    if (!target) throw new AppError(404, '没有可用备份，请先创建首个备份')
    const claim: WarrantyClaim = {
      id: nextId('warranty'),
      user_id: user.id,
      carx_email: user.carx_email,
      order_id: null,
      claim_type: 'warranty',
      status: 'processing',
      note: `恢复备份 #${target.id}`,
      new_carx_email: '',
      new_carx_password: '',
      created_at: new Date().toISOString().slice(0, 19).replace('T', ' '),
    }
    store.db.warranty_claims.push(claim)
    store.save()
    res.json({ success: true, backup_id: target.id, message: '恢复任务已提交' })
  } catch (e) {
    next(e)
  }
})

// POST /api/vip/ban-recover — 封禁恢复
memberRouter.post('/vip/ban-recover', (req: Request, res: Response, next: NextFunction) => {
  try {
    const user = getUser(req)
    if (!vipActive(user)) throw new AppError(403, '仅 VIP 用户可使用封禁恢复')
    const latest = user.vip_backups.slice().sort((a, b) => (a.created_at < b.created_at ? 1 : -1))[0]
    if (!latest) throw new AppError(404, '没有可用备份，请先创建首个备份')
    const claim: WarrantyClaim = {
      id: nextId('warranty'),
      user_id: user.id,
      carx_email: user.carx_email,
      order_id: null,
      claim_type: 'ban_recover',
      status: 'processing',
      note: `封禁恢复（使用备份 #${latest.id}）`,
      new_carx_email: '',
      new_carx_password: '',
      created_at: new Date().toISOString().slice(0, 19).replace('T', ' '),
    }
    store.db.warranty_claims.push(claim)
    store.save()
    res.status(201).json(claim)
  } catch (e) {
    next(e)
  }
})

// ============================================================= warranty ====
// GET /api/warranty/my-claims
memberRouter.get('/warranty/my-claims', (req: Request, res: Response) => {
  const list = store.db.warranty_claims
    .filter((c) => c.user_id === uid(req))
    .sort((a, b) => (a.created_at < b.created_at ? 1 : -1))
  res.json(list)
})

const warrantySchema = z.object({
  claim_type: z.enum(['ban_recover', 'warranty']),
  order_id: z.number().int().optional(),
  note: z.string().optional().default(''),
  new_carx_email: z.string().optional().default(''),
  new_carx_password: z.string().optional().default(''),
})

// POST /api/warranty/self-claim — 申请售后/理赔
memberRouter.post('/warranty/self-claim', (req: Request, res: Response, next: NextFunction) => {
  try {
    const body = warrantySchema.parse(req.body)
    const user = getUser(req)
    const claim: WarrantyClaim = {
      id: nextId('warranty'),
      user_id: user.id,
      carx_email: user.carx_email,
      order_id: body.order_id ?? null,
      claim_type: body.claim_type,
      status: 'pending',
      note: body.note,
      new_carx_email: body.new_carx_email,
      new_carx_password: body.new_carx_password,
      created_at: new Date().toISOString().slice(0, 19).replace('T', ' '),
    }
    store.db.warranty_claims.push(claim)
    store.save()
    res.status(201).json(claim)
  } catch (e) {
    next(e)
  }
})

// =========================================================== points shop ====
// GET /api/single-car-shop/catalog — { points_balance, price_groups, categories, products }
memberRouter.get('/single-car-shop/catalog', (req: Request, res: Response) => {
  const user = getUser(req)
  const products = store.db.points_products.map((p) => ({ ...p, id: String(p.id), type: 'product', can_afford: user.single_car_points >= p.price }))
  const priceGroups = Array.from(new Set(store.db.points_products.map((p) => p.price))).sort((a, b) => a - b)
  const categories = Array.from(new Set(store.db.points_products.map((p) => p.category)))
  res.json({ points_balance: user.single_car_points, price_groups: priceGroups, categories, products })
})

// GET /api/single-car-shop/car-catalog — { points_balance, categories:[{category,price,count}], cars }
memberRouter.get('/single-car-shop/car-catalog', (req: Request, res: Response) => {
  const user = getUser(req)
  const cars = store.db.points_cars.map((c) => ({ ...c, id: String(c.id), type: 'car', can_afford: user.single_car_points >= c.price }))
  const catMap = new Map<string, { category: string; price: number; count: number }>()
  for (const c of store.db.points_cars) {
    const cur = catMap.get(c.category)
    if (cur) cur.count += 1
    else catMap.set(c.category, { category: c.category, price: c.price, count: 1 })
  }
  res.json({ points_balance: user.single_car_points, categories: Array.from(catMap.values()), cars })
})

const pointsRedeemSchema = z.object({ kind: z.enum(['product', 'car']), id: z.number().int() })

// POST /api/single-car-shop/redeem
memberRouter.post('/single-car-shop/redeem', (req: Request, res: Response, next: NextFunction) => {
  try {
    if (!store.db.config.points_shop_enabled) throw new AppError(403, '积分商城未开启')
    const body = pointsRedeemSchema.parse(req.body)
    const user = getUser(req)
    let name = ''
    let price = 0
    if (body.kind === 'product') {
      const p = store.db.points_products.find((x) => x.id === body.id)
      if (!p) throw new AppError(404, '积分商品不存在')
      name = p.name
      price = p.price
    } else {
      const c = store.db.points_cars.find((x) => x.id === body.id)
      if (!c) throw new AppError(404, '车辆不存在')
      name = c.name
      price = c.price
    }
    if (user.single_car_points < price) throw new AppError(400, '积分不足')
    user.single_car_points -= price
    const now = new Date().toISOString().slice(0, 19).replace('T', ' ')
    const orderId = nextId('order')
    const order: Order = {
      order_id: orderId,
      display_no: `积分兑换-${String(orderId).slice(-8)}`,
      user_id: user.id,
      customer_username: user.username,
      product_name: name,
      amount: 0,
      selling_price: 0,
      status: 'COMPLETED',
      order_type: 'points_redeem',
      order_type_label: '积分兑换',
      source_type: 'user',
      delivery_mode: 'points_redeem',
      agent_code: '',
      created_at: now,
      warranty_expires_at: null,
      is_expired: false,
    }
    store.db.orders.push(order)
    store.save()
    res.json({ success: true, remaining_points: user.single_car_points, order: decorateOrder(order) })
  } catch (e) {
    next(e)
  }
})

// ========================================================= announcements ====
// POST /api/announcements/:id/read — 标记已读
memberRouter.post('/announcements/:id/read', (req: Request, res: Response, next: NextFunction) => {
  try {
    const ann = store.db.announcements.find((a) => a.id === Number(req.params.id))
    if (!ann) throw new AppError(404, '公告不存在')
    const id = uid(req)
    if (!ann.read_by.includes(id)) ann.read_by.push(id)
    store.save()
    res.json({ success: true })
  } catch (e) {
    next(e)
  }
})
