import { Router, Request, Response, NextFunction } from 'express'
import crypto from 'crypto'
import { z } from 'zod'
import { store, nextId, DebtEntry, Order } from '../store'
import { requireAuth, AuthRequest } from '../middleware/auth'
import { AppError } from '../middleware/errorHandler'

/** 代理商经营中心接口（/api/agent/*）。要求 agent 或 admin 角色。 */
export const agentRouter: Router = Router()
agentRouter.use(requireAuth)

function agentCode(req: Request): string {
  const auth = (req as AuthRequest).auth!
  if (auth.role !== 'agent' && auth.role !== 'admin') throw new AppError(403, '仅代理商可访问')
  const user = store.db.users.find((u) => String(u.id) === auth.userId)
  if (!user || !user.agent_code) throw new AppError(403, '当前账号不是代理商')
  return user.agent_code
}

function getAgent(req: Request) {
  const code = agentCode(req)
  const agent = store.db.agents.find((a) => a.agent_code === code)
  if (!agent) throw new AppError(404, '代理商不存在')
  return agent
}

function dateKey(offsetDays: number): string {
  const t = new Date()
  t.setDate(t.getDate() + offsetDays)
  return t.toISOString().slice(0, 10)
}

// =========================================================== dashboard ====
// GET /api/agent/dashboard-stats
agentRouter.get('/dashboard-stats', (req: Request, res: Response) => {
  const agent = getAgent(req)
  const my = store.db.orders.filter((o) => o.agent_code === agent.agent_code)
  const today = dateKey(0)
  const monthPrefix = dateKey(0).slice(0, 7)
  const todayOrders = my.filter((o) => o.created_at.slice(0, 10) === today)
  const monthOrders = my.filter((o) => o.created_at.slice(0, 7) === monthPrefix)

  // 净利 = 售价 - 结算成本
  const profitOf = (o: Order) => {
    const product = store.db.products.find((p) => p.name === o.product_name)
    const cost = product?.settlement_cost ?? 0
    return Math.max(0, o.selling_price - cost)
  }
  const todayNet = todayOrders.filter((o) => o.status === 'COMPLETED').reduce((s, o) => s + profitOf(o), 0)
  const monthNet = monthOrders.filter((o) => o.status === 'COMPLETED').reduce((s, o) => s + profitOf(o), 0)
  const pendingSettlement = todayOrders.filter((o) => o.status === 'COMPLETED').reduce((s, o) => s + (store.db.products.find((p) => p.name === o.product_name)?.settlement_cost ?? 0), 0)

  res.json({
    agent_code: agent.agent_code,
    today_orders_count: todayOrders.length,
    today_net_profit: Number(todayNet.toFixed(2)),
    month_orders_count: monthOrders.length,
    month_net_profit: Number(monthNet.toFixed(2)),
    today_pending_settlement: Number(pendingSettlement.toFixed(2)),
    amount_owed: agent.amount_owed,
    max_debt_limit: agent.max_debt_limit,
    remaining_debt_limit: Number((agent.max_debt_limit - agent.amount_owed).toFixed(2)),
    last_settlement_at: agent.last_settlement_at,
    business_start_date: agent.business_start_date,
    failed_today: 0,
    orders: todayOrders.slice(0, 8).map((o) => ({
      selling_price: o.selling_price,
      order_id: o.order_id,
      customer_username: o.customer_username,
      product_name: o.product_name,
      status: o.status,
      created_at: o.created_at,
    })),
  })
})

// GET /api/agent/sales-trend — 近 7 日
agentRouter.get('/sales-trend', (req: Request, res: Response) => {
  const agent = getAgent(req)
  const my = store.db.orders.filter((o) => o.agent_code === agent.agent_code)
  const days: { date: string; sales: number; orders: number }[] = []
  for (let i = 6; i >= 0; i--) {
    const key = dateKey(-i)
    const dayOrders = my.filter((o) => o.created_at.slice(0, 10) === key)
    days.push({
      date: key.slice(5),
      orders: dayOrders.length,
      sales: Number(dayOrders.filter((o) => o.status === 'COMPLETED').reduce((s, o) => s + o.selling_price, 0).toFixed(2)),
    })
  }
  res.json(days)
})

// GET /api/agent/my-permissions
agentRouter.get('/my-permissions', (_req: Request, res: Response) => {
  res.json({
    bind_carx: false, carx_unban_restore: true, claim: true, client_license: true,
    dashboard: true, extend_warranty: false, grant_vip: false, inject: true,
    inject_single_car: true, reset_password: false, revoke_vip: false, search_orders: true,
    set_remark: true, unbind_carx: false, update_credit: false, view_customers: true,
    view_prices: true, view_settlements: true,
  })
})

// =============================================================== prices ====
// GET /api/agent/prices
agentRouter.get('/prices', (req: Request, res: Response) => {
  const agent = getAgent(req)
  const list = store.db.products.filter((p) => p.is_active).map((p) => {
    const custom = store.db.agent_prices.find((ap) => ap.agent_code === agent.agent_code && ap.product_id === p.id)
    const agentPrice = custom?.agent_price ?? p.base_price
    return {
      product_id: p.id,
      product_name: p.name,
      base_price: p.base_price,
      agent_price: agentPrice,
      settlement_cost: p.settlement_cost,
      income_space: Number((agentPrice - p.settlement_cost).toFixed(2)),
      has_custom_price: custom?.has_custom_price ?? false,
      allow_white_account_delivery: p.allow_white_account_delivery,
    }
  })
  res.json(list)
})

// ============================================================= customers ====
// GET /api/agent/customers
agentRouter.get('/customers', (req: Request, res: Response) => {
  const agent = getAgent(req)
  const links = store.db.agent_customers.filter((c) => c.agent_code === agent.agent_code)
  const items = links.map((link) => {
    const u = store.db.users.find((x) => x.id === link.user_id)
    if (!u) return null
    const orders = store.db.orders.filter((o) => o.user_id === u.id)
    const vip = !!u.vip_expires_at && new Date(u.vip_expires_at.replace(' ', 'T')) > new Date()
    return {
      id: u.id,
      username: u.username,
      role: u.role,
      carx_email: u.carx_email,
      credit_score: u.credit_score,
      is_vip: vip,
      order_count: orders.length,
      total_spent: Number(orders.filter((o) => o.status === 'COMPLETED').reduce((s, o) => s + o.selling_price, 0).toFixed(2)),
      remark: link.remark,
      tags: link.tags,
    }
  }).filter(Boolean)
  res.json({ items })
})

const remarkSchema = z.object({ user_id: z.number().int(), remark: z.string().optional().default(''), tags: z.array(z.string()).optional().default([]) })

// POST /api/agent/customers/remark — 设置客户备注
agentRouter.post('/customers/remark', (req: Request, res: Response, next: NextFunction) => {
  try {
    const agent = getAgent(req)
    const body = remarkSchema.parse(req.body)
    let link = store.db.agent_customers.find((c) => c.agent_code === agent.agent_code && c.user_id === body.user_id)
    if (!link) {
      link = { id: nextId('agent_customer'), agent_code: agent.agent_code, user_id: body.user_id, remark: '', tags: [] }
      store.db.agent_customers.push(link)
    }
    link.remark = body.remark
    link.tags = body.tags
    store.save()
    res.json({ success: true })
  } catch (e) {
    next(e)
  }
})

// ================================================================ orders ====
// GET /api/agent/orders/search
agentRouter.get('/orders/search', (req: Request, res: Response) => {
  const agent = getAgent(req)
  const q = String(req.query.q ?? '').trim().toLowerCase()
  let items = store.db.orders.filter((o) => o.agent_code === agent.agent_code)
  if (q) {
    items = items.filter((o) =>
      o.customer_username.toLowerCase().includes(q) ||
      o.product_name.toLowerCase().includes(q) ||
      String(o.order_id).includes(q),
    )
  }
  items = items.slice().sort((a, b) => (a.created_at < b.created_at ? 1 : -1))
  res.json({
    items: items.map((o) => ({
      order_id: o.order_id,
      customer_username: o.customer_username,
      customer_carx_email: o.customer_username,
      product_name: o.product_name,
      selling_price: o.selling_price,
      status: o.status,
      created_at: o.created_at,
    })),
  })
})

// ================================================================= debt ====
// GET /api/agent/debt-ledger
agentRouter.get('/debt-ledger', (req: Request, res: Response) => {
  const agent = getAgent(req)
  const items = store.db.debt_ledger
    .filter((d) => d.agent_code === agent.agent_code)
    .sort((a, b) => (a.created_at < b.created_at ? 1 : -1))
  res.json({
    summary: { amount_owed: agent.amount_owed, ledger_count: items.length },
    total: items.length,
    page: 1,
    page_size: 50,
    items,
  })
})

// GET /api/agent/settlements
agentRouter.get('/settlements', (req: Request, res: Response) => {
  const agent = getAgent(req)
  const list = store.db.settlements
    .filter((s) => s.agent_code === agent.agent_code)
    .sort((a, b) => (a.created_at < b.created_at ? 1 : -1))
  res.json(list)
})

// ============================================================ car lists ====
// GET /api/agent/single-cars-list
agentRouter.get('/single-cars-list', (_req: Request, res: Response) => {
  res.json(store.db.points_cars.map((c) => ({
    id: String(c.id), file: `${c.car_id}[${c.price}元].json`, price: c.price,
    category: c.category, name: c.name, model: c.model, image_url: c.image_url,
  })))
})

// GET /api/agent/platform-cars-list
agentRouter.get('/platform-cars-list', (_req: Request, res: Response) => {
  res.json([
    { id: 'b19', name: '电机车', price: 15, description: '平台车辆' },
    { id: 'b20', name: '高级通行证车', price: 20, description: '平台车辆' },
  ])
})

// GET /api/agent/card-batches
agentRouter.get('/card-batches', (req: Request, res: Response) => {
  const agent = getAgent(req)
  const user = store.db.users.find((u) => u.agent_code === agent.agent_code)
  const items = store.db.card_batches.filter((b) => b.agent_id === (user?.id ?? -1))
  res.json({ items, total: items.length, page: 1, page_size: 30 })
})

// ================================================================ inject ====
const injectSchema = z.object({
  product_id: z.number().int(),
  customer_carx_email: z.string().email('请输入客户游戏邮箱'),
  selling_price: z.number().optional(),
})

// POST /api/agent/inject — 代理发货/代刷（创建客户订单）
agentRouter.post('/inject', (req: Request, res: Response, next: NextFunction) => {
  try {
    const agent = getAgent(req)
    const body = injectSchema.parse(req.body)
    const product = store.db.products.find((p) => p.id === body.product_id && p.is_active)
    if (!product) throw new AppError(404, '商品不存在')
    const sellingPrice = body.selling_price ?? product.base_price
    // 欠款校验
    if (agent.amount_owed + product.settlement_cost > agent.max_debt_limit) {
      throw new AppError(400, '超出欠款授信额度，请先结算')
    }
    // 找或建客户账号
    let customer = store.db.users.find((u) => u.carx_email === body.customer_carx_email)
    if (!customer) {
      const id = nextId('user')
      customer = {
        id, username: body.customer_carx_email, email: body.customer_carx_email,
        passwordHash: '', carx_email: body.customer_carx_email, carx_password: '',
        role: 'user', status: 'active', credit_score: 100, single_car_points: 0,
        has_carx_bound: true, agent_code: agent.agent_code, amount_owed: 0,
        vip_expires_at: null, vip_backups: [], createdAt: new Date().toISOString(),
      }
      store.db.users.push(customer)
    }
    const now = new Date().toISOString().slice(0, 19).replace('T', ' ')
    const orderId = nextId('order')
    const warrantyUntil = new Date()
    warrantyUntil.setDate(warrantyUntil.getDate() + (product.warranty_days || 0))
    const order: Order = {
      order_id: orderId,
      display_no: `普通发货-${String(orderId).slice(-8)}`,
      user_id: customer.id,
      customer_username: customer.username,
      product_name: product.name,
      amount: product.base_price,
      selling_price: sellingPrice,
      status: 'PENDING',
      order_type: 'agent_inject',
      order_type_label: '普通发货',
      source_type: 'agent',
      delivery_mode: 'template_delivery',
      agent_code: agent.agent_code,
      created_at: now,
      warranty_expires_at: product.warranty_days ? warrantyUntil.toISOString().slice(0, 19).replace('T', ' ') : null,
      is_expired: false,
    }
    store.db.orders.push(order)
    // 记入欠款台账
    agent.amount_owed = Number((agent.amount_owed + product.settlement_cost).toFixed(2))
    const entry: DebtEntry = {
      id: nextId('debt'),
      agent_code: agent.agent_code,
      entry_type: 'order_receivable',
      entry_type_label: '订单应收',
      amount_delta: product.settlement_cost,
      balance_after: agent.amount_owed,
      order_id: orderId,
      order_product_name: product.name,
      customer_username: customer.username,
      created_at: now,
    }
    store.db.debt_ledger.push(entry)
    store.save()
    res.status(201).json({ success: true, order, amount_owed: agent.amount_owed })
  } catch (e) {
    next(e)
  }
})

// POST /api/agent/carx-unban-restore — 解封账号
const unbanSchema = z.object({ carx_email: z.string().email('请输入游戏邮箱') })
agentRouter.post('/carx-unban-restore', (req: Request, res: Response, next: NextFunction) => {
  try {
    agentCode(req)
    const body = unbanSchema.parse(req.body)
    const user = store.db.users.find((u) => u.carx_email === body.carx_email)
    if (!user) throw new AppError(404, '游戏账号不存在')
    const latest = user.vip_backups.slice().sort((a, b) => (a.created_at < b.created_at ? 1 : -1))[0]
    if (!latest) throw new AppError(400, '该账号没有可用备份')
    res.json({ success: true, message: `已使用备份 #${latest.id} 提交解封`, backup_id: latest.id })
  } catch (e) {
    next(e)
  }
})

// 生成卡密批次（代销卡密）
const batchSchema = z.object({ batch_name: z.string().min(1), sku_id: z.number().int(), quantity: z.number().int().min(1).max(500) })
agentRouter.post('/card-batches', (req: Request, res: Response, next: NextFunction) => {
  try {
    const agent = getAgent(req)
    const user = store.db.users.find((u) => u.agent_code === agent.agent_code)
    const body = batchSchema.parse(req.body)
    const sku = store.db.card_skus.find((s) => s.id === body.sku_id)
    if (!sku) throw new AppError(404, '卡密类型不存在')
    const batch = {
      id: nextId('card_batch'),
      batch_name: body.batch_name,
      sku_id: body.sku_id,
      product_id: 0,
      agent_id: user?.id ?? null,
      quantity: body.quantity,
      note: '代理代销批次',
      created_at: new Date().toISOString().slice(0, 19).replace('T', ' '),
    }
    store.db.card_batches.push(batch)
    const codes = []
    for (let i = 0; i < body.quantity; i++) {
      const code = `CARX-${crypto.randomBytes(3).toString('hex').toUpperCase()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`
      const cc = { id: nextId('card_code'), code, sku_id: body.sku_id, batch_id: batch.id, status: 'UNUSED' as const, redeemed_by: null, redeemed_at: null }
      store.db.card_codes.push(cc)
      codes.push(cc)
    }
    store.save()
    res.status(201).json({ batch, codes })
  } catch (e) {
    next(e)
  }
})
