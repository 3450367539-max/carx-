import { Router, Request, Response } from 'express'
import { store } from '../store'

/** Public read-only endpoints (no auth required). */
export const publicRouter: Router = Router()

// GET /api/public/display-config
publicRouter.get('/display-config', (_req: Request, res: Response) => {
  const d = store.db.config.display
  res.json({
    site_name: d.site_name,
    slogan: d.slogan,
    showroom_background_images: d.showroom_background_images,
    console_hero_images: d.console_hero_images,
    finished_account_hero_images: d.finished_account_hero_images,
    registration_invite_required: d.registration_invite_required,
  })
})

// GET /api/public/announcements/active
publicRouter.get('/announcements/active', (_req: Request, res: Response) => {
  const now = Date.now()
  const list = store.db.announcements
    .filter((a) => a.is_active && (a.target_role === 'all' || a.target_role === 'user'))
    .filter((a) => !a.expires_at || new Date(a.expires_at).getTime() > now)
    .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1))
  res.json(list)
})

// GET /api/public/products  (active 代刷套餐 catalog)
publicRouter.get('/products', (_req: Request, res: Response) => {
  res.json(store.db.products.filter((p) => p.is_active))
})

// GET /api/public/points-shop/catalog
publicRouter.get('/points-shop/catalog', (_req: Request, res: Response) => {
  if (!store.db.config.points_shop_enabled) {
    res.json([])
    return
  }
  res.json(store.db.points_products)
})

// GET /api/public/points-shop/car-catalog
publicRouter.get('/points-shop/car-catalog', (_req: Request, res: Response) => {
  if (!store.db.config.points_shop_enabled) {
    res.json([])
    return
  }
  res.json(store.db.points_cars)
})

// GET /api/public/finished-accounts/profiles
publicRouter.get('/finished-accounts/profiles', (_req: Request, res: Response) => {
  res.json(store.db.finished_profiles.filter((p) => p.is_active))
})
