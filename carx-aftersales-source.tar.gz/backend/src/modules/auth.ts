import { Router, Request, Response, NextFunction } from 'express'
import crypto from 'crypto'
import { z } from 'zod'
import { store, publicUser, nextId } from '../store'
import { hashPassword, verifyPassword } from '../auth/password'
import { createAuthToken as signToken } from '../auth/token'
import { AppError } from '../middleware/errorHandler'
import { requireAuth, AuthRequest } from '../middleware/auth'

export const authRouter: Router = Router()

const SLIDER_MIN = 96

// GET /users/captcha/challenge
authRouter.get('/captcha/challenge', (_req: Request, res: Response) => {
  const token = crypto.randomBytes(24).toString('hex')
  res.json({ token, expires_in: 300, slider_min: SLIDER_MIN })
})

// POST /users/login  (form or json; accepts the real field names)
authRouter.post('/login', (req: Request, res: Response, next: NextFunction) => {
  try {
    const b = req.body ?? {}
    const username = String(b.username ?? b.carx_email ?? '').trim()
    const password = String(b.password ?? b.carx_password ?? '')
    const captchaValue = Number(b.captcha_value ?? 100)
    if (!username || !password) throw new AppError(400, '请输入账号和密码')
    if (captchaValue < SLIDER_MIN) throw new AppError(400, '请先完成滑块验证')
    const user = store.db.users.find(
      (u) => u.username === username || u.email === username || u.carx_email === username,
    )
    if (!user || !verifyPassword(password, user.passwordHash)) {
      throw new AppError(401, '账号或密码错误')
    }
    if (user.status === 'disabled' || user.status === 'banned') {
      throw new AppError(403, '账号已被禁用')
    }
    const token = signToken(String(user.id), user.role)
    res.json({ token, user: publicUser(user) })
  } catch (e) {
    next(e)
  }
})

// POST /users/admin-login
authRouter.post('/admin-login', (req: Request, res: Response, next: NextFunction) => {
  try {
    const b = req.body ?? {}
    const username = String(b.username ?? '').trim()
    const password = String(b.password ?? '')
    if (!username || !password) throw new AppError(400, '请输入管理员账号和密码')
    const user = store.db.users.find((u) => u.username === username || u.email === username)
    if (!user || !verifyPassword(password, user.passwordHash)) {
      throw new AppError(401, '管理员账号或密码错误')
    }
    // 管理中心入口：允许管理员与代理商登录
    if (user.role !== 'admin' && user.role !== 'agent') {
      throw new AppError(403, '该账号无权进入管理中心')
    }
    if (user.status === 'disabled' || user.status === 'banned') {
      throw new AppError(403, '账号已被禁用')
    }
    const token = signToken(String(user.id), user.role)
    res.json({ token, user: publicUser(user) })
  } catch (e) {
    next(e)
  }
})

const registerSchema = z.object({
  carx_email: z.string().email('邮箱格式不正确'),
  carx_password: z.string().min(6, '密码至少 6 位'),
  invite_code: z.string().optional().default(''),
  captcha_token: z.string().optional(),
  captcha_value: z.number().optional().default(100),
})

// POST /users/register
authRouter.post('/register', (req: Request, res: Response, next: NextFunction) => {
  try {
    const parsed = registerSchema.parse(req.body)
    if (parsed.captcha_value < SLIDER_MIN) throw new AppError(400, '请先完成滑块验证')
    const db = store.db
    if (db.config.display.registration_invite_required && !parsed.invite_code) {
      throw new AppError(400, '需要邀请码')
    }
    if (parsed.invite_code && !db.inviteCodes.includes(parsed.invite_code)) {
      throw new AppError(400, '邀请码无效')
    }
    if (db.users.some((u) => u.email === parsed.carx_email || u.carx_email === parsed.carx_email)) {
      throw new AppError(400, '该邮箱已注册')
    }
    const now = new Date().toISOString()
    const id = nextId('user')
    const user = {
      id,
      username: parsed.carx_email,
      email: parsed.carx_email,
      passwordHash: hashPassword(parsed.carx_password),
      carx_email: parsed.carx_email,
      carx_password: parsed.carx_password,
      role: 'user' as const,
      status: 'active' as const,
      credit_score: 100,
      single_car_points: 0,
      has_carx_bound: true,
      agent_code: '',
      amount_owed: 0,
      vip_expires_at: null,
      vip_backups: [],
      createdAt: now,
    }
    db.users.push(user)
    store.save()
    const token = signToken(String(id), 'user')
    res.json({ token, user: publicUser(user) })
  } catch (e) {
    next(e)
  }
})

// GET /users/me
authRouter.get('/me', requireAuth, (req: Request, res: Response, next: NextFunction) => {
  try {
    const auth = (req as AuthRequest).auth!
    const user = store.db.users.find((u) => String(u.id) === auth.userId)
    if (!user) throw new AppError(404, '用户不存在')
    res.json({ user: publicUser(user) })
  } catch (e) {
    next(e)
  }
})

const changePwSchema = z.object({
  old_password: z.string().min(1),
  new_password: z.string().min(6, '新密码至少 6 位'),
})

// POST /users/change-password
authRouter.post('/change-password', requireAuth, (req: Request, res: Response, next: NextFunction) => {
  try {
    const auth = (req as AuthRequest).auth!
    const parsed = changePwSchema.parse(req.body)
    const user = store.db.users.find((u) => String(u.id) === auth.userId)
    if (!user) throw new AppError(404, '用户不存在')
    if (!verifyPassword(parsed.old_password, user.passwordHash)) {
      throw new AppError(400, '原密码错误')
    }
    user.passwordHash = hashPassword(parsed.new_password)
    store.save()
    res.json({ success: true })
  } catch (e) {
    next(e)
  }
})

// POST /users/logout
authRouter.post('/logout', (_req: Request, res: Response) => {
  res.json({ success: true })
})
