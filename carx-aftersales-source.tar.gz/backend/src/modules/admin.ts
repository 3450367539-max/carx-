import { Router, Request, Response, NextFunction } from 'express'
import { z } from 'zod'
import crypto from 'crypto'
import {
  store, nextId, publicUser, Product, Announcement, CardSku, CardBatch, CardCode,
  Agent, PointsProduct, PointsCar, FinishedAccountProfile, ClientLicenseCode,
} from '../store'
import { hashPassword } from '../auth/password'
import { requireAdmin } from '../middleware/auth'
import { AppError } from '../middleware/errorHandler'

/** 超级管理员接口（/api/admin/*）。 */
export const adminRouter: Router = Router()
adminRouter.use(requireAdmin)

const db = () => store.db
const agentPublic = (a: Agent) => { const { passwordHash, ...rest } = a; return rest }

// ============================================================== overview ===
adminRouter.get('/overview-stats', (_req: Request, res: Response) => {
  const d = db()
  const completed = d.orders.filter((o) => o.status === 'COMPLETED')
  const revenue = completed.reduce((s, o) => s + o.selling_price, 0)
  const byStatus: Record<string, number> = {}
  for (const o of d.orders) byStatus[o.status] = (byStatus[o.status] ?? 0) + 1
  const days: { date: string; orders: number; revenue: number }[] = []
  for (let i = 6; i >= 0; i--) {
    const t = new Date(); t.setDate(t.getDate() - i)
    const key = t.toISOString().slice(0, 10)
    const dayOrders = d.orders.filter((o) => o.created_at.slice(0, 10) === key)
    days.push({ date: key.slice(5), orders: dayOrders.length, revenue: Number(dayOrders.filter((o) => o.status === 'COMPLETED').reduce((s, o) => s + o.selling_price, 0).toFixed(2)) })
  }
  res.json({
    totalUsers: d.users.filter((u) => u.role === 'user').length,
    totalAgents: d.agents.length,
    totalOrders: d.orders.length,
    totalProducts: d.products.length,
    revenue: Number(revenue.toFixed(2)),
    ordersByStatus: byStatus,
    activeCards: d.card_codes.filter((c) => c.status === 'UNUSED').length,
    redeemedCards: d.card_codes.filter((c) => c.status === 'REDEEMED').length,
    pendingWarranty: d.warranty_claims.filter((c) => c.status === 'pending' || c.status === 'processing').length,
    vipUsers: d.users.filter((u) => u.vip_expires_at && new Date(u.vip_expires_at.replace(' ', 'T')) > new Date()).length,
    totalPointsIssued: d.users.reduce((s, u) => s + u.single_car_points, 0),
    clientLicenses: d.client_license_codes.length,
    trend: days,
    recentOrders: d.orders.slice().sort((a, b) => (a.created_at < b.created_at ? 1 : -1)).slice(0, 8),
  })
})

adminRouter.get('/finance-summary', (_req: Request, res: Response) => {
  const d = db()
  const completed = d.orders.filter((o) => o.status === 'COMPLETED')
  const gross = completed.reduce((s, o) => s + o.selling_price, 0)
  const cost = completed.reduce((s, o) => s + (d.products.find((p) => p.name === o.product_name)?.settlement_cost ?? 0), 0)
  const byProduct: Record<string, { count: number; amount: number }> = {}
  for (const o of completed) {
    byProduct[o.product_name] = byProduct[o.product_name] ?? { count: 0, amount: 0 }
    byProduct[o.product_name].count += 1
    byProduct[o.product_name].amount += o.selling_price
  }
  res.json({
    grossRevenue: Number(gross.toFixed(2)),
    totalCost: Number(cost.toFixed(2)),
    netIncome: Number((gross - cost).toFixed(2)),
    totalCompletedOrders: completed.length,
    totalOwed: Number(d.agents.reduce((s, a) => s + a.amount_owed, 0).toFixed(2)),
    byProduct: Object.entries(byProduct).map(([label, v]) => ({ label, count: v.count, amount: Number(v.amount.toFixed(2)) })).sort((a, b) => b.amount - a.amount),
    agentSettlement: d.agents.map((a) => ({ id: a.id, agent_code: a.agent_code, username: a.username, commission_rate: a.commission_rate, amount_owed: a.amount_owed, max_debt_limit: a.max_debt_limit })),
  })
})

// ================================================================ users ===
adminRouter.get('/users', (_req: Request, res: Response) => res.json(db().users.map(publicUser)))

const userCreateSchema = z.object({ username: z.string().min(2), email: z.string().email(), password: z.string().min(6), role: z.enum(['user', 'agent', 'admin']).optional().default('user') })
adminRouter.post('/users', (req: Request, res: Response, next: NextFunction) => {
  try {
    const body = userCreateSchema.parse(req.body)
    if (db().users.some((u) => u.email === body.email)) throw new AppError(400, '该邮箱已存在')
    const user = {
      id: nextId('user'), username: body.username, email: body.email, passwordHash: hashPassword(body.password),
      carx_email: body.email, carx_password: body.password, role: body.role, status: 'active' as const,
      credit_score: 100, single_car_points: 0, has_carx_bound: false, agent_code: '', amount_owed: 0,
      vip_expires_at: null, vip_backups: [], createdAt: new Date().toISOString(),
    }
    db().users.push(user); store.save(); res.status(201).json(publicUser(user))
  } catch (e) { next(e) }
})

const userUpdateSchema = z.object({
  username: z.string().min(2).optional(), password: z.string().min(6).optional(),
  role: z.enum(['user', 'agent', 'admin']).optional(), status: z.enum(['active', 'disabled', 'banned']).optional(),
  credit_score: z.number().optional(), single_car_points: z.number().optional(),
  amount_owed: z.number().optional(), vip_expires_at: z.string().nullable().optional(),
})
adminRouter.put('/users/:id', (req: Request, res: Response, next: NextFunction) => {
  try {
    const user = db().users.find((u) => u.id === Number(req.params.id))
    if (!user) throw new AppError(404, '用户不存在')
    const body = userUpdateSchema.parse(req.body)
    if (body.username !== undefined) user.username = body.username
    if (body.role !== undefined) user.role = body.role
    if (body.status !== undefined) user.status = body.status
    if (body.credit_score !== undefined) user.credit_score = body.credit_score
    if (body.single_car_points !== undefined) user.single_car_points = body.single_car_points
    if (body.amount_owed !== undefined) user.amount_owed = body.amount_owed
    if (body.vip_expires_at !== undefined) user.vip_expires_at = body.vip_expires_at
    if (body.password) user.passwordHash = hashPassword(body.password)
    store.save(); res.json(publicUser(user))
  } catch (e) { next(e) }
})
adminRouter.delete('/users/:id', (req: Request, res: Response, next: NextFunction) => {
  try {
    const idx = db().users.findIndex((u) => u.id === Number(req.params.id))
    if (idx === -1) throw new AppError(404, '用户不存在')
    db().users.splice(idx, 1); store.save(); res.json({ success: true })
  } catch (e) { next(e) }
})

// ================================================================ agents ===
adminRouter.get('/agents', (_req: Request, res: Response) => res.json(db().agents.map(agentPublic)))

const agentSchema = z.object({
  username: z.string().min(2), password: z.string().min(6).optional(), promo_code: z.string().optional(),
  agent_code: z.string().optional(), tier: z.enum(['standard', 'sales', 'senior', 'aftersales']).optional(),
  commission_rate: z.number().min(0).max(1).optional(), max_debt_limit: z.number().optional(),
  max_daily_orders: z.number().int().optional(), status: z.enum(['active', 'suspended', 'archived']).optional(),
})
adminRouter.post('/agents', (req: Request, res: Response, next: NextFunction) => {
  try {
    const body = agentSchema.parse(req.body)
    if (!body.password) throw new AppError(400, '请设置代理商密码')
    const agent: Agent = {
      id: nextId('agent'), username: body.username, passwordHash: hashPassword(body.password),
      promo_code: body.promo_code || body.username.toUpperCase(), agent_code: body.agent_code || body.username,
      tier: body.tier ?? 'standard', commission_rate: body.commission_rate ?? 0.5,
      status: body.status ?? 'active', amount_owed: 0, max_debt_limit: body.max_debt_limit ?? 500,
      max_daily_orders: body.max_daily_orders ?? 100, business_start_date: new Date().toISOString().slice(0, 10),
      last_settlement_at: null, createdAt: new Date().toISOString(),
    }
    db().agents.push(agent); store.save(); res.status(201).json(agentPublic(agent))
  } catch (e) { next(e) }
})
adminRouter.put('/agents/:id', (req: Request, res: Response, next: NextFunction) => {
  try {
    const agent = db().agents.find((a) => a.id === Number(req.params.id))
    if (!agent) throw new AppError(404, '代理商不存在')
    const body = agentSchema.partial().parse(req.body)
    if (body.username !== undefined) agent.username = body.username
    if (body.promo_code !== undefined) agent.promo_code = body.promo_code
    if (body.agent_code !== undefined) agent.agent_code = body.agent_code
    if (body.tier !== undefined) agent.tier = body.tier
    if (body.commission_rate !== undefined) agent.commission_rate = body.commission_rate
    if (body.max_debt_limit !== undefined) agent.max_debt_limit = body.max_debt_limit
    if (body.max_daily_orders !== undefined) agent.max_daily_orders = body.max_daily_orders
    if (body.status !== undefined) agent.status = body.status
    if (body.password) agent.passwordHash = hashPassword(body.password)
    store.save(); res.json(agentPublic(agent))
  } catch (e) { next(e) }
})
adminRouter.delete('/agents/:id', (req: Request, res: Response, next: NextFunction) => {
  try {
    const idx = db().agents.findIndex((a) => a.id === Number(req.params.id))
    if (idx === -1) throw new AppError(404, '代理商不存在')
    db().agents.splice(idx, 1); store.save(); res.json({ success: true })
  } catch (e) { next(e) }
})

// ================================================================ orders ===
adminRouter.get('/orders', (_req: Request, res: Response) => {
  res.json(db().orders.slice().sort((a, b) => (a.created_at < b.created_at ? 1 : -1)))
})
const orderUpdateSchema = z.object({ status: z.enum(['PENDING', 'PROCESSING', 'COMPLETED', 'CANCELLED', 'REFUNDED']).optional(), amount: z.number().optional() })
adminRouter.put('/orders/:id', (req: Request, res: Response, next: NextFunction) => {
  try {
    const order = db().orders.find((o) => o.order_id === Number(req.params.id))
    if (!order) throw new AppError(404, '订单不存在')
    const body = orderUpdateSchema.parse(req.body)
    if (body.status !== undefined) order.status = body.status
    if (body.amount !== undefined) order.amount = body.amount
    store.save(); res.json(order)
  } catch (e) { next(e) }
})
adminRouter.delete('/orders/:id', (req: Request, res: Response, next: NextFunction) => {
  try {
    const idx = db().orders.findIndex((o) => o.order_id === Number(req.params.id))
    if (idx === -1) throw new AppError(404, '订单不存在')
    db().orders.splice(idx, 1); store.save(); res.json({ success: true })
  } catch (e) { next(e) }
})

// ============================================================== products ===
const productSchema = z.object({
  name: z.string().min(1), description: z.string().optional().default(''),
  icon: z.string().nullish().default(null), color: z.string().nullish().default(null),
  is_combo: z.boolean().optional().default(false), delivery_label: z.string().optional().default(''),
  base_price: z.number().min(0), warranty_days: z.number().int().min(0).optional().default(0),
  is_active: z.boolean().optional().default(true), points_redeem_price: z.number().nullish().default(null),
  grants_vip: z.boolean().optional().default(false), vip_days: z.number().int().min(0).optional().default(0),
  settlement_cost: z.number().min(0).optional().default(0), allow_white_account_delivery: z.boolean().optional().default(true),
})
adminRouter.get('/products', (_req: Request, res: Response) => res.json(db().products))
adminRouter.post('/products', (req: Request, res: Response, next: NextFunction) => {
  try {
    const body = productSchema.parse(req.body)
    const product: Product = { id: nextId('product'), createdAt: new Date().toISOString(), ...body }
    db().products.push(product); store.save(); res.status(201).json(product)
  } catch (e) { next(e) }
})
adminRouter.put('/products/:id', (req: Request, res: Response, next: NextFunction) => {
  try {
    const product = db().products.find((p) => p.id === Number(req.params.id))
    if (!product) throw new AppError(404, '商品不存在')
    Object.assign(product, productSchema.partial().parse(req.body)); store.save(); res.json(product)
  } catch (e) { next(e) }
})
adminRouter.delete('/products/:id', (req: Request, res: Response, next: NextFunction) => {
  try {
    const idx = db().products.findIndex((p) => p.id === Number(req.params.id))
    if (idx === -1) throw new AppError(404, '商品不存在')
    db().products.splice(idx, 1); store.save(); res.json({ success: true })
  } catch (e) { next(e) }
})

// ================================================================= cards ===
adminRouter.get('/card-skus', (_req: Request, res: Response) => res.json(db().card_skus))
adminRouter.get('/card-batches', (_req: Request, res: Response) => res.json(db().card_batches))
adminRouter.get('/card-codes', (_req: Request, res: Response) => {
  res.json(db().card_codes.map((c) => ({ ...c, sku_name: db().card_skus.find((s) => s.id === c.sku_id)?.name ?? '' })))
})
const skuSchema = z.object({
  name: z.string().min(1), allow_batch_generation: z.boolean().optional().default(true),
  redeem_enabled: z.boolean().optional().default(true), warranty_enabled: z.boolean().optional().default(false),
  grants_vip: z.boolean().optional().default(false), warranty_days: z.number().int().min(0).optional().default(0),
  vip_days: z.number().int().min(0).optional().default(0), points_value: z.number().int().min(0).optional().default(0),
  notes: z.string().optional().default(''), is_active: z.boolean().optional().default(true),
})
adminRouter.post('/card-skus', (req: Request, res: Response, next: NextFunction) => {
  try { const sku: CardSku = { id: nextId('card_sku'), ...skuSchema.parse(req.body) }; db().card_skus.push(sku); store.save(); res.status(201).json(sku) } catch (e) { next(e) }
})
adminRouter.put('/card-skus/:id', (req: Request, res: Response, next: NextFunction) => {
  try { const sku = db().card_skus.find((s) => s.id === Number(req.params.id)); if (!sku) throw new AppError(404, '卡密类型不存在'); Object.assign(sku, skuSchema.partial().parse(req.body)); store.save(); res.json(sku) } catch (e) { next(e) }
})
adminRouter.delete('/card-skus/:id', (req: Request, res: Response, next: NextFunction) => {
  try { const idx = db().card_skus.findIndex((s) => s.id === Number(req.params.id)); if (idx === -1) throw new AppError(404, '卡密类型不存在'); db().card_skus.splice(idx, 1); store.save(); res.json({ success: true }) } catch (e) { next(e) }
})
const batchSchema = z.object({ batch_name: z.string().min(1), sku_id: z.number().int(), product_id: z.number().int().optional().default(0), quantity: z.number().int().min(1).max(1000), note: z.string().optional().default('') })
adminRouter.post('/card-batches', (req: Request, res: Response, next: NextFunction) => {
  try {
    const body = batchSchema.parse(req.body)
    if (!db().card_skus.some((s) => s.id === body.sku_id)) throw new AppError(404, '卡密类型不存在')
    const batch: CardBatch = { id: nextId('card_batch'), batch_name: body.batch_name, sku_id: body.sku_id, product_id: body.product_id, agent_id: null, quantity: body.quantity, note: body.note, created_at: new Date().toISOString().slice(0, 19).replace('T', ' ') }
    db().card_batches.push(batch)
    const codes: CardCode[] = []
    for (let i = 0; i < body.quantity; i++) {
      const code = `CARX-${crypto.randomBytes(3).toString('hex').toUpperCase()}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`
      const cc: CardCode = { id: nextId('card_code'), code, sku_id: body.sku_id, batch_id: batch.id, status: 'UNUSED', redeemed_by: null, redeemed_at: null }
      db().card_codes.push(cc); codes.push(cc)
    }
    store.save(); res.status(201).json({ batch, codes })
  } catch (e) { next(e) }
})
adminRouter.put('/card-codes/:id', (req: Request, res: Response, next: NextFunction) => {
  try { const code = db().card_codes.find((c) => c.id === Number(req.params.id)); if (!code) throw new AppError(404, '卡密不存在'); const body = z.object({ status: z.enum(['UNUSED', 'REDEEMING', 'REDEEMED', 'DISABLED']) }).parse(req.body); code.status = body.status; store.save(); res.json(code) } catch (e) { next(e) }
})
adminRouter.delete('/card-codes/:id', (req: Request, res: Response, next: NextFunction) => {
  try { const idx = db().card_codes.findIndex((c) => c.id === Number(req.params.id)); if (idx === -1) throw new AppError(404, '卡密不存在'); db().card_codes.splice(idx, 1); store.save(); res.json({ success: true }) } catch (e) { next(e) }
})

// ============================================================= warranty ====
adminRouter.get('/warranty', (_req: Request, res: Response) => {
  res.json(db().warranty_claims.slice().sort((a, b) => (a.created_at < b.created_at ? 1 : -1)))
})
adminRouter.put('/warranty/:id', (req: Request, res: Response, next: NextFunction) => {
  try {
    const claim = db().warranty_claims.find((c) => c.id === Number(req.params.id))
    if (!claim) throw new AppError(404, '工单不存在')
    const body = z.object({ status: z.enum(['pending', 'processing', 'resolved', 'rejected']), note: z.string().optional() }).parse(req.body)
    claim.status = body.status; if (body.note !== undefined) claim.note = body.note
    store.save(); res.json(claim)
  } catch (e) { next(e) }
})

// ========================================================= announcements ====
adminRouter.get('/announcements', (_req: Request, res: Response) => res.json(db().announcements))
const annSchema = z.object({ title: z.string().min(1), content: z.string().optional().default(''), target_role: z.enum(['all', 'user', 'agent', 'admin']).optional().default('all'), is_active: z.boolean().optional().default(true), expires_at: z.string().nullish().default(null) })
adminRouter.post('/announcements', (req: Request, res: Response, next: NextFunction) => {
  try { const ann: Announcement = { id: nextId('announcement'), read_by: [], createdAt: new Date().toISOString(), ...annSchema.parse(req.body) }; db().announcements.push(ann); store.save(); res.status(201).json(ann) } catch (e) { next(e) }
})
adminRouter.put('/announcements/:id', (req: Request, res: Response, next: NextFunction) => {
  try { const ann = db().announcements.find((a) => a.id === Number(req.params.id)); if (!ann) throw new AppError(404, '公告不存在'); Object.assign(ann, annSchema.partial().parse(req.body)); store.save(); res.json(ann) } catch (e) { next(e) }
})
adminRouter.delete('/announcements/:id', (req: Request, res: Response, next: NextFunction) => {
  try { const idx = db().announcements.findIndex((a) => a.id === Number(req.params.id)); if (idx === -1) throw new AppError(404, '公告不存在'); db().announcements.splice(idx, 1); store.save(); res.json({ success: true }) } catch (e) { next(e) }
})

// ============================================================ points shop ===
adminRouter.get('/points-products', (_req: Request, res: Response) => res.json(db().points_products))
adminRouter.get('/points-cars', (_req: Request, res: Response) => res.json(db().points_cars))
const pointsProductSchema = z.object({ name: z.string().min(1), description: z.string().optional().default(''), delivery_label: z.string().optional().default(''), package_summary: z.string().optional().default(''), category: z.string().optional().default('权益同步'), price: z.number().int().min(0), icon: z.string().nullish().default(null), color: z.string().nullish().default(null), image_url: z.string().nullish().default(null) })
adminRouter.post('/points-products', (req: Request, res: Response, next: NextFunction) => {
  try { const p: PointsProduct = { id: nextId('points_product'), product_id: null, ...pointsProductSchema.parse(req.body) }; db().points_products.push(p); store.save(); res.status(201).json(p) } catch (e) { next(e) }
})
adminRouter.put('/points-products/:id', (req: Request, res: Response, next: NextFunction) => {
  try { const p = db().points_products.find((x) => x.id === Number(req.params.id)); if (!p) throw new AppError(404, '积分商品不存在'); Object.assign(p, pointsProductSchema.partial().parse(req.body)); store.save(); res.json(p) } catch (e) { next(e) }
})
adminRouter.delete('/points-products/:id', (req: Request, res: Response, next: NextFunction) => {
  try { const idx = db().points_products.findIndex((x) => x.id === Number(req.params.id)); if (idx === -1) throw new AppError(404, '积分商品不存在'); db().points_products.splice(idx, 1); store.save(); res.json({ success: true }) } catch (e) { next(e) }
})
const pointsCarSchema = z.object({ car_id: z.string().min(1), name: z.string().min(1), model: z.string().optional().default(''), category: z.string().optional().default('银币车'), price: z.number().int().min(0), image_url: z.string().nullish().default(null) })
adminRouter.post('/points-cars', (req: Request, res: Response, next: NextFunction) => {
  try { const c: PointsCar = { id: nextId('points_car'), ...pointsCarSchema.parse(req.body) }; db().points_cars.push(c); store.save(); res.status(201).json(c) } catch (e) { next(e) }
})
adminRouter.put('/points-cars/:id', (req: Request, res: Response, next: NextFunction) => {
  try { const c = db().points_cars.find((x) => x.id === Number(req.params.id)); if (!c) throw new AppError(404, '车辆不存在'); Object.assign(c, pointsCarSchema.partial().parse(req.body)); store.save(); res.json(c) } catch (e) { next(e) }
})
adminRouter.delete('/points-cars/:id', (req: Request, res: Response, next: NextFunction) => {
  try { const idx = db().points_cars.findIndex((x) => x.id === Number(req.params.id)); if (idx === -1) throw new AppError(404, '车辆不存在'); db().points_cars.splice(idx, 1); store.save(); res.json({ success: true }) } catch (e) { next(e) }
})

// ===================================================== finished accounts ====
adminRouter.get('/finished-profiles', (_req: Request, res: Response) => res.json(db().finished_profiles))
const finishedSchema = z.object({ code: z.string().min(1), name: z.string().min(1), product_id: z.number().int().optional().default(0), email_prefix: z.string().optional().default('carx'), email_domain: z.string().optional().default('mailhub.com'), password_length: z.number().int().min(6).optional().default(12), warranty_days_default: z.number().int().min(0).optional().default(30), description: z.string().optional().default(''), is_active: z.boolean().optional().default(true) })
adminRouter.post('/finished-profiles', (req: Request, res: Response, next: NextFunction) => {
  try { const p: FinishedAccountProfile = { id: nextId('finished_profile'), ...finishedSchema.parse(req.body) }; db().finished_profiles.push(p); store.save(); res.status(201).json(p) } catch (e) { next(e) }
})
adminRouter.delete('/finished-profiles/:id', (req: Request, res: Response, next: NextFunction) => {
  try { const idx = db().finished_profiles.findIndex((x) => x.id === Number(req.params.id)); if (idx === -1) throw new AppError(404, '成品号不存在'); db().finished_profiles.splice(idx, 1); store.save(); res.json({ success: true }) } catch (e) { next(e) }
})

// ======================================================== client licenses ====
adminRouter.get('/client-license/codes', (_req: Request, res: Response) => res.json(db().client_license_codes))
adminRouter.get('/client-license/overview', (_req: Request, res: Response) => {
  const codes = db().client_license_codes
  res.json({
    total: codes.length,
    version_available: codes.filter((c) => c.kind === 'version' && c.status === 'UNUSED').length,
    version_activated: codes.filter((c) => c.kind === 'version' && c.status === 'ACTIVATED').length,
    feature_available: codes.filter((c) => c.kind === 'feature' && c.status === 'UNUSED').length,
    feature_activated: codes.filter((c) => c.kind === 'feature' && c.status === 'ACTIVATED').length,
  })
})
const licenseSchema = z.object({ kind: z.enum(['version', 'feature']), days: z.number().int().min(0).optional().default(30), quantity: z.number().int().min(1).max(500).optional().default(1) })
adminRouter.post('/client-license/codes/generate', (req: Request, res: Response, next: NextFunction) => {
  try {
    const body = licenseSchema.parse(req.body)
    const codes: ClientLicenseCode[] = []
    for (let i = 0; i < body.quantity; i++) {
      const prefix = body.kind === 'version' ? 'CDK-VER' : 'CDK-FEAT'
      const code = `${prefix}-${crypto.randomBytes(4).toString('hex').toUpperCase()}`
      const cc: ClientLicenseCode = { id: nextId('client_license'), code, kind: body.kind, kind_label: body.kind === 'version' ? '版本卡密' : '功能月卡', status: 'UNUSED', days: body.days, activated_by: null, activated_at: null, created_at: new Date().toISOString().slice(0, 19).replace('T', ' ') }
      db().client_license_codes.push(cc); codes.push(cc)
    }
    store.save(); res.status(201).json({ codes })
  } catch (e) { next(e) }
})
adminRouter.put('/client-license/codes/:id', (req: Request, res: Response, next: NextFunction) => {
  try { const c = db().client_license_codes.find((x) => x.id === Number(req.params.id)); if (!c) throw new AppError(404, 'CDK 不存在'); const body = z.object({ status: z.enum(['UNUSED', 'ACTIVATED', 'REVOKED', 'EXPIRED']) }).parse(req.body); c.status = body.status; store.save(); res.json(c) } catch (e) { next(e) }
})

// ================================================================ config ====
adminRouter.get('/config', (_req: Request, res: Response) => res.json(db().config))
const configSchema = z.object({
  display: z.object({
    site_name: z.string().optional(), slogan: z.string().optional(),
    showroom_background_images: z.array(z.string()).optional(), console_hero_images: z.array(z.string()).optional(),
    finished_account_hero_images: z.array(z.string()).optional(), registration_invite_required: z.boolean().optional(),
  }).optional(),
  points_shop_enabled: z.boolean().optional(), cards_enabled: z.boolean().optional(), agent_application_open: z.boolean().optional(),
})
adminRouter.put('/config', (req: Request, res: Response, next: NextFunction) => {
  try {
    const body = configSchema.parse(req.body)
    const cfg = db().config
    if (body.display) cfg.display = { ...cfg.display, ...body.display }
    if (body.points_shop_enabled !== undefined) cfg.points_shop_enabled = body.points_shop_enabled
    if (body.cards_enabled !== undefined) cfg.cards_enabled = body.cards_enabled
    if (body.agent_application_open !== undefined) cfg.agent_application_open = body.agent_application_open
    store.save(); res.json(cfg)
  } catch (e) { next(e) }
})
