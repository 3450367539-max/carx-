import crypto from 'crypto'

const SECRET = process.env.AUTH_SECRET || 'carx-dev-secret-change-in-production'

export interface TokenPayload {
  sub: string
  role: string
  type?: string
  iat: number
  exp: number
}

function b64url(input: Buffer | string): string {
  return Buffer.from(input)
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '')
}

function sign(payload: Record<string, unknown>, ttlMs: number): string {
  const body = b64url(Buffer.from(JSON.stringify({ ...payload, iat: Date.now(), exp: Date.now() + ttlMs })))
  const sig = b64url(crypto.createHmac('sha256', SECRET).update(body).digest())
  return `${body}.${sig}`
}

export function verifyToken(token: string): TokenPayload | null {
  try {
    const [body, sig] = token.split('.')
    if (!body || !sig) return null
    const expected = b64url(crypto.createHmac('sha256', SECRET).update(body).digest())
    // Constant-time compare
    const a = Buffer.from(sig)
    const b = Buffer.from(expected)
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null
    const payload = JSON.parse(Buffer.from(body, 'base64').toString('utf-8')) as TokenPayload
    if (!payload.exp || payload.exp < Date.now()) return null
    return payload
  } catch {
    return null
  }
}

/** Long-lived session token (7 days) for logged-in users / admins. */
export function createAuthToken(sub: string, role: string): string {
  return sign({ sub, role }, 7 * 24 * 60 * 60 * 1000)
}

/** Short-lived token (10 minutes) issued by the slider captcha challenge. */
export function createCaptchaToken(): string {
  return sign({ type: 'captcha' }, 10 * 60 * 1000)
}
