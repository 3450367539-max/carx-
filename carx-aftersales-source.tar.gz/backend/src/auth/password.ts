import crypto from 'crypto'

/**
 * Hash a plaintext password using scrypt with a random salt.
 * Format: `${salt}:${hash}` (both hex).
 */
export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex')
  const hash = crypto.scryptSync(password, salt, 64).toString('hex')
  return `${salt}:${hash}`
}

/**
 * Verify a plaintext password against a stored `salt:hash` string.
 */
export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(':')
  if (!salt || !hash) return false
  const computed = crypto.scryptSync(password, salt, 64).toString('hex')
  // Constant-time comparison to avoid timing attacks
  const a = Buffer.from(hash, 'hex')
  const b = Buffer.from(computed, 'hex')
  return a.length === b.length && crypto.timingSafeEqual(a, b)
}
