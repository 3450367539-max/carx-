import { Request, Response, NextFunction } from 'express'
import { verifyToken } from '../auth/token'
import { AppError } from './errorHandler'

export interface AuthRequest extends Request {
  auth?: { userId: string; role: string }
}

/**
 * Extract the session token from the request.
 *
 * Some hosting gateways inject/overwrite the standard `Authorization` header,
 * which would clobber the user's real token. To stay robust we also accept a
 * custom `x-auth-token` header, which gateways leave untouched. The custom
 * header takes precedence when present.
 */
function extractToken(req: Request): string | null {
  const custom = req.headers['x-auth-token']
  if (typeof custom === 'string' && custom.trim()) return custom.trim()
  const header = req.headers.authorization
  if (header && header.startsWith('Bearer ')) return header.slice(7)
  return null
}

/** Require a valid session token. Attaches `req.auth` on success. */
export function requireAuth(req: Request, _res: Response, next: NextFunction): void {
  const token = extractToken(req)
  if (!token) {
    return next(new AppError(401, '未登录或登录已失效'))
  }
  const payload = verifyToken(token)
  if (!payload) {
    return next(new AppError(401, '登录已过期，请重新登录'))
  }
  ;(req as AuthRequest).auth = { userId: payload.sub, role: payload.role }
  next()
}

/** Require a valid session token AND admin role. */
export function requireAdmin(req: Request, _res: Response, next: NextFunction): void {
  requireAuth(req, _res, (err?: unknown) => {
    if (err) return next(err)
    if ((req as AuthRequest).auth?.role !== 'admin') {
      return next(new AppError(403, '无权限访问该资源'))
    }
    next()
  })
}
