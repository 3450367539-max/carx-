import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function ConsoleHeader({
  title,
  description,
  actions,
}: {
  title: string;
  description?: string;
  actions?: ReactNode;
}) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-xl font-bold text-[var(--cx-text)]">{title}</h1>
        {description && <p className="mt-1 text-sm text-[var(--cx-muted)]">{description}</p>}
      </div>
      {actions && <div className="flex items-center gap-2">{actions}</div>}
    </div>
  );
}

export function ConsolePanel({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return <div className={cn("console-panel p-5", className)}>{children}</div>;
}

export function ConsoleStat({
  label,
  value,
  hint,
  icon,
  tone = "default",
}: {
  label: string;
  value: ReactNode;
  hint?: string;
  icon?: ReactNode;
  tone?: "default" | "red" | "green" | "amber" | "blue";
}) {
  const toneClass = {
    default: "bg-[var(--cx-panel-soft)] text-[var(--cx-text)]",
    red: "bg-[var(--cx-red)]/12 text-[var(--cx-red)]",
    green: "bg-[var(--cx-green)]/12 text-[var(--cx-green)]",
    amber: "bg-[var(--cx-amber)]/12 text-[var(--cx-amber)]",
    blue: "bg-[var(--cx-blue)]/12 text-[var(--cx-blue)]",
  }[tone];
  return (
    <div className="console-panel flex items-center gap-4 p-4">
      {icon && (
        <div className={cn("flex size-11 shrink-0 items-center justify-center rounded-[10px]", toneClass)}>
          {icon}
        </div>
      )}
      <div className="min-w-0">
        <div className="text-xs text-[var(--cx-muted)]">{label}</div>
        <div className="truncate text-xl font-bold text-[var(--cx-text)]">{value}</div>
        {hint && <div className="truncate text-xs text-[var(--cx-muted)]">{hint}</div>}
      </div>
    </div>
  );
}

export function ConsoleEmpty({
  icon,
  title,
  description,
  action,
}: {
  icon?: ReactNode;
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 rounded-[12px] border border-dashed border-[var(--cx-line)] py-14 text-center">
      {icon && <div className="text-[var(--cx-muted)]">{icon}</div>}
      <div className="text-sm font-medium text-[var(--cx-text)]">{title}</div>
      {description && <div className="max-w-sm text-xs text-[var(--cx-muted)]">{description}</div>}
      {action && <div className="mt-2">{action}</div>}
    </div>
  );
}
