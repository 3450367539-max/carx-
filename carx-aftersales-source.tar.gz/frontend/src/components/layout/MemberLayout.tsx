import { useState } from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { useQueryClient } from "@tanstack/react-query";
import {
  House,
  User,
  GameController,
  ShieldCheck,
  Wallet,
  Receipt,
  Storefront,
  LockKey,
  SignOut,
  List,
  Crown,
} from "phosphor-react";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";

const navItems = [
  { to: "/console", label: "首页概览", icon: House, end: true },
  { to: "/console/account", label: "账号信息", icon: User },
  { to: "/console/game", label: "游戏数据", icon: GameController },
  { to: "/console/backup", label: "数据备份", icon: ShieldCheck },
  { to: "/console/redeem", label: "卡密兑换", icon: Wallet },
  { to: "/console/orders", label: "购买记录", icon: Receipt },
  { to: "/console/points", label: "积分商城", icon: Storefront },
  { to: "/console/security", label: "安全设置", icon: LockKey },
];

function NavContent({ onNavigate }: { onNavigate?: () => void }) {
  const { user } = useAuth();
  return (
    <div className="flex h-full flex-col gap-1 p-4">
      <div className="mb-5 flex items-center gap-2.5 px-2">
        <div className="flex size-9 items-center justify-center rounded-xl bg-[var(--vip-blue)] text-white">
          <ShieldCheck className="size-5" weight="fill" />
        </div>
        <div className="leading-tight">
          <div className="text-sm font-bold text-[var(--vip-text)]">CARX售后中心</div>
          <div className="text-xs text-[var(--vip-muted)]">会员中心</div>
        </div>
      </div>
      <nav className="flex flex-col gap-0.5 overflow-y-auto">
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            onClick={onNavigate}
            className={({ isActive }) =>
              cn(
                "flex items-center gap-3 rounded-[10px] px-3 py-2.5 text-sm font-medium transition-colors",
                isActive
                  ? "bg-[var(--vip-blue)] text-white shadow-sm"
                  : "text-[var(--vip-muted)] hover:bg-[var(--vip-soft)] hover:text-[var(--vip-text)]"
              )
            }
          >
            <item.icon className="size-[18px]" weight="regular" />
            {item.label}
          </NavLink>
        ))}
      </nav>
      <div className="mt-auto rounded-[10px] border border-[var(--vip-line)] bg-[var(--vip-soft)] p-3">
        <div className="text-xs text-[var(--vip-muted)]">当前积分</div>
        <div className="text-lg font-bold text-[var(--vip-text)]">{user?.single_car_points ?? 0}</div>
      </div>
    </div>
  );
}

export function MemberLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);

  const handleLogout = () => {
    logout();
    queryClient.clear();
    navigate("/login");
  };

  const vipActive =
    !!user?.vip_expires_at && new Date(user.vip_expires_at.replace(" ", "T")) > new Date();

  return (
    <div className="member-theme flex min-h-screen">
      {/* 桌面端侧边栏 */}
      <aside className="hidden w-60 shrink-0 border-r border-[var(--vip-line)] bg-[var(--vip-surface)] md:block">
        <NavContent />
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        {/* 顶栏 */}
        <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-[var(--vip-line)] bg-[var(--vip-surface)]/85 px-4 backdrop-blur">
          <div className="flex items-center gap-2">
            <Sheet open={open} onOpenChange={setOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <List className="size-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-60 p-0">
                <NavContent onNavigate={() => setOpen(false)} />
              </SheetContent>
            </Sheet>
            <span className="text-sm font-semibold text-[var(--vip-text)] md:hidden">会员中心</span>
          </div>

          <div className="flex items-center gap-3">
            {vipActive && (
              <span className="hidden items-center gap-1 rounded-full border border-amber-300 bg-amber-50 px-2.5 py-0.5 text-xs font-medium text-amber-600 sm:inline-flex">
                <Crown className="size-3" weight="fill" /> 至臻会员
              </span>
            )}
            {(user?.role === "agent" || user?.role === "admin") && (
              <Button
                variant="ghost"
                size="sm"
                className="hidden text-[var(--vip-blue)] sm:inline-flex"
                onClick={() => navigate("/admin")}
              >
                经营中心
              </Button>
            )}
            <span className="hidden max-w-40 truncate text-sm text-[var(--vip-muted)] sm:inline">
              {user?.username}
            </span>
            <Button variant="ghost" size="icon" onClick={handleLogout} title="退出登录">
              <SignOut className="size-4" />
            </Button>
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
