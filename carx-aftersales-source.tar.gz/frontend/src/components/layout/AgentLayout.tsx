import { useState } from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { useQueryClient } from "@tanstack/react-query";
import {
  SquaresFour,
  UserGear,
  UsersThree,
  Receipt,
  ShieldChevron,
  Stack,
  ArchiveBox,
  MagnifyingGlass,
  Bell,
  Gear,
  RocketLaunch,
  Wallet,
  Users,
  Ticket,
  Tag,
  Car,
  ShieldCheck,
  Package,
  Storefront,
  Handshake,
  SignOut,
  List,
  type Icon,
} from "phosphor-react";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";

interface NavItem {
  to: string;
  label: string;
  icon: Icon;
  end?: boolean;
}
interface NavGroup {
  title: string;
  items: NavItem[];
  adminOnly?: boolean;
}

const navGroups: NavGroup[] = [
  {
    title: "核心管理",
    adminOnly: true,
    items: [
      { to: "/admin", label: "数据总览", icon: SquaresFour, end: true },
      { to: "/admin/users", label: "用户管理", icon: UserGear },
      { to: "/admin/agents", label: "代理管理", icon: UsersThree },
      { to: "/admin/orders", label: "订单管理", icon: Receipt },
      { to: "/admin/products", label: "商品管理", icon: Package },
      { to: "/admin/cards", label: "卡密管理", icon: Ticket },
      { to: "/admin/points", label: "积分商城", icon: Storefront },
      { to: "/admin/warranty", label: "售后理赔", icon: Handshake },
      { to: "/admin/licenses", label: "客户端授权", icon: ShieldChevron },
    ],
  },
  {
    title: "交付配置",
    adminOnly: true,
    items: [{ to: "/admin/delivery", label: "交付中心", icon: Stack }],
  },
  {
    title: "记录与配置",
    adminOnly: true,
    items: [
      { to: "/admin/archives", label: "历史归档", icon: ArchiveBox },
      { to: "/admin/audit-logs", label: "操作日志", icon: MagnifyingGlass },
      { to: "/admin/announcements", label: "消息通知", icon: Bell },
      { to: "/admin/settings", label: "系统配置", icon: Gear },
    ],
  },
  {
    title: "代理经营",
    items: [
      { to: "/admin/biz", label: "经营概览", icon: Wallet },
      { to: "/admin/biz/delivery", label: "发货操作", icon: RocketLaunch },
      { to: "/admin/biz/customers", label: "客户管理", icon: Users },
      { to: "/admin/biz/cards", label: "代销卡密", icon: Ticket },
      { to: "/admin/biz/prices", label: "商品价格表", icon: Tag },
      { to: "/admin/biz/single-car", label: "单车零售专区", icon: Car },
    ],
  },
  {
    title: "运营操作",
    items: [{ to: "/admin/biz/unban", label: "解封账号", icon: ShieldCheck }],
  },
];

function NavContent({ onNavigate }: { onNavigate?: () => void }) {
  const { user } = useAuth();
  return (
    <div className="flex h-full flex-col gap-1 overflow-y-auto p-4">
      <div className="mb-4 flex items-center gap-2.5 px-2">
        <div className="flex size-9 items-center justify-center rounded-xl bg-[var(--cx-red)] text-white">
          <SquaresFour className="size-5" weight="fill" />
        </div>
        <div className="leading-tight">
          <div className="text-sm font-bold text-[var(--cx-text)]">CARX 管理中心</div>
          <div className="text-xs text-[var(--cx-muted)]">
            {user?.role === "agent" ? `代理 · ${user.agent_code}` : "运营管理"}
          </div>
        </div>
      </div>
      {navGroups
        .filter((g) => !g.adminOnly || user?.role === "admin")
        .map((group) => (
        <div key={group.title} className="mb-3">
          <div className="mb-1 px-2 text-[11px] font-semibold uppercase tracking-wider text-[var(--cx-muted)]">
            {group.title}
          </div>
          <nav className="flex flex-col gap-0.5">
            {group.items.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                onClick={onNavigate}
                className={({ isActive }) =>
                  cn(
                    "flex items-center gap-3 rounded-[9px] px-3 py-2 text-sm font-medium transition-colors",
                    isActive
                      ? "bg-[var(--cx-red)] text-white"
                      : "text-[var(--cx-muted)] hover:bg-[var(--cx-panel-soft)] hover:text-[var(--cx-text)]"
                  )
                }
              >
                <item.icon className="size-[17px]" />
                {item.label}
              </NavLink>
            ))}
          </nav>
        </div>
      ))}
    </div>
  );
}

export function AgentLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);

  const handleLogout = () => {
    logout();
    queryClient.clear();
    navigate("/login");
  };

  return (
    <div className="console-theme flex min-h-screen">
      <aside className="hidden w-60 shrink-0 border-r border-[var(--cx-line)] bg-[var(--cx-bg)] md:block">
        <NavContent />
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex h-14 items-center justify-between border-b border-[var(--cx-line)] bg-[var(--cx-bg)]/85 px-4 backdrop-blur">
          <div className="flex items-center gap-2">
            <Sheet open={open} onOpenChange={setOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <List className="size-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-60 border-[var(--cx-line)] bg-[var(--cx-bg)] p-0">
                <NavContent onNavigate={() => setOpen(false)} />
              </SheetContent>
            </Sheet>
            <span className="text-sm font-semibold text-[var(--cx-text)] md:hidden">管理中心</span>
          </div>

          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              className="hidden text-[var(--cx-muted)] hover:text-[var(--cx-text)] sm:inline-flex"
              onClick={() => navigate("/console")}
            >
              会员中心
            </Button>
            <span className="rounded-full border border-[var(--cx-red)]/40 bg-[var(--cx-red)]/10 px-2.5 py-0.5 text-xs font-medium text-[var(--cx-red)]">
              {user?.role === "agent" ? "代理商" : "管理员"}
            </span>
            <span className="hidden max-w-40 truncate text-sm text-[var(--cx-muted)] sm:inline">
              {user?.username}
            </span>
            <Button variant="ghost" size="icon" onClick={handleLogout} title="退出登录" className="text-[var(--cx-muted)]">
              <SignOut className="size-4" />
            </Button>
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
