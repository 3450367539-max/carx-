import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "@/lib/auth";
import type { Role } from "@/lib/api";

function FullScreenLoader() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background">
      <div className="size-8 animate-spin rounded-full border-2 border-muted border-t-theme-red" />
    </div>
  );
}

interface RequireAuthProps {
  /** 允许进入的角色集合 */
  roles: Role[];
  children: React.ReactNode;
}

/** 根据角色返回默认落地页 */
export function homeForRole(role: Role): string {
  return role === "user" ? "/console" : "/admin";
}

export function RequireAuth({ roles, children }: RequireAuthProps) {
  const { user, loading } = useAuth();
  const location = useLocation();
  const hasToken = !!localStorage.getItem("auth_token");

  if (loading) {
    return <FullScreenLoader />;
  }

  if (!hasToken || !user) {
    return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  }

  if (!roles.includes(user.role)) {
    return <Navigate to={homeForRole(user.role)} replace />;
  }

  return <>{children}</>;
}
