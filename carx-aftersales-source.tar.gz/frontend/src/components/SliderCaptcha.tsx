import { useEffect, useRef, useState } from "react";
import { CheckIcon, ChevronsRightIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { getCaptchaChallenge } from "@/lib/api";

interface SliderCaptchaProps {
  /** Called whenever the verification state changes. */
  onChange?: (token: string, passed: boolean) => void;
  disabled?: boolean;
}

const KNOB_SIZE = 40;
const SUCCESS_THRESHOLD = 0.96;

export function SliderCaptcha({ onChange, disabled }: SliderCaptchaProps) {
  const [token, setToken] = useState("");
  const [loadingToken, setLoadingToken] = useState(true);
  const [pos, setPos] = useState(0);
  const [dragging, setDragging] = useState(false);
  const [passed, setPassed] = useState(false);

  const trackRef = useRef<HTMLDivElement>(null);
  const startX = useRef(0);
  const startPos = useRef(0);
  const draggingRef = useRef(false);
  const posRef = useRef(0);

  useEffect(() => {
    let active = true;
    setLoadingToken(true);
    getCaptchaChallenge()
      .then((t) => {
        if (active) setToken(t);
      })
      .catch(() => {
        // ignore — user simply cannot verify until token is available
      })
      .finally(() => {
        if (active) setLoadingToken(false);
      });
    return () => {
      active = false;
    };
  }, []);

  const maxTravel = () => {
    const track = trackRef.current;
    if (!track) return 0;
    return track.clientWidth - KNOB_SIZE;
  };

  const clamp = (v: number, min: number, max: number) =>
    Math.max(min, Math.min(max, v));

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    if (disabled || passed || loadingToken || !token) return;
    draggingRef.current = true;
    setDragging(true);
    startX.current = e.clientX;
    startPos.current = posRef.current;
    e.currentTarget.setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!draggingRef.current) return;
    const next = clamp(
      startPos.current + (e.clientX - startX.current),
      0,
      maxTravel()
    );
    posRef.current = next;
    setPos(next);
  };

  const finishDrag = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!draggingRef.current) return;
    draggingRef.current = false;
    setDragging(false);
    const max = maxTravel();
    const finalPos = clamp(
      startPos.current + (e.clientX - startX.current),
      0,
      max
    );
    if (finalPos >= max * SUCCESS_THRESHOLD) {
      posRef.current = max;
      setPos(max);
      setPassed(true);
      onChange?.(token, true);
    } else {
      posRef.current = 0;
      setPos(0);
      setPassed(false);
      onChange?.(token, false);
    }
  };

  const fillWidth = pos + KNOB_SIZE;

  return (
    <div
      ref={trackRef}
      className="relative h-11 w-full select-none overflow-hidden rounded-full border border-input bg-muted"
      style={{ touchAction: "none" }}
    >
      {/* fill */}
      <div
        className={cn(
          "absolute inset-y-0 left-0 rounded-full",
          passed ? "bg-success/80" : "bg-theme-red/80"
        )}
        style={{ width: fillWidth }}
      />
      {/* label */}
      <div
        className={cn(
          "pointer-events-none absolute inset-0 flex items-center justify-center text-sm font-medium",
          passed ? "text-white" : "text-muted-foreground"
        )}
      >
        {passed
          ? "验证通过"
          : loadingToken
            ? "正在加载验证…"
            : "拖动滑块完成验证"}
      </div>
      {/* knob */}
      <div
        role="slider"
        aria-label="滑块验证"
        aria-valuenow={Math.round((pos / Math.max(1, maxTravel())) * 100)}
        aria-valuemin={0}
        aria-valuemax={100}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={finishDrag}
        onPointerCancel={finishDrag}
        className={cn(
          "absolute top-1/2 left-0 flex size-10 -translate-y-1/2 cursor-grab items-center justify-center rounded-full bg-white shadow-md active:cursor-grabbing",
          !dragging && "transition-[left] duration-200 ease-out"
        )}
        style={{ left: pos }}
      >
        {passed ? (
          <CheckIcon className="size-5 text-success" />
        ) : (
          <ChevronsRightIcon className="size-5 text-theme-red" />
        )}
      </div>
    </div>
  );
}
