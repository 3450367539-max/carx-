import { useQuery } from "@tanstack/react-query";
import { ArchiveBox } from "phosphor-react";
import { getAdminOrders } from "@/lib/api";
import { orderStatusMeta } from "@/lib/status";
import { formatCurrency, formatDateTime } from "@/lib/format";
import { ConsoleHeader, ConsolePanel, ConsoleEmpty } from "@/components/ConsoleKit";
import { Badge } from "@/components/ui/badge";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";

/** 历史归档：已完成 / 已取消 / 已退款的订单归档记录。 */
export default function AdminArchives() {
  const { data: orders, isLoading } = useQuery({ queryKey: ["admin-orders"], queryFn: getAdminOrders });
  const archived = (orders ?? []).filter((o) => o.status === "COMPLETED" || o.status === "CANCELLED" || o.status === "REFUNDED");

  return (
    <div>
      <ConsoleHeader title="历史归档" description="查询已归档任务，并把旧任务移出主任务表" />
      <ConsolePanel className="p-0">
        {isLoading ? (
          <div className="py-16 text-center text-sm text-[var(--cx-muted)]">正在加载...</div>
        ) : archived.length === 0 ? (
          <div className="p-5"><ConsoleEmpty icon={<ArchiveBox className="size-8" />} title="暂无归档记录" /></div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>订单号</TableHead><TableHead>商品</TableHead><TableHead>客户</TableHead>
                <TableHead>金额</TableHead><TableHead>最终状态</TableHead><TableHead>归档时间</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {archived.map((o) => (
                <TableRow key={o.order_id}>
                  <TableCell className="font-mono text-xs text-[var(--cx-muted)]">{o.display_no}</TableCell>
                  <TableCell className="font-medium text-[var(--cx-text)]">{o.product_name}</TableCell>
                  <TableCell className="font-mono text-xs text-[var(--cx-muted)]">{o.customer_username}</TableCell>
                  <TableCell className="text-[var(--cx-text)]">{o.amount > 0 ? formatCurrency(o.amount) : "—"}</TableCell>
                  <TableCell><Badge variant="outline" className={orderStatusMeta[o.status].className}>{orderStatusMeta[o.status].label}</Badge></TableCell>
                  <TableCell className="text-xs text-[var(--cx-muted)]">{formatDateTime(o.created_at)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </ConsolePanel>
    </div>
  );
}
