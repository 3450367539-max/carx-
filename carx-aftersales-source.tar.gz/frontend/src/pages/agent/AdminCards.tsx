import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Ticket, Plus, Trash, Copy, Prohibit } from "phosphor-react";
import {
  getCardSkus, createCardSku, updateCardSku, deleteCardSku,
  getCardBatches, createCardBatch, getCardCodes, updateCardCode, deleteCardCode,
  getErrorMessage, type CardSku, type CardCode, type CardStatus,
} from "@/lib/api";
import { formatDateTime } from "@/lib/format";
import { ConsoleHeader, ConsolePanel, ConsoleStat, ConsoleEmpty } from "@/components/ConsoleKit";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";

const cardStatusMeta: Record<CardStatus, { label: string; cls: string }> = {
  UNUSED: { label: "未使用", cls: "border-emerald-500/30 bg-emerald-500/10 text-emerald-400" },
  REDEEMING: { label: "兑换中", cls: "border-amber-500/30 bg-amber-500/10 text-amber-400" },
  REDEEMED: { label: "已使用", cls: "border-sky-500/30 bg-sky-500/10 text-sky-400" },
  DISABLED: { label: "已禁用", cls: "border-red-500/30 bg-red-500/10 text-red-400" },
};

export default function AdminCards() {
  const queryClient = useQueryClient();
  const { data: skus } = useQuery({ queryKey: ["card-skus"], queryFn: getCardSkus });
  const { data: batches } = useQuery({ queryKey: ["card-batches"], queryFn: getCardBatches });
  const { data: codes } = useQuery({ queryKey: ["card-codes"], queryFn: getCardCodes });

  const [skuDialog, setSkuDialog] = useState(false);
  const [editingSku, setEditingSku] = useState<CardSku | null>(null);
  const [skuForm, setSkuForm] = useState({ name: "", grants_vip: false, vip_days: 0, warranty_days: 30, points_value: 0, notes: "", redeem_enabled: true });

  const [genDialog, setGenDialog] = useState(false);
  const [genForm, setGenForm] = useState({ batch_name: "", sku_id: 0, quantity: 10, note: "" });
  const [generated, setGenerated] = useState<CardCode[] | null>(null);

  const [statusFilter, setStatusFilter] = useState<"all" | CardStatus>("all");

  const refresh = () => {
    queryClient.invalidateQueries({ queryKey: ["card-skus"] });
    queryClient.invalidateQueries({ queryKey: ["card-batches"] });
    queryClient.invalidateQueries({ queryKey: ["card-codes"] });
  };

  const saveSkuMut = useMutation({
    mutationFn: () => editingSku
      ? updateCardSku(editingSku.id, skuForm)
      : createCardSku({ ...skuForm, allow_batch_generation: true, warranty_enabled: skuForm.warranty_days > 0, is_active: true }),
    onSuccess: () => { toast.success(editingSku ? "卡密类型已更新" : "卡密类型已创建"); setSkuDialog(false); setEditingSku(null); refresh(); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const deleteSkuMut = useMutation({
    mutationFn: (id: number) => deleteCardSku(id),
    onSuccess: () => { toast.success("卡密类型已删除"); refresh(); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const genMut = useMutation({
    mutationFn: () => createCardBatch({ batch_name: genForm.batch_name, sku_id: genForm.sku_id, quantity: genForm.quantity, note: genForm.note }),
    onSuccess: (r) => {
      toast.success(`已生成 ${r.codes.length} 张卡密`);
      setGenerated(r.codes); setGenDialog(false); refresh();
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const toggleCodeMut = useMutation({
    mutationFn: (c: CardCode) => updateCardCode(c.id, { status: c.status === "DISABLED" ? "UNUSED" : "DISABLED" }),
    onSuccess: (_, c) => { toast.success(c.status === "DISABLED" ? "卡密已恢复" : "卡密已禁用"); refresh(); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const deleteCodeMut = useMutation({
    mutationFn: (id: number) => deleteCardCode(id),
    onSuccess: () => { toast.success("卡密已删除"); refresh(); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const skuName = (id: number) => skus?.find((s) => s.id === id)?.name ?? `#${id}`;
  const filteredCodes = (codes ?? []).filter((c) => statusFilter === "all" || c.status === statusFilter);
  const unusedCount = (codes ?? []).filter((c) => c.status === "UNUSED").length;

  const copyCodes = (list: CardCode[]) => {
    navigator.clipboard.writeText(list.map((c) => c.code).join("\n")).then(
      () => toast.success(`已复制 ${list.length} 张卡密`),
      () => toast.error("复制失败"),
    );
  };

  return (
    <div>
      <ConsoleHeader title="卡密管理" description="管理卡密类型、批量生成卡密、监控卡密使用状态" />

      <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <ConsoleStat label="卡密类型" value={skus?.length ?? 0} />
        <ConsoleStat label="生成批次" value={batches?.length ?? 0} />
        <ConsoleStat label="卡密总数" value={codes?.length ?? 0} />
        <ConsoleStat label="未使用" value={unusedCount} tone="red" />
      </div>

      <Tabs defaultValue="codes">
        <TabsList className="mb-4">
          <TabsTrigger value="codes">卡密列表</TabsTrigger>
          <TabsTrigger value="skus">卡密类型</TabsTrigger>
          <TabsTrigger value="batches">生成批次</TabsTrigger>
        </TabsList>

        {/* 卡密列表 */}
        <TabsContent value="codes">
          <ConsolePanel>
            <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-sm font-semibold text-[var(--cx-text)]">
                <Ticket className="size-4" /> 全部卡密
              </div>
              <div className="flex items-center gap-2">
                <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as typeof statusFilter)}>
                  <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部状态</SelectItem>
                    <SelectItem value="UNUSED">未使用</SelectItem>
                    <SelectItem value="REDEEMING">兑换中</SelectItem>
                    <SelectItem value="REDEEMED">已使用</SelectItem>
                    <SelectItem value="DISABLED">已禁用</SelectItem>
                  </SelectContent>
                </Select>
                <Button size="sm" onClick={() => { setGenForm({ batch_name: "", sku_id: skus?.[0]?.id ?? 0, quantity: 10, note: "" }); setGenDialog(true); }}>
                  <Plus className="size-4" /> 生成卡密
                </Button>
              </div>
            </div>
            {filteredCodes.length === 0 ? (
              <ConsoleEmpty title="暂无卡密" />
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>卡密</TableHead>
                    <TableHead>类型</TableHead>
                    <TableHead>状态</TableHead>
                    <TableHead>使用人</TableHead>
                    <TableHead>使用时间</TableHead>
                    <TableHead className="text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredCodes.slice(0, 100).map((c) => (
                    <TableRow key={c.id}>
                      <TableCell className="font-mono text-xs">{c.code}</TableCell>
                      <TableCell>{c.sku_name ?? skuName(c.sku_id)}</TableCell>
                      <TableCell><Badge className={cardStatusMeta[c.status].cls}>{cardStatusMeta[c.status].label}</Badge></TableCell>
                      <TableCell className="text-[var(--cx-muted)]">{c.redeemed_by ?? "—"}</TableCell>
                      <TableCell className="text-[var(--cx-muted)]">{c.redeemed_at ? formatDateTime(c.redeemed_at) : "—"}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          <Button size="icon" variant="ghost" title="复制" onClick={() => copyCodes([c])}><Copy className="size-4" /></Button>
                          {c.status !== "REDEEMED" && (
                            <Button size="icon" variant="ghost" title={c.status === "DISABLED" ? "恢复" : "禁用"} onClick={() => toggleCodeMut.mutate(c)}>
                              <Prohibit className="size-4" />
                            </Button>
                          )}
                          <Button size="icon" variant="ghost" title="删除"
                            onClick={() => { if (confirm("确定删除该卡密？")) deleteCodeMut.mutate(c.id); }}>
                            <Trash className="size-4 text-red-400" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
            {filteredCodes.length > 100 && (
              <div className="mt-3 text-center text-xs text-[var(--cx-muted)]">仅显示前 100 条，共 {filteredCodes.length} 条</div>
            )}
          </ConsolePanel>
        </TabsContent>

        {/* 卡密类型 */}
        <TabsContent value="skus">
          <ConsolePanel>
            <div className="mb-4 flex items-center justify-between">
              <div className="text-sm font-semibold text-[var(--cx-text)]">卡密类型（SKU）</div>
              <Button size="sm" onClick={() => { setEditingSku(null); setSkuForm({ name: "", grants_vip: false, vip_days: 0, warranty_days: 30, points_value: 0, notes: "", redeem_enabled: true }); setSkuDialog(true); }}>
                <Plus className="size-4" /> 新建类型
              </Button>
            </div>
            {!skus || skus.length === 0 ? (
              <ConsoleEmpty title="暂无卡密类型" />
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>名称</TableHead>
                    <TableHead>赠送会员</TableHead>
                    <TableHead>质保</TableHead>
                    <TableHead>积分</TableHead>
                    <TableHead>兑换开关</TableHead>
                    <TableHead className="text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {skus.map((s) => (
                    <TableRow key={s.id}>
                      <TableCell className="font-medium text-[var(--cx-text)]">{s.name}</TableCell>
                      <TableCell>{s.grants_vip ? `${s.vip_days} 天` : "—"}</TableCell>
                      <TableCell>{s.warranty_days > 0 ? `${s.warranty_days} 天` : "—"}</TableCell>
                      <TableCell>{s.points_value > 0 ? s.points_value : "—"}</TableCell>
                      <TableCell>
                        {s.redeem_enabled
                          ? <Badge className="border-emerald-500/30 bg-emerald-500/10 text-emerald-400">开启</Badge>
                          : <Badge className="border-red-500/30 bg-red-500/10 text-red-400">关闭</Badge>}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          <Button size="sm" variant="outline" onClick={() => {
                            setEditingSku(s);
                            setSkuForm({ name: s.name, grants_vip: s.grants_vip, vip_days: s.vip_days, warranty_days: s.warranty_days, points_value: s.points_value, notes: s.notes, redeem_enabled: s.redeem_enabled });
                            setSkuDialog(true);
                          }}>编辑</Button>
                          <Button size="icon" variant="ghost" onClick={() => { if (confirm(`确定删除类型「${s.name}」？`)) deleteSkuMut.mutate(s.id); }}>
                            <Trash className="size-4 text-red-400" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </ConsolePanel>
        </TabsContent>

        {/* 生成批次 */}
        <TabsContent value="batches">
          <ConsolePanel>
            <div className="mb-4 text-sm font-semibold text-[var(--cx-text)]">生成批次记录</div>
            {!batches || batches.length === 0 ? (
              <ConsoleEmpty title="暂无生成批次" />
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>批次名</TableHead>
                    <TableHead>类型</TableHead>
                    <TableHead>数量</TableHead>
                    <TableHead>备注</TableHead>
                    <TableHead>生成时间</TableHead>
                    <TableHead className="text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {batches.map((b) => (
                    <TableRow key={b.id}>
                      <TableCell className="font-medium text-[var(--cx-text)]">{b.batch_name}</TableCell>
                      <TableCell>{skuName(b.sku_id)}</TableCell>
                      <TableCell>{b.quantity}</TableCell>
                      <TableCell className="text-[var(--cx-muted)]">{b.note || "—"}</TableCell>
                      <TableCell className="text-[var(--cx-muted)]">{b.created_at}</TableCell>
                      <TableCell className="text-right">
                        <Button size="sm" variant="outline" onClick={() => copyCodes((codes ?? []).filter((c) => c.batch_id === b.id && c.status === "UNUSED"))}>
                          <Copy className="size-3.5" /> 复制未用
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </ConsolePanel>
        </TabsContent>
      </Tabs>

      {/* SKU 编辑对话框 */}
      <Dialog open={skuDialog} onOpenChange={setSkuDialog}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editingSku ? "编辑卡密类型" : "新建卡密类型"}</DialogTitle></DialogHeader>
          <div className="flex flex-col gap-3">
            <div className="flex flex-col gap-1.5">
              <Label>类型名称</Label>
              <Input value={skuForm.name} onChange={(e) => setSkuForm({ ...skuForm, name: e.target.value })} placeholder="如：会员月卡" />
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="flex flex-col gap-1.5">
                <Label>会员天数</Label>
                <Input type="number" value={skuForm.vip_days} onChange={(e) => setSkuForm({ ...skuForm, vip_days: Number(e.target.value) })} />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label>质保天数</Label>
                <Input type="number" value={skuForm.warranty_days} onChange={(e) => setSkuForm({ ...skuForm, warranty_days: Number(e.target.value) })} />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label>赠送积分</Label>
                <Input type="number" value={skuForm.points_value} onChange={(e) => setSkuForm({ ...skuForm, points_value: Number(e.target.value) })} />
              </div>
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>备注</Label>
              <Input value={skuForm.notes} onChange={(e) => setSkuForm({ ...skuForm, notes: e.target.value })} />
            </div>
            <div className="flex flex-col gap-2.5 rounded-lg border border-[var(--cx-line)] p-3">
              <label className="flex items-center justify-between text-sm">
                <span>兑换赠送 VIP</span>
                <Switch checked={skuForm.grants_vip} onCheckedChange={(v) => setSkuForm({ ...skuForm, grants_vip: v })} />
              </label>
              <label className="flex items-center justify-between text-sm">
                <span>开放兑换</span>
                <Switch checked={skuForm.redeem_enabled} onCheckedChange={(v) => setSkuForm({ ...skuForm, redeem_enabled: v })} />
              </label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSkuDialog(false)}>取消</Button>
            <Button disabled={!skuForm.name || saveSkuMut.isPending} onClick={() => saveSkuMut.mutate()}>保存</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 生成卡密对话框 */}
      <Dialog open={genDialog} onOpenChange={setGenDialog}>
        <DialogContent>
          <DialogHeader><DialogTitle>批量生成卡密</DialogTitle></DialogHeader>
          <div className="flex flex-col gap-3">
            <div className="flex flex-col gap-1.5">
              <Label>批次名称</Label>
              <Input value={genForm.batch_name} onChange={(e) => setGenForm({ ...genForm, batch_name: e.target.value })} placeholder="如：8月代理补货批次" />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>卡密类型</Label>
              <Select value={String(genForm.sku_id)} onValueChange={(v) => setGenForm({ ...genForm, sku_id: Number(v) })}>
                <SelectTrigger><SelectValue placeholder="选择类型" /></SelectTrigger>
                <SelectContent>
                  {(skus ?? []).map((s) => <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>生成数量（最多 500）</Label>
              <Input type="number" min={1} max={500} value={genForm.quantity} onChange={(e) => setGenForm({ ...genForm, quantity: Math.min(500, Math.max(1, Number(e.target.value))) })} />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>备注</Label>
              <Input value={genForm.note} onChange={(e) => setGenForm({ ...genForm, note: e.target.value })} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setGenDialog(false)}>取消</Button>
            <Button disabled={!genForm.batch_name || !genForm.sku_id || genMut.isPending} onClick={() => genMut.mutate()}>
              {genMut.isPending ? "生成中..." : "立即生成"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 生成结果 */}
      <Dialog open={!!generated} onOpenChange={() => setGenerated(null)}>
        <DialogContent className="max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>生成成功（{generated?.length} 张）</DialogTitle></DialogHeader>
          <div className="rounded-lg border border-[var(--cx-line)] bg-[var(--cx-bg)] p-3 font-mono text-xs leading-6">
            {generated?.map((c) => <div key={c.id}>{c.code}</div>)}
          </div>
          <DialogFooter>
            <Button onClick={() => generated && copyCodes(generated)}><Copy className="size-4" /> 一键复制</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
