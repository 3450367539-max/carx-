import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { UsersThree, Plus, Pencil, Trash } from "phosphor-react";
import {
  getAgents, createAgent, updateAgent, deleteAgent, getErrorMessage, type Agent,
} from "@/lib/api";
import { formatCurrency } from "@/lib/format";
import { agentTierLabel, agentStatusLabel } from "@/lib/status";
import { ConsoleHeader, ConsolePanel, ConsoleEmpty } from "@/components/ConsoleKit";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";

export default function AdminAgents() {
  const queryClient = useQueryClient();
  const { data: agents, isLoading } = useQuery({ queryKey: ["admin-agents"], queryFn: getAgents });
  const [editing, setEditing] = useState<Agent | null>(null);
  const [creating, setCreating] = useState(false);
  const empty = { username: "", password: "", agent_code: "", promo_code: "", tier: "standard" as Agent["tier"], commission_rate: 0.5, max_debt_limit: 500, status: "active" as Agent["status"] };
  const [form, setForm] = useState(empty);
  const invalidate = () => queryClient.invalidateQueries({ queryKey: ["admin-agents"] });

  const createMutation = useMutation({
    mutationFn: createAgent,
    onSuccess: () => { toast.success("代理商已创建"); setCreating(false); invalidate(); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });
  const updateMutation = useMutation({
    mutationFn: ({ id, body }: { id: number; body: Parameters<typeof updateAgent>[1] }) => updateAgent(id, body),
    onSuccess: () => { toast.success("已保存"); setEditing(null); invalidate(); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });
  const deleteMutation = useMutation({
    mutationFn: deleteAgent,
    onSuccess: () => { toast.success("已删除"); invalidate(); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  return (
    <div>
      <ConsoleHeader
        title="代理管理"
        description="管理代理账号、权限、商品范围、欠款和经营数据"
        actions={<Button className="bg-[var(--cx-red)] text-white hover:bg-[var(--cx-red)]/90" onClick={() => { setForm(empty); setCreating(true); }}><Plus className="size-4" /> 新建代理</Button>}
      />
      <ConsolePanel className="p-0">
        {isLoading ? (
          <div className="py-16 text-center text-sm text-[var(--cx-muted)]">正在加载...</div>
        ) : (agents ?? []).length === 0 ? (
          <div className="p-5"><ConsoleEmpty icon={<UsersThree className="size-8" />} title="暂无代理商" /></div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>账号</TableHead><TableHead>代号</TableHead><TableHead>等级</TableHead>
                <TableHead>佣金</TableHead><TableHead>欠款/额度</TableHead><TableHead>状态</TableHead>
                <TableHead className="text-right">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(agents ?? []).map((a) => (
                <TableRow key={a.id}>
                  <TableCell className="font-medium text-[var(--cx-text)]">{a.username}</TableCell>
                  <TableCell className="font-mono text-xs text-[var(--cx-muted)]">{a.agent_code}</TableCell>
                  <TableCell><Badge variant="outline" className="border-[var(--cx-line)] text-[var(--cx-muted)]">{agentTierLabel[a.tier]}</Badge></TableCell>
                  <TableCell className="text-[var(--cx-text)]">{Math.round(a.commission_rate * 100)}%</TableCell>
                  <TableCell className="text-[var(--cx-text)]">{formatCurrency(a.amount_owed)} / {formatCurrency(a.max_debt_limit)}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className={a.status === "active" ? "border-emerald-500/30 text-[var(--cx-green)]" : "border-[var(--cx-red)]/40 text-[var(--cx-red)]"}>
                      {agentStatusLabel[a.status]}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" className="text-[var(--cx-muted)]" onClick={() => { setForm({ username: a.username, password: "", agent_code: a.agent_code, promo_code: a.promo_code, tier: a.tier, commission_rate: a.commission_rate, max_debt_limit: a.max_debt_limit, status: a.status }); setEditing(a); }}><Pencil className="size-4" /></Button>
                    <Button variant="ghost" size="icon" className="text-[var(--cx-red)]" onClick={() => deleteMutation.mutate(a.id)}><Trash className="size-4" /></Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </ConsolePanel>

      <Dialog open={creating || !!editing} onOpenChange={(o) => { if (!o) { setCreating(false); setEditing(null); } }}>
        <DialogContent>
          <DialogHeader><DialogTitle>{creating ? "新建代理" : "编辑代理"}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3">
            <div className="flex flex-col gap-1.5"><Label>账号</Label><Input value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} /></div>
            <div className="flex flex-col gap-1.5"><Label>{creating ? "密码" : "重置密码"}</Label><Input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></div>
            <div className="flex flex-col gap-1.5"><Label>代号</Label><Input value={form.agent_code} onChange={(e) => setForm({ ...form, agent_code: e.target.value })} /></div>
            <div className="flex flex-col gap-1.5"><Label>推广码</Label><Input value={form.promo_code} onChange={(e) => setForm({ ...form, promo_code: e.target.value })} /></div>
            <div className="flex flex-col gap-1.5"><Label>等级</Label>
              <Select value={form.tier} onValueChange={(v) => setForm({ ...form, tier: v as Agent["tier"] })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="standard">标准代理</SelectItem><SelectItem value="sales">销售代理</SelectItem><SelectItem value="senior">高级代理</SelectItem><SelectItem value="aftersales">售后代理</SelectItem></SelectContent>
              </Select>
            </div>
            <div className="flex flex-col gap-1.5"><Label>状态</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v as Agent["status"] })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="active">启用中</SelectItem><SelectItem value="suspended">已停用</SelectItem><SelectItem value="archived">已归档</SelectItem></SelectContent>
              </Select>
            </div>
            <div className="flex flex-col gap-1.5"><Label>佣金比例 (0-1)</Label><Input type="number" step="0.05" value={form.commission_rate} onChange={(e) => setForm({ ...form, commission_rate: Number(e.target.value) })} /></div>
            <div className="flex flex-col gap-1.5"><Label>欠款授信额度</Label><Input type="number" value={form.max_debt_limit} onChange={(e) => setForm({ ...form, max_debt_limit: Number(e.target.value) })} /></div>
          </div>
          <DialogFooter>
            <Button
              className="bg-[var(--cx-red)] text-white hover:bg-[var(--cx-red)]/90"
              disabled={createMutation.isPending || updateMutation.isPending}
              onClick={() => {
                if (creating) {
                  if (!form.username || !form.password) { toast.error("请填写账号与密码"); return; }
                  createMutation.mutate(form);
                } else if (editing) {
                  const body: Parameters<typeof updateAgent>[1] = { ...form };
                  if (!form.password) delete body.password;
                  updateMutation.mutate({ id: editing.id, body });
                }
              }}
            >保存</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
