import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Users, Crown, Pencil, MagnifyingGlass } from "phosphor-react";
import { getAgentCustomers, setCustomerRemark, getErrorMessage, type AgentCustomer } from "@/lib/api";
import { formatCurrency } from "@/lib/format";
import { ConsoleHeader, ConsolePanel, ConsoleEmpty } from "@/components/ConsoleKit";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";

export default function AgentCustomers() {
  const queryClient = useQueryClient();
  const { data, isLoading } = useQuery({ queryKey: ["agent-customers"], queryFn: getAgentCustomers });
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState<AgentCustomer | null>(null);
  const [remark, setRemark] = useState("");

  const remarkMutation = useMutation({
    mutationFn: setCustomerRemark,
    onSuccess: () => {
      toast.success("备注已保存");
      setEditing(null);
      queryClient.invalidateQueries({ queryKey: ["agent-customers"] });
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const items = (data?.items ?? []).filter((c) =>
    !search.trim() || c.username.toLowerCase().includes(search.trim().toLowerCase())
  );

  return (
    <div>
      <ConsoleHeader title="客户管理" description="管理自己的客户、备注、标签和售后操作" />

      <div className="mb-4 flex items-center gap-3">
        <div className="relative">
          <MagnifyingGlass className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-[var(--cx-muted)]" />
          <Input
            placeholder="搜索客户邮箱"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-64 border-[var(--cx-line)] bg-[var(--cx-panel)] pl-9 text-[var(--cx-text)]"
          />
        </div>
      </div>

      <ConsolePanel className="p-0">
        {isLoading ? (
          <div className="py-16 text-center text-sm text-[var(--cx-muted)]">正在加载...</div>
        ) : items.length === 0 ? (
          <div className="p-5"><ConsoleEmpty icon={<Users className="size-8" />} title="暂无客户" /></div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>客户邮箱</TableHead>
                <TableHead>VIP</TableHead>
                <TableHead>信用分</TableHead>
                <TableHead>订单数</TableHead>
                <TableHead>累计消费</TableHead>
                <TableHead>备注</TableHead>
                <TableHead className="text-right">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((c) => (
                <TableRow key={c.id}>
                  <TableCell className="font-mono text-xs text-[var(--cx-text)]">{c.username}</TableCell>
                  <TableCell>
                    {c.is_vip ? (
                      <Badge className="border-amber-500/40 bg-amber-500/10 text-[var(--cx-amber)]">
                        <Crown className="mr-1 size-3" weight="fill" /> VIP
                      </Badge>
                    ) : (
                      <span className="text-xs text-[var(--cx-muted)]">—</span>
                    )}
                  </TableCell>
                  <TableCell className="text-[var(--cx-text)]">{c.credit_score}</TableCell>
                  <TableCell className="text-[var(--cx-text)]">{c.order_count}</TableCell>
                  <TableCell className="font-semibold text-[var(--cx-text)]">{formatCurrency(c.total_spent)}</TableCell>
                  <TableCell className="max-w-32 truncate text-xs text-[var(--cx-muted)]">{c.remark || "—"}</TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-[var(--cx-muted)] hover:text-[var(--cx-text)]"
                      onClick={() => { setEditing(c); setRemark(c.remark); }}
                    >
                      <Pencil className="size-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </ConsolePanel>

      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>客户备注</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-3">
            <div className="rounded-[8px] bg-[var(--cx-panel-soft)] p-3 font-mono text-xs text-[var(--cx-text)]">
              {editing?.username}
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>备注</Label>
              <Input value={remark} onChange={(e) => setRemark(e.target.value)} placeholder="添加备注..." />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditing(null)}>取消</Button>
            <Button
              className="bg-[var(--cx-red)] text-white hover:bg-[var(--cx-red)]/90"
              disabled={remarkMutation.isPending}
              onClick={() => editing && remarkMutation.mutate({ user_id: editing.id, remark })}
            >
              保存
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
