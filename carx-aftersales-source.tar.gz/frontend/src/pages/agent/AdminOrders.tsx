import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Receipt, Trash } from "phosphor-react";
import {
  getAdminOrders, updateAdminOrder, deleteAdminOrder, getErrorMessage, type OrderStatus,
} from "@/lib/api";
import { orderStatusMeta } from "@/lib/status";
import { formatCurrency, formatDateTime } from "@/lib/format";
import { ConsoleHeader, ConsolePanel, ConsoleEmpty } from "@/components/ConsoleKit";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";

export default function AdminOrders() {
  const queryClient = useQueryClient();
  const { data: orders, isLoading } = useQuery({ queryKey: ["admin-orders"], queryFn: getAdminOrders });
  const invalidate = () => queryClient.invalidateQueries({ queryKey: ["admin-orders"] });

  const updateMutation = useMutation({
    mutationFn: ({ id, status }: { id: number; status: OrderStatus }) => updateAdminOrder(id, { status }),
    onSuccess: () => { toast.success("状态已更新"); invalidate(); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });
  const deleteMutation = useMutation({
    mutationFn: deleteAdminOrder,
    onSuccess: () => { toast.success("已删除"); invalidate(); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  return (
    <div>
      <ConsoleHeader title="订单管理" description="查看订单、客户、商品、状态、质保和售后记录" />
      <ConsolePanel className="p-0">
        {isLoading ? (
          <div className="py-16 text-center text-sm text-[var(--cx-muted)]">正在加载...</div>
        ) : (orders ?? []).length === 0 ? (
          <div className="p-5"><ConsoleEmpty icon={<Receipt className="size-8" />} title="暂无订单" /></div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>订单号</TableHead><TableHead>商品</TableHead><TableHead>客户</TableHead>
                <TableHead>类型</TableHead><TableHead>金额</TableHead><TableHead>状态</TableHead>
                <TableHead>时间</TableHead><TableHead className="text-right">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(orders ?? []).map((o) => (
                <TableRow key={o.order_id}>
                  <TableCell className="font-mono text-xs text-[var(--cx-muted)]">{o.display_no}</TableCell>
                  <TableCell className="font-medium text-[var(--cx-text)]">{o.product_name}</TableCell>
                  <TableCell className="font-mono text-xs text-[var(--cx-muted)]">{o.customer_username}</TableCell>
                  <TableCell><Badge variant="outline" className="border-[var(--cx-line)] text-[var(--cx-muted)]">{o.order_type_label}</Badge></TableCell>
                  <TableCell className="text-[var(--cx-text)]">{o.amount > 0 ? formatCurrency(o.amount) : "—"}</TableCell>
                  <TableCell>
                    <Select value={o.status} onValueChange={(v) => updateMutation.mutate({ id: o.order_id, status: v as OrderStatus })}>
                      <SelectTrigger className="h-8 w-32 border-[var(--cx-line)] bg-[var(--cx-panel)] text-[var(--cx-text)]"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {(Object.keys(orderStatusMeta) as OrderStatus[]).map((s) => (
                          <SelectItem key={s} value={s}>{orderStatusMeta[s].label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell className="text-xs text-[var(--cx-muted)]">{formatDateTime(o.created_at)}</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" className="text-[var(--cx-red)]" onClick={() => deleteMutation.mutate(o.order_id)}><Trash className="size-4" /></Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </ConsolePanel>
    </div>
  );
}
