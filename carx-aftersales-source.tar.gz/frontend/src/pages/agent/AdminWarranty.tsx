import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { ShieldCheck } from "phosphor-react";
import {
  getAdminWarranty, updateAdminWarranty, getErrorMessage,
  type WarrantyClaim, type WarrantyStatus,
} from "@/lib/api";
import { formatDateTime } from "@/lib/format";
import { ConsoleHeader, ConsolePanel, ConsoleStat, ConsoleEmpty } from "@/components/ConsoleKit";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";

const statusMeta: Record<WarrantyStatus, { label: string; cls: string }> = {
  pending: { label: "待处理", cls: "border-amber-500/30 bg-amber-500/10 text-amber-400" },
  processing: { label: "处理中", cls: "border-sky-500/30 bg-sky-500/10 text-sky-400" },
  resolved: { label: "已解决", cls: "border-emerald-500/30 bg-emerald-500/10 text-emerald-400" },
  rejected: { label: "已驳回", cls: "border-red-500/30 bg-red-500/10 text-red-400" },
};

const claimTypeLabel: Record<WarrantyClaim["claim_type"], string> = {
  ban_recover: "封禁恢复",
  warranty: "售后理赔",
};

export default function AdminWarranty() {
  const queryClient = useQueryClient();
  const { data: claims, isLoading } = useQuery({ queryKey: ["admin-warranty"], queryFn: getAdminWarranty });
  const [filter, setFilter] = useState<"all" | WarrantyStatus>("all");
  const [handling, setHandling] = useState<WarrantyClaim | null>(null);
  const [handleForm, setHandleForm] = useState<{ status: WarrantyStatus; note: string }>({ status: "processing", note: "" });

  const updateMut = useMutation({
    mutationFn: () => updateAdminWarranty(handling!.id, handleForm),
    onSuccess: () => {
      toast.success("工单已更新");
      setHandling(null);
      queryClient.invalidateQueries({ queryKey: ["admin-warranty"] });
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const filtered = (claims ?? []).filter((c) => filter === "all" || c.status === filter);
  const pendingCount = (claims ?? []).filter((c) => c.status === "pending").length;

  return (
    <div>
      <ConsoleHeader title="售后理赔" description="处理用户提交的售后与封禁恢复工单" />

      <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <ConsoleStat label="工单总数" value={claims?.length ?? 0} />
        <ConsoleStat label="待处理" value={pendingCount} tone="red" />
        <ConsoleStat label="处理中" value={(claims ?? []).filter((c) => c.status === "processing").length} />
        <ConsoleStat label="已解决" value={(claims ?? []).filter((c) => c.status === "resolved").length} />
      </div>

      <ConsolePanel>
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-sm font-semibold text-[var(--cx-text)]">
            <ShieldCheck className="size-4" /> 工单列表
          </div>
          <Select value={filter} onValueChange={(v) => setFilter(v as typeof filter)}>
            <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">全部状态</SelectItem>
              <SelectItem value="pending">待处理</SelectItem>
              <SelectItem value="processing">处理中</SelectItem>
              <SelectItem value="resolved">已解决</SelectItem>
              <SelectItem value="rejected">已驳回</SelectItem>
            </SelectContent>
          </Select>
        </div>
        {isLoading ? (
          <div className="py-10 text-center text-sm text-[var(--cx-muted)]">正在加载...</div>
        ) : filtered.length === 0 ? (
          <ConsoleEmpty title="暂无工单" />
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>工单号</TableHead>
                <TableHead>类型</TableHead>
                <TableHead>游戏账号</TableHead>
                <TableHead>关联订单</TableHead>
                <TableHead>状态</TableHead>
                <TableHead>提交时间</TableHead>
                <TableHead className="text-right">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((c) => (
                <TableRow key={c.id}>
                  <TableCell className="font-mono text-xs">#{c.id}</TableCell>
                  <TableCell><Badge variant="outline">{claimTypeLabel[c.claim_type]}</Badge></TableCell>
                  <TableCell className="text-[var(--cx-text)]">{c.carx_email}</TableCell>
                  <TableCell className="text-[var(--cx-muted)]">{c.order_id ? `#${c.order_id}` : "—"}</TableCell>
                  <TableCell><Badge className={statusMeta[c.status].cls}>{statusMeta[c.status].label}</Badge></TableCell>
                  <TableCell className="text-[var(--cx-muted)]">{formatDateTime(c.created_at)}</TableCell>
                  <TableCell className="text-right">
                    <Button size="sm" variant="outline" onClick={() => {
                      setHandling(c);
                      setHandleForm({ status: c.status === "pending" ? "processing" : c.status, note: c.note });
                    }}>处理</Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </ConsolePanel>

      <Dialog open={!!handling} onOpenChange={(o) => { if (!o) setHandling(null); }}>
        <DialogContent>
          <DialogHeader><DialogTitle>处理工单 #{handling?.id}</DialogTitle></DialogHeader>
          {handling && (
            <div className="flex flex-col gap-3">
              <div className="rounded-lg border border-[var(--cx-line)] bg-[var(--cx-bg)] p-3 text-sm">
                <div className="mb-1 flex justify-between"><span className="text-[var(--cx-muted)]">类型</span><span>{claimTypeLabel[handling.claim_type]}</span></div>
                <div className="mb-1 flex justify-between"><span className="text-[var(--cx-muted)]">游戏账号</span><span>{handling.carx_email}</span></div>
                {handling.order_id && <div className="mb-1 flex justify-between"><span className="text-[var(--cx-muted)]">关联订单</span><span>#{handling.order_id}</span></div>}
                <div className="mt-2 border-t border-[var(--cx-line)] pt-2 text-[var(--cx-muted)]">{handling.note || "用户未填写说明"}</div>
              </div>
              <div className="flex flex-col gap-1.5">
                <Label>处理结果</Label>
                <Select value={handleForm.status} onValueChange={(v) => setHandleForm({ ...handleForm, status: v as WarrantyStatus })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="processing">处理中</SelectItem>
                    <SelectItem value="resolved">已解决</SelectItem>
                    <SelectItem value="rejected">驳回</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex flex-col gap-1.5">
                <Label>处理备注</Label>
                <Textarea rows={3} value={handleForm.note} onChange={(e) => setHandleForm({ ...handleForm, note: e.target.value })} placeholder="填写处理说明，用户可见" />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setHandling(null)}>取消</Button>
            <Button disabled={updateMut.isPending} onClick={() => updateMut.mutate()}>
              {updateMut.isPending ? "提交中..." : "提交处理结果"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
