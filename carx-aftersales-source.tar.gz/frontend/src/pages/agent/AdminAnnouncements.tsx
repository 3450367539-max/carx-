import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Bell, Plus, Pencil, Trash } from "phosphor-react";
import {
  getAdminAnnouncements, createAnnouncement, updateAnnouncement, deleteAnnouncement,
  getErrorMessage, type Announcement,
} from "@/lib/api";
import { formatDateTime } from "@/lib/format";
import { ConsoleHeader, ConsolePanel, ConsoleEmpty } from "@/components/ConsoleKit";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";

const targetLabel: Record<string, string> = { all: "全部", user: "会员", agent: "代理", admin: "管理员" };

export default function AdminAnnouncements() {
  const queryClient = useQueryClient();
  const { data: announcements, isLoading } = useQuery({ queryKey: ["admin-announcements"], queryFn: getAdminAnnouncements });
  const [editing, setEditing] = useState<Announcement | null>(null);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({ title: "", content: "", target_role: "all" as Announcement["target_role"], is_active: true });
  const invalidate = () => queryClient.invalidateQueries({ queryKey: ["admin-announcements"] });

  const createMutation = useMutation({
    mutationFn: createAnnouncement,
    onSuccess: () => { toast.success("公告已发布"); setCreating(false); invalidate(); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });
  const updateMutation = useMutation({
    mutationFn: ({ id, body }: { id: number; body: Partial<Announcement> }) => updateAnnouncement(id, body),
    onSuccess: () => { toast.success("已保存"); setEditing(null); invalidate(); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });
  const deleteMutation = useMutation({
    mutationFn: deleteAnnouncement,
    onSuccess: () => { toast.success("已删除"); invalidate(); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const openCreate = () => { setForm({ title: "", content: "", target_role: "all", is_active: true }); setCreating(true); };
  const openEdit = (a: Announcement) => { setForm({ title: a.title, content: a.content, target_role: a.target_role, is_active: a.is_active }); setEditing(a); };

  return (
    <div>
      <ConsoleHeader
        title="消息通知"
        description="发布站内消息，并管理用户与代理的提醒"
        actions={<Button className="bg-[var(--cx-red)] text-white hover:bg-[var(--cx-red)]/90" onClick={openCreate}><Plus className="size-4" /> 发布公告</Button>}
      />

      {isLoading ? (
        <div className="py-16 text-center text-sm text-[var(--cx-muted)]">正在加载...</div>
      ) : (announcements ?? []).length === 0 ? (
        <ConsoleEmpty icon={<Bell className="size-8" />} title="暂无公告" />
      ) : (
        <div className="flex flex-col gap-4">
          {(announcements ?? []).map((a) => (
            <ConsolePanel key={a.id}>
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <Bell className="size-4 shrink-0 text-[var(--cx-red)]" weight="fill" />
                    <span className="text-sm font-semibold text-[var(--cx-text)]">{a.title}</span>
                    <Badge variant="outline" className="border-[var(--cx-line)] text-[var(--cx-muted)]">{targetLabel[a.target_role]}</Badge>
                    <Badge variant="outline" className={a.is_active ? "border-emerald-500/30 text-[var(--cx-green)]" : "text-[var(--cx-muted)]"}>
                      {a.is_active ? "展示中" : "已下线"}
                    </Badge>
                  </div>
                  <p className="mt-2 whitespace-pre-line text-sm leading-relaxed text-[var(--cx-muted)]">{a.content}</p>
                </div>
                <div className="flex shrink-0 items-center gap-1">
                  <span className="mr-1 text-xs text-[var(--cx-muted)]">{formatDateTime(a.createdAt)}</span>
                  <Button variant="ghost" size="icon" className="text-[var(--cx-muted)]" onClick={() => openEdit(a)}><Pencil className="size-4" /></Button>
                  <Button variant="ghost" size="icon" className="text-[var(--cx-red)]" onClick={() => deleteMutation.mutate(a.id)}><Trash className="size-4" /></Button>
                </div>
              </div>
            </ConsolePanel>
          ))}
        </div>
      )}

      <Dialog open={creating || !!editing} onOpenChange={(o) => { if (!o) { setCreating(false); setEditing(null); } }}>
        <DialogContent>
          <DialogHeader><DialogTitle>{creating ? "发布公告" : "编辑公告"}</DialogTitle></DialogHeader>
          <div className="flex flex-col gap-3">
            <div className="flex flex-col gap-1.5"><Label>标题</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></div>
            <div className="flex flex-col gap-1.5"><Label>内容</Label><Textarea value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} rows={6} /></div>
            <div className="flex flex-col gap-1.5"><Label>目标角色</Label>
              <Select value={form.target_role} onValueChange={(v) => setForm({ ...form, target_role: v as Announcement["target_role"] })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">全部</SelectItem><SelectItem value="user">会员</SelectItem>
                  <SelectItem value="agent">代理</SelectItem><SelectItem value="admin">管理员</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center justify-between rounded-[8px] border border-[var(--cx-line)] p-3">
              <Label>立即展示</Label><Switch checked={form.is_active} onCheckedChange={(v) => setForm({ ...form, is_active: v })} />
            </div>
          </div>
          <DialogFooter>
            <Button
              className="bg-[var(--cx-red)] text-white hover:bg-[var(--cx-red)]/90"
              disabled={createMutation.isPending || updateMutation.isPending}
              onClick={() => {
                if (!form.title) { toast.error("请输入标题"); return; }
                if (creating) createMutation.mutate(form);
                else if (editing) updateMutation.mutate({ id: editing.id, body: form });
              }}
            >保存</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
