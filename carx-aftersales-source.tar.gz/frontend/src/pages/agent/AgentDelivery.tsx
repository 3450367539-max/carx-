import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { RocketLaunch, ShoppingBag } from "phosphor-react";
import { getAgentPrices, agentInject, getErrorMessage } from "@/lib/api";
import { formatCurrency } from "@/lib/format";
import { ConsoleHeader } from "@/components/ConsoleKit";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import type { AgentPrice } from "@/lib/api";

export default function AgentDelivery() {
  const queryClient = useQueryClient();
  const { data: prices, isLoading } = useQuery({ queryKey: ["agent-prices"], queryFn: getAgentPrices });
  const [target, setTarget] = useState<AgentPrice | null>(null);
  const [email, setEmail] = useState("");
  const [price, setPrice] = useState("");

  const injectMutation = useMutation({
    mutationFn: agentInject,
    onSuccess: (r) => {
      toast.success(`发货成功，当前欠款 ${formatCurrency(r.amount_owed)}`);
      setTarget(null); setEmail(""); setPrice("");
      queryClient.invalidateQueries({ queryKey: ["agent-dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["agent-debt"] });
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const openInject = (p: AgentPrice) => {
    setTarget(p);
    setPrice(String(p.agent_price));
    setEmail("");
  };

  return (
    <div>
      <ConsoleHeader title="发货操作" description="普通套餐、礼包和权益类商品发货" />

      {isLoading ? (
        <div className="py-16 text-center text-sm text-[var(--cx-muted)]">正在加载...</div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {(prices ?? []).map((p) => (
            <div key={p.product_id} className="console-panel flex flex-col p-5">
              <div className="flex items-start justify-between">
                <span className="text-sm font-semibold text-[var(--cx-text)]">{p.product_name}</span>
                {p.has_custom_price && <Badge variant="outline" className="border-[var(--cx-blue)]/40 text-[var(--cx-blue)]">自定义价</Badge>}
              </div>
              <div className="mt-3 grid grid-cols-3 gap-2 text-center">
                <div className="rounded-[8px] bg-[var(--cx-panel-soft)] p-2">
                  <div className="text-[11px] text-[var(--cx-muted)]">成本价</div>
                  <div className="text-sm font-semibold text-[var(--cx-text)]">{formatCurrency(p.settlement_cost)}</div>
                </div>
                <div className="rounded-[8px] bg-[var(--cx-panel-soft)] p-2">
                  <div className="text-[11px] text-[var(--cx-muted)]">售价</div>
                  <div className="text-sm font-semibold text-[var(--cx-text)]">{formatCurrency(p.agent_price)}</div>
                </div>
                <div className="rounded-[8px] bg-[var(--cx-panel-soft)] p-2">
                  <div className="text-[11px] text-[var(--cx-muted)]">利润空间</div>
                  <div className="text-sm font-semibold text-[var(--cx-green)]">{formatCurrency(p.income_space)}</div>
                </div>
              </div>
              <Button
                className="mt-4 bg-[var(--cx-red)] text-white hover:bg-[var(--cx-red)]/90"
                onClick={() => openInject(p)}
              >
                <RocketLaunch className="size-4" /> 立即发货
              </Button>
            </div>
          ))}
        </div>
      )}

      <Dialog open={!!target} onOpenChange={(o) => !o && setTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ShoppingBag className="size-5 text-[var(--cx-red)]" /> 发货「{target?.product_name}」
            </DialogTitle>
            <DialogDescription>填写客户游戏邮箱，系统创建订单并计入欠款台账</DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-3">
            <div className="flex flex-col gap-1.5">
              <Label>客户游戏邮箱</Label>
              <Input placeholder="customer@example.com" value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>售价（元）</Label>
              <Input type="number" value={price} onChange={(e) => setPrice(e.target.value)} />
            </div>
            <div className="rounded-[8px] bg-[var(--cx-panel-soft)] p-3 text-xs text-[var(--cx-muted)]">
              结算成本 {formatCurrency(target?.settlement_cost ?? 0)} 将计入您的欠款。
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setTarget(null)}>取消</Button>
            <Button
              className="bg-[var(--cx-red)] text-white hover:bg-[var(--cx-red)]/90"
              disabled={injectMutation.isPending}
              onClick={() => {
                if (!target) return;
                if (!email.trim()) { toast.error("请输入客户游戏邮箱"); return; }
                injectMutation.mutate({
                  product_id: target.product_id,
                  customer_carx_email: email.trim(),
                  selling_price: Number(price) || target.agent_price,
                });
              }}
            >
              {injectMutation.isPending ? "发货中..." : "确认发货"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
