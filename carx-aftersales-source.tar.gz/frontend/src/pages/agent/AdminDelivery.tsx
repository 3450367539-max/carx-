import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Stack, Package, Ticket, Plus, Pencil, Trash } from "phosphor-react";
import {
  getAdminProducts, createProduct, updateProduct, deleteProduct,
  getCardSkus, getCardBatches, getCardCodes, createCardBatch, deleteCardCode,
  getAdminFinishedProfiles, createFinishedProfile, deleteFinishedProfile,
  getAdminWarranty, updateAdminWarranty,
  getErrorMessage, type Product, type WarrantyStatus,
} from "@/lib/api";
import { formatCurrency, formatDateTime } from "@/lib/format";
import { cardStatusMeta, warrantyStatusMeta, warrantyTypeLabel } from "@/lib/status";
import { ConsoleHeader, ConsolePanel, ConsoleEmpty } from "@/components/ConsoleKit";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";

export default function AdminDelivery() {
  const queryClient = useQueryClient();
  const { data: products } = useQuery({ queryKey: ["admin-products"], queryFn: getAdminProducts });
  const { data: skus } = useQuery({ queryKey: ["card-skus"], queryFn: getCardSkus });
  const { data: batches } = useQuery({ queryKey: ["card-batches"], queryFn: getCardBatches });
  const { data: codes } = useQuery({ queryKey: ["card-codes"], queryFn: getCardCodes });
  const { data: profiles } = useQuery({ queryKey: ["finished-profiles"], queryFn: getAdminFinishedProfiles });
  const { data: warranty } = useQuery({ queryKey: ["admin-warranty"], queryFn: getAdminWarranty });

  const [productOpen, setProductOpen] = useState(false);
  const [editProduct, setEditProduct] = useState<Product | null>(null);
  const [pForm, setPForm] = useState({ name: "", description: "", base_price: 0, settlement_cost: 0, warranty_days: 30, grants_vip: false, vip_days: 0, is_active: true });
  const [batchOpen, setBatchOpen] = useState(false);
  const [batchName, setBatchName] = useState("");
  const [batchSku, setBatchSku] = useState("");
  const [batchQty, setBatchQty] = useState(10);
  const [profileOpen, setProfileOpen] = useState(false);
  const [fForm, setFForm] = useState({ code: "", name: "", description: "", warranty_days_default: 30 });

  const inv = (keys: string[]) => keys.forEach((k) => queryClient.invalidateQueries({ queryKey: [k] }));

  const productSave = useMutation({
    mutationFn: (data: { id?: number; body: Partial<Product> & { name: string; base_price: number } }) =>
      data.id ? updateProduct(data.id, data.body) : createProduct(data.body),
    onSuccess: () => { toast.success("已保存"); setProductOpen(false); setEditProduct(null); inv(["admin-products"]); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });
  const productDelete = useMutation({
    mutationFn: deleteProduct,
    onSuccess: () => { toast.success("已删除"); inv(["admin-products"]); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });
  const batchCreate = useMutation({
    mutationFn: createCardBatch,
    onSuccess: (r) => { toast.success(`已生成 ${r.codes.length} 张卡密`); setBatchOpen(false); setBatchName(""); inv(["card-batches", "card-codes"]); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });
  const codeDelete = useMutation({
    mutationFn: deleteCardCode,
    onSuccess: () => { toast.success("已删除"); inv(["card-codes"]); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });
  const profileCreate = useMutation({
    mutationFn: createFinishedProfile,
    onSuccess: () => { toast.success("成品号档位已创建"); setProfileOpen(false); setFForm({ code: "", name: "", description: "", warranty_days_default: 30 }); inv(["finished-profiles"]); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });
  const profileDelete = useMutation({
    mutationFn: deleteFinishedProfile,
    onSuccess: () => { toast.success("已删除"); inv(["finished-profiles"]); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });
  const warrantyUpdate = useMutation({
    mutationFn: ({ id, status }: { id: number; status: WarrantyStatus }) => updateAdminWarranty(id, { status }),
    onSuccess: () => { toast.success("已更新"); inv(["admin-warranty"]); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  return (
    <div>
      <ConsoleHeader title="交付中心" description="集中管理商品、卡密、成品号和交付售后" />

      <Tabs defaultValue="products">
        <TabsList className="border border-[var(--cx-line)] bg-[var(--cx-panel)]">
          <TabsTrigger value="products"><Package className="size-4" /> 商品</TabsTrigger>
          <TabsTrigger value="cards"><Ticket className="size-4" /> 卡密</TabsTrigger>
          <TabsTrigger value="finished"><Stack className="size-4" /> 成品号</TabsTrigger>
          <TabsTrigger value="warranty"><Pencil className="size-4" /> 交付售后</TabsTrigger>
        </TabsList>

        {/* 商品 */}
        <TabsContent value="products" className="mt-4">
          <div className="mb-3 flex justify-end">
            <Button className="bg-[var(--cx-red)] text-white hover:bg-[var(--cx-red)]/90" onClick={() => { setEditProduct(null); setPForm({ name: "", description: "", base_price: 0, settlement_cost: 0, warranty_days: 30, grants_vip: false, vip_days: 0, is_active: true }); setProductOpen(true); }}>
              <Plus className="size-4" /> 新建商品
            </Button>
          </div>
          <ConsolePanel className="p-0">
            {(products ?? []).length === 0 ? (
              <div className="p-5"><ConsoleEmpty icon={<Package className="size-8" />} title="暂无商品" /></div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>名称</TableHead><TableHead>售价</TableHead><TableHead>结算成本</TableHead>
                    <TableHead>保修</TableHead><TableHead>赠 VIP</TableHead><TableHead>状态</TableHead>
                    <TableHead className="text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {(products ?? []).map((p) => (
                    <TableRow key={p.id}>
                      <TableCell className="font-medium text-[var(--cx-text)]">{p.name}</TableCell>
                      <TableCell className="text-[var(--cx-text)]">{p.base_price > 0 ? formatCurrency(p.base_price) : "积分兑换"}</TableCell>
                      <TableCell className="text-[var(--cx-muted)]">{formatCurrency(p.settlement_cost)}</TableCell>
                      <TableCell className="text-[var(--cx-muted)]">{p.warranty_days > 0 ? `${p.warranty_days} 天` : "—"}</TableCell>
                      <TableCell>{p.grants_vip ? <Badge variant="outline" className="border-amber-500/40 text-[var(--cx-amber)]">{p.vip_days} 天</Badge> : "—"}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className={p.is_active ? "border-emerald-500/30 text-[var(--cx-green)]" : "text-[var(--cx-muted)]"}>{p.is_active ? "在售" : "下架"}</Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" className="text-[var(--cx-muted)]" onClick={() => { setEditProduct(p); setPForm({ name: p.name, description: p.description, base_price: p.base_price, settlement_cost: p.settlement_cost, warranty_days: p.warranty_days, grants_vip: p.grants_vip, vip_days: p.vip_days, is_active: p.is_active }); setProductOpen(true); }}><Pencil className="size-4" /></Button>
                        <Button variant="ghost" size="icon" className="text-[var(--cx-red)]" onClick={() => productDelete.mutate(p.id)}><Trash className="size-4" /></Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </ConsolePanel>
        </TabsContent>

        {/* 卡密 */}
        <TabsContent value="cards" className="mt-4">
          <div className="mb-3 flex justify-end">
            <Button className="bg-[var(--cx-red)] text-white hover:bg-[var(--cx-red)]/90" onClick={() => setBatchOpen(true)}>
              <Plus className="size-4" /> 生成批次
            </Button>
          </div>
          <ConsolePanel className="p-0">
            {(codes ?? []).length === 0 ? (
              <div className="p-5"><ConsoleEmpty icon={<Ticket className="size-8" />} title="暂无卡密" /></div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>卡密</TableHead><TableHead>类型</TableHead><TableHead>状态</TableHead>
                    <TableHead>兑换人</TableHead><TableHead>兑换时间</TableHead><TableHead className="text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {(codes ?? []).map((c) => (
                    <TableRow key={c.id}>
                      <TableCell className="font-mono text-xs text-[var(--cx-text)]">{c.code}</TableCell>
                      <TableCell className="text-[var(--cx-muted)]">{c.sku_name}</TableCell>
                      <TableCell><Badge variant="outline" className={cardStatusMeta[c.status].className}>{cardStatusMeta[c.status].label}</Badge></TableCell>
                      <TableCell className="font-mono text-xs text-[var(--cx-muted)]">{c.redeemed_by ?? "—"}</TableCell>
                      <TableCell className="text-xs text-[var(--cx-muted)]">{c.redeemed_at ? formatDateTime(c.redeemed_at) : "—"}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" className="text-[var(--cx-red)]" onClick={() => codeDelete.mutate(c.id)}><Trash className="size-4" /></Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </ConsolePanel>
          <div className="mt-3 text-xs text-[var(--cx-muted)]">共 {batches?.length ?? 0} 个批次 · {codes?.length ?? 0} 张卡密</div>
        </TabsContent>

        {/* 成品号 */}
        <TabsContent value="finished" className="mt-4">
          <div className="mb-3 flex justify-end">
            <Button className="bg-[var(--cx-red)] text-white hover:bg-[var(--cx-red)]/90" onClick={() => setProfileOpen(true)}>
              <Plus className="size-4" /> 新建档位
            </Button>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
            {(profiles ?? []).map((p) => (
              <ConsolePanel key={p.id}>
                <div className="flex items-start justify-between">
                  <div>
                    <div className="text-sm font-semibold text-[var(--cx-text)]">{p.name}</div>
                    <div className="mt-0.5 font-mono text-xs text-[var(--cx-muted)]">{p.code}</div>
                  </div>
                  <Button variant="ghost" size="icon" className="text-[var(--cx-red)]" onClick={() => profileDelete.mutate(p.id)}><Trash className="size-4" /></Button>
                </div>
                <p className="mt-2 text-xs text-[var(--cx-muted)]">{p.description}</p>
                <div className="mt-3 flex gap-2">
                  <Badge variant="outline" className="border-[var(--cx-line)] text-[var(--cx-muted)]">保修 {p.warranty_days_default} 天</Badge>
                  <Badge variant="outline" className={p.is_active ? "border-emerald-500/30 text-[var(--cx-green)]" : "text-[var(--cx-muted)]"}>{p.is_active ? "启用" : "停用"}</Badge>
                </div>
              </ConsolePanel>
            ))}
            {(profiles ?? []).length === 0 && (
              <div className="sm:col-span-2 xl:col-span-3"><ConsoleEmpty icon={<Stack className="size-8" />} title="暂无成品号档位" /></div>
            )}
          </div>
        </TabsContent>

        {/* 交付售后 */}
        <TabsContent value="warranty" className="mt-4">
          <ConsolePanel className="p-0">
            {(warranty ?? []).length === 0 ? (
              <div className="p-5"><ConsoleEmpty icon={<Pencil className="size-8" />} title="暂无售后工单" /></div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>编号</TableHead><TableHead>用户</TableHead><TableHead>类型</TableHead>
                    <TableHead>描述</TableHead><TableHead>状态</TableHead><TableHead>时间</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {(warranty ?? []).map((c) => (
                    <TableRow key={c.id}>
                      <TableCell className="font-mono text-xs text-[var(--cx-muted)]">#{c.id}</TableCell>
                      <TableCell className="text-xs text-[var(--cx-text)]">{c.carx_email}</TableCell>
                      <TableCell><Badge variant="outline" className="border-[var(--cx-line)] text-[var(--cx-muted)]">{warrantyTypeLabel[c.claim_type]}</Badge></TableCell>
                      <TableCell className="max-w-48 truncate text-xs text-[var(--cx-muted)]">{c.note || "—"}</TableCell>
                      <TableCell>
                        <Select value={c.status} onValueChange={(v) => warrantyUpdate.mutate({ id: c.id, status: v as WarrantyStatus })}>
                          <SelectTrigger className="h-8 w-28 border-[var(--cx-line)] bg-[var(--cx-panel)] text-[var(--cx-text)]"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {(Object.keys(warrantyStatusMeta) as WarrantyStatus[]).map((s) => (
                              <SelectItem key={s} value={s}>{warrantyStatusMeta[s].label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell className="text-xs text-[var(--cx-muted)]">{formatDateTime(c.created_at)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </ConsolePanel>
        </TabsContent>
      </Tabs>

      {/* 商品编辑弹窗 */}
      <Dialog open={productOpen} onOpenChange={(o) => { if (!o) { setProductOpen(false); setEditProduct(null); } }}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editProduct ? "编辑商品" : "新建商品"}</DialogTitle></DialogHeader>
          <div className="flex flex-col gap-3">
            <div className="flex flex-col gap-1.5"><Label>名称</Label><Input value={pForm.name} onChange={(e) => setPForm({ ...pForm, name: e.target.value })} /></div>
            <div className="flex flex-col gap-1.5"><Label>描述</Label><Input value={pForm.description} onChange={(e) => setPForm({ ...pForm, description: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="flex flex-col gap-1.5"><Label>售价 (元)</Label><Input type="number" value={pForm.base_price} onChange={(e) => setPForm({ ...pForm, base_price: Number(e.target.value) })} /></div>
              <div className="flex flex-col gap-1.5"><Label>结算成本</Label><Input type="number" value={pForm.settlement_cost} onChange={(e) => setPForm({ ...pForm, settlement_cost: Number(e.target.value) })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="flex flex-col gap-1.5"><Label>保修天数</Label><Input type="number" value={pForm.warranty_days} onChange={(e) => setPForm({ ...pForm, warranty_days: Number(e.target.value) })} /></div>
              <div className="flex flex-col gap-1.5"><Label>VIP 天数</Label><Input type="number" value={pForm.vip_days} onChange={(e) => setPForm({ ...pForm, vip_days: Number(e.target.value) })} /></div>
            </div>
            <div className="flex items-center justify-between rounded-[8px] border border-[var(--cx-line)] p-3">
              <Label>赠送 VIP</Label><Switch checked={pForm.grants_vip} onCheckedChange={(v) => setPForm({ ...pForm, grants_vip: v })} />
            </div>
            <div className="flex items-center justify-between rounded-[8px] border border-[var(--cx-line)] p-3">
              <Label>上架销售</Label><Switch checked={pForm.is_active} onCheckedChange={(v) => setPForm({ ...pForm, is_active: v })} />
            </div>
          </div>
          <DialogFooter>
            <Button
              className="bg-[var(--cx-red)] text-white hover:bg-[var(--cx-red)]/90"
              disabled={productSave.isPending}
              onClick={() => {
                if (!pForm.name) { toast.error("请输入名称"); return; }
                productSave.mutate({ id: editProduct?.id, body: { ...pForm, delivery_label: pForm.description } });
              }}
            >保存</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 卡密批次弹窗 */}
      <Dialog open={batchOpen} onOpenChange={setBatchOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>生成卡密批次</DialogTitle></DialogHeader>
          <div className="flex flex-col gap-3">
            <div className="flex flex-col gap-1.5"><Label>批次名</Label><Input value={batchName} onChange={(e) => setBatchName(e.target.value)} placeholder="批次-001" /></div>
            <div className="flex flex-col gap-1.5"><Label>卡密类型</Label>
              <Select value={batchSku} onValueChange={setBatchSku}>
                <SelectTrigger><SelectValue placeholder="选择类型" /></SelectTrigger>
                <SelectContent>{(skus ?? []).map((s) => <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="flex flex-col gap-1.5"><Label>数量</Label><Input type="number" value={batchQty} onChange={(e) => setBatchQty(Number(e.target.value))} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBatchOpen(false)}>取消</Button>
            <Button
              className="bg-[var(--cx-red)] text-white hover:bg-[var(--cx-red)]/90"
              disabled={batchCreate.isPending}
              onClick={() => {
                if (!batchName || !batchSku) { toast.error("请填写批次名并选择类型"); return; }
                batchCreate.mutate({ batch_name: batchName, sku_id: Number(batchSku), quantity: batchQty });
              }}
            >生成</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 成品号档位弹窗 */}
      <Dialog open={profileOpen} onOpenChange={setProfileOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>新建成品号档位</DialogTitle></DialogHeader>
          <div className="flex flex-col gap-3">
            <div className="flex flex-col gap-1.5"><Label>档位卡密代码</Label><Input value={fForm.code} onChange={(e) => setFForm({ ...fForm, code: e.target.value })} placeholder="FA-STD-003" /></div>
            <div className="flex flex-col gap-1.5"><Label>名称</Label><Input value={fForm.name} onChange={(e) => setFForm({ ...fForm, name: e.target.value })} placeholder="满级成品号" /></div>
            <div className="flex flex-col gap-1.5"><Label>描述</Label><Input value={fForm.description} onChange={(e) => setFForm({ ...fForm, description: e.target.value })} /></div>
            <div className="flex flex-col gap-1.5"><Label>默认保修天数</Label><Input type="number" value={fForm.warranty_days_default} onChange={(e) => setFForm({ ...fForm, warranty_days_default: Number(e.target.value) })} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setProfileOpen(false)}>取消</Button>
            <Button
              className="bg-[var(--cx-red)] text-white hover:bg-[var(--cx-red)]/90"
              disabled={profileCreate.isPending}
              onClick={() => {
                if (!fForm.code || !fForm.name) { toast.error("请填写代码与名称"); return; }
                profileCreate.mutate(fForm);
              }}
            >创建</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
