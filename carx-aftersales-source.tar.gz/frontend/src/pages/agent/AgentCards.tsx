import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Ticket, Plus } from "phosphor-react";
import {
  getAgentCardBatches,
  agentCreateCardBatch,
  getCardSkus,
  getErrorMessage,
} from "@/lib/api";
import { formatDateTime } from "@/lib/format";
import { ConsoleHeader, ConsolePanel, ConsoleEmpty } from "@/components/ConsoleKit";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";

export default function AgentCards() {
  const queryClient = useQueryClient();
  const { data, isLoading } = useQuery({ queryKey: ["agent-card-batches"], queryFn: getAgentCardBatches });
  const { data: skus } = useQuery({ queryKey: ["card-skus"], queryFn: getCardSkus });
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [skuId, setSkuId] = useState("");
  const [qty, setQty] = useState(10);
  const [generated, setGenerated] = useState<string[]>([]);

  const createMutation = useMutation({
    mutationFn: agentCreateCardBatch,
    onSuccess: (r) => {
      toast.success(`已生成 ${r.codes.length} 张卡密`);
      setGenerated(r.codes.map((c) => c.code));
      setOpen(false); setName("");
      queryClient.invalidateQueries({ queryKey: ["agent-card-batches"] });
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  return (
    <div>
      <ConsoleHeader
        title="代销卡密"
        description="批量生成卡密用于线下代销"
        actions={
          <Button className="bg-[var(--cx-red)] text-white hover:bg-[var(--cx-red)]/90" onClick={() => setOpen(true)}>
            <Plus className="size-4" /> 生成批次
          </Button>
        }
      />

      {generated.length > 0 && (
        <ConsolePanel className="mb-5">
          <div className="mb-2 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-[var(--cx-text)]">本次生成的卡密</h3>
            <Button variant="ghost" size="sm" onClick={() => setGenerated([])}>清空</Button>
          </div>
          <div className="grid max-h-48 gap-1 overflow-y-auto sm:grid-cols-2">
            {generated.map((c) => (
              <code key={c} className="rounded bg-[var(--cx-panel-soft)] px-2 py-1 font-mono text-xs text-[var(--cx-green)]">{c}</code>
            ))}
          </div>
        </ConsolePanel>
      )}

      <ConsolePanel className="p-0">
        {isLoading ? (
          <div className="py-16 text-center text-sm text-[var(--cx-muted)]">正在加载...</div>
        ) : (data?.items ?? []).length === 0 ? (
          <div className="p-5"><ConsoleEmpty icon={<Ticket className="size-8" />} title="暂无卡密批次" description="点击右上角「生成批次」创建代销卡密" /></div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>批次名</TableHead>
                <TableHead>类型</TableHead>
                <TableHead>数量</TableHead>
                <TableHead>备注</TableHead>
                <TableHead>创建时间</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(data?.items ?? []).map((b) => (
                <TableRow key={b.id}>
                  <TableCell className="font-medium text-[var(--cx-text)]">{b.batch_name}</TableCell>
                  <TableCell className="text-[var(--cx-muted)]">{skus?.find((s) => s.id === b.sku_id)?.name ?? b.sku_id}</TableCell>
                  <TableCell className="text-[var(--cx-text)]">{b.quantity}</TableCell>
                  <TableCell className="text-xs text-[var(--cx-muted)]">{b.note || "—"}</TableCell>
                  <TableCell className="text-xs text-[var(--cx-muted)]">{formatDateTime(b.created_at)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </ConsolePanel>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>生成卡密批次</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-3">
            <div className="flex flex-col gap-1.5">
              <Label>批次名</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="批次-001" />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>卡密类型</Label>
              <Select value={skuId} onValueChange={setSkuId}>
                <SelectTrigger><SelectValue placeholder="选择类型" /></SelectTrigger>
                <SelectContent>
                  {(skus ?? []).map((s) => (
                    <SelectItem key={s.id} value={String(s.id)}>{s.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>数量</Label>
              <Input type="number" value={qty} onChange={(e) => setQty(Number(e.target.value))} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>取消</Button>
            <Button
              className="bg-[var(--cx-red)] text-white hover:bg-[var(--cx-red)]/90"
              disabled={createMutation.isPending}
              onClick={() => {
                if (!name || !skuId) { toast.error("请填写批次名并选择类型"); return; }
                createMutation.mutate({ batch_name: name, sku_id: Number(skuId), quantity: qty });
              }}
            >
              生成
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
