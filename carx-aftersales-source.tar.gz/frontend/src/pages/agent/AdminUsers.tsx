import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Users, Plus, Pencil, Trash } from "phosphor-react";
import {
  getAdminUsers, createAdminUser, updateAdminUser, deleteAdminUser, getErrorMessage, type User,
} from "@/lib/api";
import { formatDateTime } from "@/lib/format";
import { ConsoleHeader, ConsolePanel, ConsoleEmpty } from "@/components/ConsoleKit";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";

const roleLabel = { user: "普通用户", agent: "代理用户", admin: "管理员" } as const;
const statusLabel = { active: "正常", disabled: "禁用", banned: "封禁" } as const;

export default function AdminUsers() {
  const queryClient = useQueryClient();
  const { data: users, isLoading } = useQuery({ queryKey: ["admin-users"], queryFn: getAdminUsers });
  const [editing, setEditing] = useState<User | null>(null);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({ username: "", email: "", password: "", role: "user" as User["role"], status: "active" as User["status"], credit_score: 100, single_car_points: 0 });

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ["admin-users"] });
  const createMutation = useMutation({
    mutationFn: createAdminUser,
    onSuccess: () => { toast.success("用户已创建"); setCreating(false); invalidate(); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });
  const updateMutation = useMutation({
    mutationFn: ({ id, body }: { id: number; body: Parameters<typeof updateAdminUser>[1] }) => updateAdminUser(id, body),
    onSuccess: () => { toast.success("已保存"); setEditing(null); invalidate(); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });
  const deleteMutation = useMutation({
    mutationFn: deleteAdminUser,
    onSuccess: () => { toast.success("已删除"); invalidate(); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const openCreate = () => { setForm({ username: "", email: "", password: "", role: "user", status: "active", credit_score: 100, single_car_points: 0 }); setCreating(true); };
  const openEdit = (u: User) => { setForm({ username: u.username, email: u.email, password: "", role: u.role, status: u.status, credit_score: u.credit_score, single_car_points: u.single_car_points }); setEditing(u); };

  return (
    <div>
      <ConsoleHeader
        title="用户管理"
        description="管理客户资料、积分、VIP、绑定状态"
        actions={<Button className="bg-[var(--cx-red)] text-white hover:bg-[var(--cx-red)]/90" onClick={openCreate}><Plus className="size-4" /> 新建用户</Button>}
      />
      <ConsolePanel className="p-0">
        {isLoading ? (
          <div className="py-16 text-center text-sm text-[var(--cx-muted)]">正在加载...</div>
        ) : (users ?? []).length === 0 ? (
          <div className="p-5"><ConsoleEmpty icon={<Users className="size-8" />} title="暂无用户" /></div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead><TableHead>账号</TableHead><TableHead>角色</TableHead>
                <TableHead>状态</TableHead><TableHead>积分</TableHead><TableHead>注册时间</TableHead>
                <TableHead className="text-right">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(users ?? []).map((u) => (
                <TableRow key={u.id}>
                  <TableCell className="font-mono text-xs text-[var(--cx-muted)]">{u.id}</TableCell>
                  <TableCell className="font-medium text-[var(--cx-text)]">{u.username}</TableCell>
                  <TableCell><Badge variant="outline" className="border-[var(--cx-line)] text-[var(--cx-muted)]">{roleLabel[u.role]}</Badge></TableCell>
                  <TableCell>
                    <Badge variant="outline" className={u.status === "active" ? "border-emerald-500/30 text-[var(--cx-green)]" : "border-[var(--cx-red)]/40 text-[var(--cx-red)]"}>
                      {statusLabel[u.status]}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-[var(--cx-text)]">{u.single_car_points}</TableCell>
                  <TableCell className="text-xs text-[var(--cx-muted)]">{formatDateTime(u.createdAt)}</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" className="text-[var(--cx-muted)]" onClick={() => openEdit(u)}><Pencil className="size-4" /></Button>
                    <Button variant="ghost" size="icon" className="text-[var(--cx-red)]" onClick={() => deleteMutation.mutate(u.id)}><Trash className="size-4" /></Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </ConsolePanel>

      <Dialog open={creating || !!editing} onOpenChange={(o) => { if (!o) { setCreating(false); setEditing(null); } }}>
        <DialogContent>
          <DialogHeader><DialogTitle>{creating ? "新建用户" : "编辑用户"}</DialogTitle></DialogHeader>
          <div className="flex flex-col gap-3">
            <div className="flex flex-col gap-1.5"><Label>账号</Label><Input value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} /></div>
            {creating && <div className="flex flex-col gap-1.5"><Label>邮箱</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>}
            <div className="flex flex-col gap-1.5"><Label>{creating ? "密码" : "重置密码（留空不改）"}</Label><Input type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div className="flex flex-col gap-1.5"><Label>角色</Label>
                <Select value={form.role} onValueChange={(v) => setForm({ ...form, role: v as User["role"] })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="user">普通用户</SelectItem><SelectItem value="agent">代理用户</SelectItem><SelectItem value="admin">管理员</SelectItem></SelectContent>
                </Select>
              </div>
              <div className="flex flex-col gap-1.5"><Label>状态</Label>
                <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v as User["status"] })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="active">正常</SelectItem><SelectItem value="disabled">禁用</SelectItem><SelectItem value="banned">封禁</SelectItem></SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="flex flex-col gap-1.5"><Label>信用分</Label><Input type="number" value={form.credit_score} onChange={(e) => setForm({ ...form, credit_score: Number(e.target.value) })} /></div>
              <div className="flex flex-col gap-1.5"><Label>积分</Label><Input type="number" value={form.single_car_points} onChange={(e) => setForm({ ...form, single_car_points: Number(e.target.value) })} /></div>
            </div>
          </div>
          <DialogFooter>
            <Button
              className="bg-[var(--cx-red)] text-white hover:bg-[var(--cx-red)]/90"
              disabled={createMutation.isPending || updateMutation.isPending}
              onClick={() => {
                if (creating) {
                  if (!form.username || !form.email || !form.password) { toast.error("请填写账号、邮箱与密码"); return; }
                  createMutation.mutate({ username: form.username, email: form.email, password: form.password, role: form.role });
                } else if (editing) {
                  const body: Parameters<typeof updateAdminUser>[1] = { username: form.username, role: form.role, status: form.status, credit_score: form.credit_score, single_car_points: form.single_car_points };
                  if (form.password) body.password = form.password;
                  updateMutation.mutate({ id: editing.id, body });
                }
              }}
            >保存</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
