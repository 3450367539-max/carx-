import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Car, MagnifyingGlass } from "phosphor-react";
import { getAgentSingleCars, getAgentPlatformCars } from "@/lib/api";
import { formatCurrency } from "@/lib/format";
import { ConsoleHeader, ConsoleEmpty } from "@/components/ConsoleKit";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export default function AgentSingleCar() {
  const [category, setCategory] = useState("all");
  const [search, setSearch] = useState("");
  const { data: cars, isLoading } = useQuery({ queryKey: ["agent-single-cars"], queryFn: getAgentSingleCars });
  const { data: platformCars } = useQuery({ queryKey: ["agent-platform-cars"], queryFn: getAgentPlatformCars });

  const categories = useMemo(() => Array.from(new Set((cars ?? []).map((c) => c.category))), [cars]);
  const filtered = useMemo(() => {
    let list = cars ?? [];
    if (category !== "all") list = list.filter((c) => c.category === category);
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      list = list.filter((c) => c.name.toLowerCase().includes(q) || c.model.toLowerCase().includes(q));
    }
    return list;
  }, [cars, category, search]);

  return (
    <div>
      <ConsoleHeader title="单车零售专区" description="游戏内车辆单品零售目录" />

      {/* 平台车 */}
      {(platformCars ?? []).length > 0 && (
        <div className="mb-5">
          <h3 className="mb-3 text-sm font-semibold text-[var(--cx-text)]">平台车辆</h3>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {(platformCars ?? []).map((c) => (
              <div key={c.id} className="console-panel flex items-center justify-between p-4">
                <div>
                  <div className="text-sm font-semibold text-[var(--cx-text)]">{c.name}</div>
                  <div className="text-xs text-[var(--cx-muted)]">{c.description}</div>
                </div>
                <span className="text-sm font-bold text-[var(--cx-red)]">{formatCurrency(c.price)}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 筛选 */}
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setCategory("all")}
            className={cn("rounded-full border px-3 py-1 text-xs font-medium transition",
              category === "all" ? "border-[var(--cx-red)] bg-[var(--cx-red)] text-white" : "border-[var(--cx-line)] text-[var(--cx-muted)] hover:text-[var(--cx-text)]")}
          >
            全部
          </button>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={cn("rounded-full border px-3 py-1 text-xs font-medium transition",
                category === cat ? "border-[var(--cx-red)] bg-[var(--cx-red)] text-white" : "border-[var(--cx-line)] text-[var(--cx-muted)] hover:text-[var(--cx-text)]")}
            >
              {cat}
            </button>
          ))}
        </div>
        <div className="relative ml-auto">
          <MagnifyingGlass className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-[var(--cx-muted)]" />
          <Input
            placeholder="搜索车辆名称 / 型号"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-56 border-[var(--cx-line)] bg-[var(--cx-panel)] pl-9 text-[var(--cx-text)]"
          />
        </div>
      </div>

      {/* 车辆网格 */}
      {isLoading ? (
        <div className="py-16 text-center text-sm text-[var(--cx-muted)]">正在加载...</div>
      ) : filtered.length === 0 ? (
        <ConsoleEmpty icon={<Car className="size-8" />} title="暂无车辆" />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {filtered.map((c) => (
            <div key={c.id} className="console-panel overflow-hidden">
              <div className="flex h-28 items-center justify-center bg-[var(--cx-panel-soft)]">
                {c.image_url ? (
                  <img src={c.image_url} alt={c.name} className="h-full w-full object-cover" />
                ) : (
                  <Car className="size-10 text-[var(--cx-muted)]/30" />
                )}
              </div>
              <div className="p-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-semibold text-[var(--cx-text)]">{c.name}</span>
                  <Badge variant="outline" className="border-[var(--cx-line)] text-[var(--cx-muted)]">{c.category}</Badge>
                </div>
                <div className="mt-0.5 font-mono text-xs text-[var(--cx-muted)]">{c.file}</div>
                <div className="mt-2 text-sm font-bold text-[var(--cx-red)]">{formatCurrency(c.price)}</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
