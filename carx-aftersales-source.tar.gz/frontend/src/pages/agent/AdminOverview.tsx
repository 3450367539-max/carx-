import { useQuery } from "@tanstack/react-query";
import { Users, UsersThree, Receipt, Wallet, Crown, Ticket, ShieldCheck, Coins } from "phosphor-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";
import { getAdminStats } from "@/lib/api";
import { orderStatusMeta } from "@/lib/status";
import { formatCurrency, formatDateTime } from "@/lib/format";
import { ConsoleHeader, ConsolePanel, ConsoleStat } from "@/components/ConsoleKit";
import { Badge } from "@/components/ui/badge";

export default function AdminOverview() {
  const { data: stats, isLoading } = useQuery({ queryKey: ["admin-stats"], queryFn: getAdminStats });

  if (isLoading || !stats) {
    return <div className="py-16 text-center text-sm text-[var(--cx-muted)]">正在加载...</div>;
  }

  return (
    <div>
      <ConsoleHeader title="数据总览" description="全局业务数据概览与系统运行状态" />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <ConsoleStat label="总营收" value={formatCurrency(stats.revenue)} icon={<Wallet className="size-5" />} tone="red" />
        <ConsoleStat label="订单总数" value={stats.totalOrders} icon={<Receipt className="size-5" />} tone="blue" />
        <ConsoleStat label="会员用户" value={stats.totalUsers} icon={<Users className="size-5" />} tone="green" />
        <ConsoleStat label="代理商" value={stats.totalAgents} icon={<UsersThree className="size-5" />} tone="amber" />
        <ConsoleStat label="VIP 用户" value={stats.vipUsers} icon={<Crown className="size-5" />} tone="amber" />
        <ConsoleStat label="可用卡密" value={stats.activeCards} icon={<Ticket className="size-5" />} tone="blue" hint={`已使用 ${stats.redeemedCards}`} />
        <ConsoleStat label="待处理售后" value={stats.pendingWarranty} icon={<ShieldCheck className="size-5" />} tone="red" />
        <ConsoleStat label="客户端授权" value={stats.clientLicenses} icon={<Coins className="size-5" />} tone="green" />
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-3">
        <ConsolePanel className="lg:col-span-2">
          <h3 className="mb-4 text-sm font-semibold text-[var(--cx-text)]">近 7 日订单与营收</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={stats.trend} margin={{ left: 0, right: 8, top: 8 }}>
                <defs>
                  <linearGradient id="adminRev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--cx-red)" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="var(--cx-red)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--cx-line)" />
                <XAxis dataKey="date" fontSize={12} tickLine={false} axisLine={false} stroke="var(--cx-muted)" />
                <YAxis fontSize={12} tickLine={false} axisLine={false} stroke="var(--cx-muted)" />
                <Tooltip contentStyle={{ background: "var(--cx-panel-strong)", border: "1px solid var(--cx-line)", borderRadius: 8, fontSize: 12, color: "var(--cx-text)" }} />
                <Area type="monotone" dataKey="revenue" stroke="var(--cx-red)" fill="url(#adminRev)" strokeWidth={2} name="营收" />
                <Area type="monotone" dataKey="orders" stroke="var(--cx-blue)" fill="none" strokeWidth={2} name="订单" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </ConsolePanel>

        <ConsolePanel>
          <h3 className="mb-3 text-sm font-semibold text-[var(--cx-text)]">最新订单</h3>
          <div className="flex flex-col divide-y divide-[var(--cx-line)]">
            {stats.recentOrders.length === 0 && (
              <div className="py-8 text-center text-xs text-[var(--cx-muted)]">暂无订单</div>
            )}
            {stats.recentOrders.map((o) => (
              <div key={o.order_id} className="flex items-center justify-between gap-2 py-2.5">
                <div className="min-w-0">
                  <div className="truncate text-sm font-medium text-[var(--cx-text)]">{o.product_name}</div>
                  <div className="text-xs text-[var(--cx-muted)]">{formatDateTime(o.created_at)}</div>
                </div>
                <div className="flex shrink-0 flex-col items-end gap-1">
                  <span className="text-xs font-semibold text-[var(--cx-text)]">{formatCurrency(o.selling_price)}</span>
                  <Badge variant="outline" className={orderStatusMeta[o.status].className}>{orderStatusMeta[o.status].label}</Badge>
                </div>
              </div>
            ))}
          </div>
        </ConsolePanel>
      </div>
    </div>
  );
}
