import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Storefront, Car, Plus, Pencil, Trash } from "phosphor-react";
import {
  getAdminPointsProducts, createPointsProduct, updatePointsProduct, deletePointsProduct,
  getAdminPointsCars, createPointsCar, updatePointsCar, deletePointsCar,
  getErrorMessage, type PointsProduct, type PointsCar,
} from "@/lib/api";
import { ConsoleHeader, ConsolePanel, ConsoleStat, ConsoleEmpty } from "@/components/ConsoleKit";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";

const carCategories = ["银币车", "金币车", "付费车", "人机车", "隐藏车", "通行证车", "涂装车"];

export default function AdminPoints() {
  const queryClient = useQueryClient();
  const { data: products } = useQuery({ queryKey: ["admin-points-products"], queryFn: getAdminPointsProducts });
  const { data: cars } = useQuery({ queryKey: ["admin-points-cars"], queryFn: getAdminPointsCars });

  const [prodDialog, setProdDialog] = useState(false);
  const [editingProd, setEditingProd] = useState<PointsProduct | null>(null);
  const [prodForm, setProdForm] = useState({ name: "", description: "", category: "平台商品", price: 0, delivery_label: "", package_summary: "" });

  const [carDialog, setCarDialog] = useState(false);
  const [editingCar, setEditingCar] = useState<PointsCar | null>(null);
  const [carForm, setCarForm] = useState({ car_id: "", name: "", model: "", category: "银币车", price: 0, image_url: "" });

  const refresh = () => {
    queryClient.invalidateQueries({ queryKey: ["admin-points-products"] });
    queryClient.invalidateQueries({ queryKey: ["admin-points-cars"] });
  };

  const saveProdMut = useMutation({
    mutationFn: () => editingProd
      ? updatePointsProduct(Number(editingProd.id), prodForm)
      : createPointsProduct({ ...prodForm, icon: null, color: null, image_url: null, product_id: null }),
    onSuccess: () => { toast.success(editingProd ? "商品已更新" : "商品已创建"); setProdDialog(false); setEditingProd(null); refresh(); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const deleteProdMut = useMutation({
    mutationFn: (id: number) => deletePointsProduct(id),
    onSuccess: () => { toast.success("商品已删除"); refresh(); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const saveCarMut = useMutation({
    mutationFn: () => editingCar
      ? updatePointsCar(Number(editingCar.id), { ...carForm, image_url: carForm.image_url || null })
      : createPointsCar({ ...carForm, image_url: carForm.image_url || null }),
    onSuccess: () => { toast.success(editingCar ? "车辆已更新" : "车辆已创建"); setCarDialog(false); setEditingCar(null); refresh(); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const deleteCarMut = useMutation({
    mutationFn: (id: number) => deletePointsCar(id),
    onSuccess: () => { toast.success("车辆已删除"); refresh(); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  return (
    <div>
      <ConsoleHeader title="积分商城管理" description="维护积分兑换的商品与车辆，调整积分定价" />

      <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <ConsoleStat label="平台商品" value={products?.length ?? 0} />
        <ConsoleStat label="兑换车辆" value={cars?.length ?? 0} />
        <ConsoleStat label="最低车价" value={cars && cars.length ? `${Math.min(...cars.map((c) => c.price))} 分` : "—"} tone="red" />
        <ConsoleStat label="最高车价" value={cars && cars.length ? `${Math.max(...cars.map((c) => c.price))} 分` : "—"} />
      </div>

      <Tabs defaultValue="cars">
        <TabsList className="mb-4">
          <TabsTrigger value="cars">车辆兑换</TabsTrigger>
          <TabsTrigger value="products">平台商品</TabsTrigger>
        </TabsList>

        <TabsContent value="cars">
          <ConsolePanel>
            <div className="mb-4 flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm font-semibold text-[var(--cx-text)]">
                <Car className="size-4" /> 车辆列表
              </div>
              <Button size="sm" onClick={() => { setEditingCar(null); setCarForm({ car_id: "", name: "", model: "", category: "银币车", price: 0, image_url: "" }); setCarDialog(true); }}>
                <Plus className="size-4" /> 新增车辆
              </Button>
            </div>
            {!cars || cars.length === 0 ? (
              <ConsoleEmpty title="暂无车辆" />
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>车辆</TableHead>
                    <TableHead>游戏内 ID</TableHead>
                    <TableHead>分类</TableHead>
                    <TableHead>积分价</TableHead>
                    <TableHead className="text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {cars.map((c) => (
                    <TableRow key={c.id}>
                      <TableCell>
                        <div className="font-medium text-[var(--cx-text)]">{c.name}</div>
                        <div className="text-xs text-[var(--cx-muted)]">{c.model}</div>
                      </TableCell>
                      <TableCell className="font-mono text-xs">{c.car_id}</TableCell>
                      <TableCell><Badge variant="outline">{c.category}</Badge></TableCell>
                      <TableCell className="font-semibold text-[var(--cx-text)]">{c.price} 分</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          <Button size="icon" variant="ghost" onClick={() => {
                            setEditingCar(c);
                            setCarForm({ car_id: c.car_id, name: c.name, model: c.model, category: c.category, price: c.price, image_url: c.image_url ?? "" });
                            setCarDialog(true);
                          }}><Pencil className="size-4" /></Button>
                          <Button size="icon" variant="ghost" onClick={() => { if (confirm(`确定删除车辆「${c.name}」？`)) deleteCarMut.mutate(Number(c.id)); }}>
                            <Trash className="size-4 text-red-400" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </ConsolePanel>
        </TabsContent>

        <TabsContent value="products">
          <ConsolePanel>
            <div className="mb-4 flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm font-semibold text-[var(--cx-text)]">
                <Storefront className="size-4" /> 平台商品
              </div>
              <Button size="sm" onClick={() => { setEditingProd(null); setProdForm({ name: "", description: "", category: "平台商品", price: 0, delivery_label: "", package_summary: "" }); setProdDialog(true); }}>
                <Plus className="size-4" /> 新增商品
              </Button>
            </div>
            {!products || products.length === 0 ? (
              <ConsoleEmpty title="暂无平台商品" />
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>商品</TableHead>
                    <TableHead>分类</TableHead>
                    <TableHead>积分价</TableHead>
                    <TableHead className="text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {products.map((p) => (
                    <TableRow key={p.id}>
                      <TableCell>
                        <div className="font-medium text-[var(--cx-text)]">{p.name}</div>
                        <div className="max-w-[280px] truncate text-xs text-[var(--cx-muted)]">{p.description || p.package_summary || "—"}</div>
                      </TableCell>
                      <TableCell><Badge variant="outline">{p.category}</Badge></TableCell>
                      <TableCell className="font-semibold text-[var(--cx-text)]">{p.price} 分</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          <Button size="icon" variant="ghost" onClick={() => {
                            setEditingProd(p);
                            setProdForm({ name: p.name, description: p.description, category: p.category, price: p.price, delivery_label: p.delivery_label, package_summary: p.package_summary });
                            setProdDialog(true);
                          }}><Pencil className="size-4" /></Button>
                          <Button size="icon" variant="ghost" onClick={() => { if (confirm(`确定删除商品「${p.name}」？`)) deleteProdMut.mutate(Number(p.id)); }}>
                            <Trash className="size-4 text-red-400" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </ConsolePanel>
        </TabsContent>
      </Tabs>

      {/* 车辆编辑 */}
      <Dialog open={carDialog} onOpenChange={setCarDialog}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editingCar ? "编辑车辆" : "新增车辆"}</DialogTitle></DialogHeader>
          <div className="flex flex-col gap-3">
            <div className="grid grid-cols-2 gap-3">
              <div className="flex flex-col gap-1.5">
                <Label>车辆名称</Label>
                <Input value={carForm.name} onChange={(e) => setCarForm({ ...carForm, name: e.target.value })} placeholder="如：GT-R" />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label>型号标识</Label>
                <Input value={carForm.model} onChange={(e) => setCarForm({ ...carForm, model: e.target.value })} />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label>游戏内 ID</Label>
                <Input value={carForm.car_id} onChange={(e) => setCarForm({ ...carForm, car_id: e.target.value })} />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label>积分价</Label>
                <Input type="number" value={carForm.price} onChange={(e) => setCarForm({ ...carForm, price: Number(e.target.value) })} />
              </div>
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>分类</Label>
              <Select value={carForm.category} onValueChange={(v) => setCarForm({ ...carForm, category: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {carCategories.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>展示图链接（可选）</Label>
              <Input value={carForm.image_url} onChange={(e) => setCarForm({ ...carForm, image_url: e.target.value })} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCarDialog(false)}>取消</Button>
            <Button disabled={!carForm.name || !carForm.car_id || carForm.price <= 0 || saveCarMut.isPending} onClick={() => saveCarMut.mutate()}>保存</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 商品编辑 */}
      <Dialog open={prodDialog} onOpenChange={setProdDialog}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editingProd ? "编辑平台商品" : "新增平台商品"}</DialogTitle></DialogHeader>
          <div className="flex flex-col gap-3">
            <div className="flex flex-col gap-1.5">
              <Label>商品名称</Label>
              <Input value={prodForm.name} onChange={(e) => setProdForm({ ...prodForm, name: e.target.value })} />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>描述</Label>
              <Input value={prodForm.description} onChange={(e) => setProdForm({ ...prodForm, description: e.target.value })} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="flex flex-col gap-1.5">
                <Label>分类</Label>
                <Input value={prodForm.category} onChange={(e) => setProdForm({ ...prodForm, category: e.target.value })} />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label>积分价</Label>
                <Input type="number" value={prodForm.price} onChange={(e) => setProdForm({ ...prodForm, price: Number(e.target.value) })} />
              </div>
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>发货说明</Label>
              <Input value={prodForm.delivery_label} onChange={(e) => setProdForm({ ...prodForm, delivery_label: e.target.value })} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setProdDialog(false)}>取消</Button>
            <Button disabled={!prodForm.name || prodForm.price <= 0 || saveProdMut.isPending} onClick={() => saveProdMut.mutate()}>保存</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
