import { useQuery } from "@tanstack/react-query";
import { Tag } from "phosphor-react";
import { getAgentPrices } from "@/lib/api";
import { formatCurrency } from "@/lib/format";
import { ConsoleHeader, ConsolePanel, ConsoleEmpty } from "@/components/ConsoleKit";
import { Badge } from "@/components/ui/badge";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";

export default function AgentPrices() {
  const { data: prices, isLoading } = useQuery({ queryKey: ["agent-prices"], queryFn: getAgentPrices });

  return (
    <div>
      <ConsoleHeader title="商品价格表" description="查看各商品的底价、售价与利润空间" />

      <ConsolePanel className="p-0">
        {isLoading ? (
          <div className="py-16 text-center text-sm text-[var(--cx-muted)]">正在加载...</div>
        ) : (prices ?? []).length === 0 ? (
          <div className="p-5"><ConsoleEmpty icon={<Tag className="size-8" />} title="暂无商品" /></div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>商品</TableHead>
                <TableHead>底价</TableHead>
                <TableHead>我的售价</TableHead>
                <TableHead>结算成本</TableHead>
                <TableHead>利润空间</TableHead>
                <TableHead>定价</TableHead>
                <TableHead>成品号交付</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(prices ?? []).map((p) => (
                <TableRow key={p.product_id}>
                  <TableCell className="font-medium text-[var(--cx-text)]">{p.product_name}</TableCell>
                  <TableCell className="text-[var(--cx-muted)]">{formatCurrency(p.base_price)}</TableCell>
                  <TableCell className="font-semibold text-[var(--cx-text)]">{formatCurrency(p.agent_price)}</TableCell>
                  <TableCell className="text-[var(--cx-muted)]">{formatCurrency(p.settlement_cost)}</TableCell>
                  <TableCell className="font-semibold text-[var(--cx-green)]">{formatCurrency(p.income_space)}</TableCell>
                  <TableCell>
                    {p.has_custom_price ? (
                      <Badge variant="outline" className="border-[var(--cx-blue)]/40 text-[var(--cx-blue)]">自定义</Badge>
                    ) : (
                      <Badge variant="outline" className="text-[var(--cx-muted)]">默认</Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    {p.allow_white_account_delivery ? (
                      <Badge variant="outline" className="border-emerald-500/40 text-[var(--cx-green)]">支持</Badge>
                    ) : (
                      <span className="text-xs text-[var(--cx-muted)]">不支持</span>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </ConsolePanel>
    </div>
  );
}
