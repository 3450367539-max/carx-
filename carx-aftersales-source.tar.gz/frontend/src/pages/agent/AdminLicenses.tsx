import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { ShieldChevron, Key, Plus } from "phosphor-react";
import {
  getClientLicenseCodes, getClientLicenseOverview, generateClientLicense, updateClientLicense, getErrorMessage,
} from "@/lib/api";
import { licenseStatusMeta } from "@/lib/status";
import { formatDateTime } from "@/lib/format";
import { ConsoleHeader, ConsolePanel, ConsoleStat, ConsoleEmpty } from "@/components/ConsoleKit";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";

export default function AdminLicenses() {
  const queryClient = useQueryClient();
  const { data: overview } = useQuery({ queryKey: ["license-overview"], queryFn: getClientLicenseOverview });
  const { data: codes, isLoading } = useQuery({ queryKey: ["license-codes"], queryFn: getClientLicenseCodes });
  const [open, setOpen] = useState(false);
  const [kind, setKind] = useState<"version" | "feature">("feature");
  const [days, setDays] = useState(30);
  const [qty, setQty] = useState(10);

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["license-overview"] });
    queryClient.invalidateQueries({ queryKey: ["license-codes"] });
  };
  const genMutation = useMutation({
    mutationFn: generateClientLicense,
    onSuccess: (r) => { toast.success(`已生成 ${r.codes.length} 个 CDK`); setOpen(false); invalidate(); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });
  const statusMutation = useMutation({
    mutationFn: ({ id, status }: { id: number; status: "UNUSED" | "ACTIVATED" | "REVOKED" | "EXPIRED" }) => updateClientLicense(id, { status }),
    onSuccess: () => { toast.success("状态已更新"); invalidate(); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  return (
    <div>
      <ConsoleHeader
        title="客户端授权"
        description="分开管理版本卡密、功能月卡、客户剩余天数"
        actions={<Button className="bg-[var(--cx-red)] text-white hover:bg-[var(--cx-red)]/90" onClick={() => setOpen(true)}><Plus className="size-4" /> 生成 CDK</Button>}
      />

      <div className="mb-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <ConsoleStat label="版本卡密 · 可用" value={overview?.version_available ?? 0} icon={<Key className="size-5" />} tone="blue" />
        <ConsoleStat label="版本卡密 · 已激活" value={overview?.version_activated ?? 0} icon={<ShieldChevron className="size-5" />} tone="green" />
        <ConsoleStat label="功能月卡 · 可用" value={overview?.feature_available ?? 0} icon={<Key className="size-5" />} tone="amber" />
        <ConsoleStat label="功能月卡 · 已激活" value={overview?.feature_activated ?? 0} icon={<ShieldChevron className="size-5" />} tone="red" />
      </div>

      <ConsolePanel className="p-0">
        {isLoading ? (
          <div className="py-16 text-center text-sm text-[var(--cx-muted)]">正在加载...</div>
        ) : (codes ?? []).length === 0 ? (
          <div className="p-5"><ConsoleEmpty icon={<Key className="size-8" />} title="暂无 CDK" /></div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>CDK</TableHead><TableHead>类型</TableHead><TableHead>天数</TableHead>
                <TableHead>状态</TableHead><TableHead>激活人</TableHead><TableHead>创建时间</TableHead>
                <TableHead className="text-right">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(codes ?? []).map((c) => (
                <TableRow key={c.id}>
                  <TableCell className="font-mono text-xs text-[var(--cx-text)]">{c.code}</TableCell>
                  <TableCell><Badge variant="outline" className="border-[var(--cx-line)] text-[var(--cx-muted)]">{c.kind_label}</Badge></TableCell>
                  <TableCell className="text-[var(--cx-text)]">{c.days > 0 ? `${c.days} 天` : "—"}</TableCell>
                  <TableCell><Badge variant="outline" className={licenseStatusMeta[c.status].className}>{licenseStatusMeta[c.status].label}</Badge></TableCell>
                  <TableCell className="font-mono text-xs text-[var(--cx-muted)]">{c.activated_by ?? "—"}</TableCell>
                  <TableCell className="text-xs text-[var(--cx-muted)]">{formatDateTime(c.created_at)}</TableCell>
                  <TableCell className="text-right">
                    {c.status === "UNUSED" && (
                      <Button variant="ghost" size="sm" className="text-[var(--cx-red)]" onClick={() => statusMutation.mutate({ id: c.id, status: "REVOKED" })}>回收</Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </ConsolePanel>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>生成客户端授权 CDK</DialogTitle></DialogHeader>
          <div className="flex flex-col gap-3">
            <div className="flex flex-col gap-1.5"><Label>类型</Label>
              <Select value={kind} onValueChange={(v) => setKind(v as "version" | "feature")}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="version">版本卡密</SelectItem><SelectItem value="feature">功能月卡</SelectItem></SelectContent>
              </Select>
            </div>
            {kind === "feature" && (
              <div className="flex flex-col gap-1.5"><Label>有效天数</Label><Input type="number" value={days} onChange={(e) => setDays(Number(e.target.value))} /></div>
            )}
            <div className="flex flex-col gap-1.5"><Label>数量</Label><Input type="number" value={qty} onChange={(e) => setQty(Number(e.target.value))} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>取消</Button>
            <Button
              className="bg-[var(--cx-red)] text-white hover:bg-[var(--cx-red)]/90"
              disabled={genMutation.isPending}
              onClick={() => genMutation.mutate({ kind, days, quantity: qty })}
            >生成</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
