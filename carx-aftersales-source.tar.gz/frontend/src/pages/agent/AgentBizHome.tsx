import { useQuery } from "@tanstack/react-query";
import { Wallet, Hand, Receipt, TrendUp, ArrowsClockwise } from "phosphor-react";
import { getAgentDashboard, getAgentDebtLedger, getAgentSettlements } from "@/lib/api";
import { formatCurrency, formatDateTime } from "@/lib/format";
import { ConsoleHeader, ConsolePanel, ConsoleStat, ConsoleEmpty } from "@/components/ConsoleKit";
import { Badge } from "@/components/ui/badge";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";

export default function AgentBizHome() {
  const { data: stats } = useQuery({ queryKey: ["agent-dashboard"], queryFn: getAgentDashboard });
  const { data: ledger } = useQuery({ queryKey: ["agent-debt"], queryFn: getAgentDebtLedger });
  const { data: settlements } = useQuery({ queryKey: ["agent-settlements"], queryFn: getAgentSettlements });

  const debtPct = stats ? Math.min(100, Math.round((stats.amount_owed / stats.max_debt_limit) * 100)) : 0;

  return (
    <div>
      <ConsoleHeader title="经营概览" description="查看今日营业额、当前欠款和最近订单" />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <ConsoleStat label="今日净利" value={formatCurrency(stats?.today_net_profit ?? 0)} icon={<TrendUp className="size-5" />} tone="green" />
        <ConsoleStat label="本月净利" value={formatCurrency(stats?.month_net_profit ?? 0)} icon={<Wallet className="size-5" />} tone="blue" />
        <ConsoleStat label="当前欠款" value={formatCurrency(stats?.amount_owed ?? 0)} icon={<Hand className="size-5" />} tone="red" hint={`额度 ${formatCurrency(stats?.max_debt_limit ?? 0)}`} />
        <ConsoleStat label="今日订单" value={stats?.today_orders_count ?? 0} icon={<Receipt className="size-5" />} tone="amber" />
      </div>

      {/* 欠款额度条 */}
      <ConsolePanel className="mt-5">
        <div className="mb-2 flex items-center justify-between text-sm">
          <span className="font-medium text-[var(--cx-text)]">欠款授信额度</span>
          <span className="text-[var(--cx-muted)]">
            {formatCurrency(stats?.amount_owed ?? 0)} / {formatCurrency(stats?.max_debt_limit ?? 0)}
          </span>
        </div>
        <div className="h-2.5 overflow-hidden rounded-full bg-[var(--cx-panel-soft)]">
          <div
            className="h-full rounded-full bg-[var(--cx-red)] transition-all"
            style={{ width: `${debtPct}%` }}
          />
        </div>
        <div className="mt-2 text-xs text-[var(--cx-muted)]">
          剩余可用额度 {formatCurrency(stats?.remaining_debt_limit ?? 0)} · 已用 {debtPct}%
        </div>
      </ConsolePanel>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        {/* 欠款台账 */}
        <ConsolePanel>
          <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-[var(--cx-text)]">
            <Hand className="size-4 text-[var(--cx-red)]" /> 欠款台账
            <span className="text-xs font-normal text-[var(--cx-muted)]">共 {ledger?.summary.ledger_count ?? 0} 条</span>
          </h3>
          {(ledger?.items ?? []).length === 0 ? (
            <ConsoleEmpty icon={<Hand className="size-8" />} title="暂无台账记录" />
          ) : (
            <div className="flex flex-col divide-y divide-[var(--cx-line)]">
              {(ledger?.items ?? []).slice(0, 8).map((d) => (
                <div key={d.id} className="flex items-center justify-between gap-2 py-2.5">
                  <div className="min-w-0">
                    <div className="truncate text-sm text-[var(--cx-text)]">{d.order_product_name || d.entry_type_label}</div>
                    <div className="text-xs text-[var(--cx-muted)]">{d.customer_username}</div>
                  </div>
                  <div className="flex shrink-0 flex-col items-end">
                    <span className="text-sm font-semibold text-[var(--cx-red)]">+{formatCurrency(d.amount_delta)}</span>
                    <span className="text-xs text-[var(--cx-muted)]">余额 {formatCurrency(d.balance_after)}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </ConsolePanel>

        {/* 结算记录 */}
        <ConsolePanel>
          <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-[var(--cx-text)]">
            <ArrowsClockwise className="size-4 text-[var(--cx-green)]" /> 结算记录
          </h3>
          {(settlements ?? []).length === 0 ? (
            <ConsoleEmpty icon={<ArrowsClockwise className="size-8" />} title="暂无结算记录" />
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>结算金额</TableHead>
                  <TableHead>结算前欠款</TableHead>
                  <TableHead>结算后欠款</TableHead>
                  <TableHead>时间</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(settlements ?? []).slice(0, 8).map((s) => (
                  <TableRow key={s.id}>
                    <TableCell className="font-semibold text-[var(--cx-green)]">{formatCurrency(s.amount_paid)}</TableCell>
                    <TableCell className="text-[var(--cx-muted)]">{formatCurrency(s.previous_debt)}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className={s.new_debt === 0 ? "border-emerald-500/30 text-[var(--cx-green)]" : "text-[var(--cx-amber)]"}>
                        {formatCurrency(s.new_debt)}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs text-[var(--cx-muted)]">{formatDateTime(s.created_at)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </ConsolePanel>
      </div>
    </div>
  );
}
