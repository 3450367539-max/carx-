import { useQuery } from "@tanstack/react-query";
import { MagnifyingGlass } from "phosphor-react";
import { getAdminOrders, getAdminWarranty, getCardBatches } from "@/lib/api";
import { formatDateTime } from "@/lib/format";
import { ConsoleHeader, ConsolePanel, ConsoleEmpty } from "@/components/ConsoleKit";
import { Badge } from "@/components/ui/badge";

interface AuditItem {
  id: string;
  action: string;
  detail: string;
  time: string;
  tone: string;
}

/** 操作日志：汇总后台关键操作，便于追踪。 */
export default function AdminAuditLogs() {
  const { data: orders } = useQuery({ queryKey: ["admin-orders"], queryFn: getAdminOrders });
  const { data: warranty } = useQuery({ queryKey: ["admin-warranty"], queryFn: getAdminWarranty });
  const { data: batches } = useQuery({ queryKey: ["card-batches"], queryFn: getCardBatches });

  const logs: AuditItem[] = [
    ...(orders ?? []).map((o): AuditItem => ({
      id: `order-${o.order_id}`,
      action: "订单创建",
      detail: `${o.customer_username} 购买「${o.product_name}」`,
      time: o.created_at,
      tone: "text-[var(--cx-blue)]",
    })),
    ...(warranty ?? []).map((w): AuditItem => ({
      id: `warranty-${w.id}`,
      action: "售后工单",
      detail: `${w.carx_email} 提交「${w.claim_type === "ban_recover" ? "封禁恢复" : "保修"}」`,
      time: w.created_at,
      tone: "text-[var(--cx-amber)]",
    })),
    ...(batches ?? []).map((b): AuditItem => ({
      id: `batch-${b.id}`,
      action: "卡密批次",
      detail: `生成批次「${b.batch_name}」共 ${b.quantity} 张`,
      time: b.created_at,
      tone: "text-[var(--cx-green)]",
    })),
  ].sort((a, b) => (a.time < b.time ? 1 : -1));

  return (
    <div>
      <ConsoleHeader title="操作日志" description="查看后台关键操作记录，便于追踪问题" />
      <ConsolePanel>
        {logs.length === 0 ? (
          <ConsoleEmpty icon={<MagnifyingGlass className="size-8" />} title="暂无操作记录" />
        ) : (
          <div className="flex flex-col divide-y divide-[var(--cx-line)]">
            {logs.map((l) => (
              <div key={l.id} className="flex items-center justify-between gap-3 py-3">
                <div className="flex min-w-0 items-center gap-3">
                  <Badge variant="outline" className={`shrink-0 border-[var(--cx-line)] ${l.tone}`}>{l.action}</Badge>
                  <span className="truncate text-sm text-[var(--cx-text)]">{l.detail}</span>
                </div>
                <span className="shrink-0 text-xs text-[var(--cx-muted)]">{formatDateTime(l.time)}</span>
              </div>
            ))}
          </div>
        )}
      </ConsolePanel>
    </div>
  );
}
