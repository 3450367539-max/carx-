import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Gear, ToggleLeft } from "phosphor-react";
import { getAdminConfig, updateAdminConfig, getErrorMessage } from "@/lib/api";
import { ConsoleHeader, ConsolePanel } from "@/components/ConsoleKit";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";

export default function AdminSettings() {
  const queryClient = useQueryClient();
  const { data: config, isLoading } = useQuery({ queryKey: ["admin-config"], queryFn: getAdminConfig });

  const [siteName, setSiteName] = useState("");
  const [slogan, setSlogan] = useState("");
  const [inviteRequired, setInviteRequired] = useState(false);
  const [pointsEnabled, setPointsEnabled] = useState(true);
  const [cardsEnabled, setCardsEnabled] = useState(true);
  const [agentOpen, setAgentOpen] = useState(true);

  useEffect(() => {
    if (config) {
      setSiteName(config.display.site_name);
      setSlogan(config.display.slogan);
      setInviteRequired(config.display.registration_invite_required);
      setPointsEnabled(config.points_shop_enabled);
      setCardsEnabled(config.cards_enabled);
      setAgentOpen(config.agent_application_open);
    }
  }, [config]);

  const saveMutation = useMutation({
    mutationFn: updateAdminConfig,
    onSuccess: () => {
      toast.success("配置已保存");
      queryClient.invalidateQueries({ queryKey: ["admin-config"] });
      queryClient.invalidateQueries({ queryKey: ["public-display-config"] });
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  if (isLoading) {
    return <div className="py-16 text-center text-sm text-[var(--cx-muted)]">正在加载...</div>;
  }

  return (
    <div>
      <ConsoleHeader title="系统配置" description="配置前台展示、任务执行、VIP备份等系统参数" />

      <div className="grid gap-5 lg:grid-cols-2">
        <ConsolePanel>
          <h3 className="flex items-center gap-2 text-sm font-semibold text-[var(--cx-text)]">
            <Gear className="size-4 text-[var(--cx-red)]" /> 站点信息
          </h3>
          <div className="mt-4 flex flex-col gap-3">
            <div className="flex flex-col gap-1.5">
              <Label>站点名称</Label>
              <Input value={siteName} onChange={(e) => setSiteName(e.target.value)} className="border-[var(--cx-line)] bg-[var(--cx-panel)] text-[var(--cx-text)]" />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>标语</Label>
              <Input value={slogan} onChange={(e) => setSlogan(e.target.value)} className="border-[var(--cx-line)] bg-[var(--cx-panel)] text-[var(--cx-text)]" />
            </div>
            <div className="flex items-center justify-between rounded-[8px] border border-[var(--cx-line)] p-3">
              <div>
                <Label>注册需要邀请码</Label>
                <p className="text-xs text-[var(--cx-muted)]">开启后新用户注册必须填写有效邀请码</p>
              </div>
              <Switch checked={inviteRequired} onCheckedChange={setInviteRequired} />
            </div>
          </div>
        </ConsolePanel>

        <ConsolePanel>
          <h3 className="flex items-center gap-2 text-sm font-semibold text-[var(--cx-text)]">
            <ToggleLeft className="size-4 text-[var(--cx-red)]" /> 功能开关
          </h3>
          <div className="mt-4 flex flex-col gap-3">
            <div className="flex items-center justify-between rounded-[8px] border border-[var(--cx-line)] p-3">
              <div>
                <Label>积分商城</Label>
                <p className="text-xs text-[var(--cx-muted)]">关闭后会员无法访问积分商城</p>
              </div>
              <Switch checked={pointsEnabled} onCheckedChange={setPointsEnabled} />
            </div>
            <div className="flex items-center justify-between rounded-[8px] border border-[var(--cx-line)] p-3">
              <div>
                <Label>卡密兑换</Label>
                <p className="text-xs text-[var(--cx-muted)]">关闭后会员无法兑换卡密</p>
              </div>
              <Switch checked={cardsEnabled} onCheckedChange={setCardsEnabled} />
            </div>
            <div className="flex items-center justify-between rounded-[8px] border border-[var(--cx-line)] p-3">
              <div>
                <Label>代理商申请</Label>
                <p className="text-xs text-[var(--cx-muted)]">开放新的代理商入驻申请</p>
              </div>
              <Switch checked={agentOpen} onCheckedChange={setAgentOpen} />
            </div>
          </div>
        </ConsolePanel>
      </div>

      <div className="mt-5">
        <Button
          className="bg-[var(--cx-red)] text-white hover:bg-[var(--cx-red)]/90"
          disabled={saveMutation.isPending}
          onClick={() =>
            saveMutation.mutate({
              display: { site_name: siteName, slogan, registration_invite_required: inviteRequired },
              points_shop_enabled: pointsEnabled,
              cards_enabled: cardsEnabled,
              agent_application_open: agentOpen,
            })
          }
        >
          保存配置
        </Button>
      </div>
    </div>
  );
}
