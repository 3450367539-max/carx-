import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { ShieldCheck, Prohibit } from "phosphor-react";
import { agentUnbanRestore, getErrorMessage } from "@/lib/api";
import { ConsoleHeader, ConsolePanel } from "@/components/ConsoleKit";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function AgentUnban() {
  const [email, setEmail] = useState("");

  const mutation = useMutation({
    mutationFn: agentUnbanRestore,
    onSuccess: (r) => { toast.success(r.message || "解封已提交"); setEmail(""); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) { toast.error("请输入游戏邮箱"); return; }
    mutation.mutate(email.trim());
  };

  return (
    <div>
      <ConsoleHeader title="解封账号" description="使用客户最新备份为其游戏账号解除封禁" />

      <div className="grid gap-5 lg:grid-cols-2">
        <ConsolePanel>
          <h3 className="flex items-center gap-2 text-sm font-semibold text-[var(--cx-text)]">
            <Prohibit className="size-4 text-[var(--cx-red)]" /> 提交解封
          </h3>
          <form onSubmit={submit} className="mt-4 flex flex-col gap-3">
            <div className="flex flex-col gap-1.5">
              <Label>客户游戏邮箱</Label>
              <Input
                placeholder="customer@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="border-[var(--cx-line)] bg-[var(--cx-panel)] text-[var(--cx-text)]"
              />
            </div>
            <Button
              type="submit"
              className="bg-[var(--cx-red)] text-white hover:bg-[var(--cx-red)]/90"
              disabled={mutation.isPending}
            >
              {mutation.isPending ? "处理中..." : "确认解封"}
            </Button>
          </form>
        </ConsolePanel>

        <ConsolePanel>
          <h3 className="flex items-center gap-2 text-sm font-semibold text-[var(--cx-text)]">
            <ShieldCheck className="size-4 text-[var(--cx-green)]" /> 说明
          </h3>
          <ul className="mt-3 flex flex-col gap-2 text-sm leading-relaxed text-[var(--cx-muted)]">
            <li>· 仅对存在可用备份的账号有效；</li>
            <li>· 系统默认使用该账号最新可用备份执行恢复；</li>
            <li>· VIP 用户每日凌晨 5 点自动备份，封禁恢复依赖这些备份；</li>
            <li>· 提交后由系统后台队列处理，请稍后核对结果。</li>
          </ul>
        </ConsolePanel>
      </div>
    </div>
  );
}
