import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Package, Plus, Pencil, Trash, Eye, EyeSlash } from "phosphor-react";
import {
  getAdminProducts, createProduct, updateProduct, deleteProduct,
  getErrorMessage, type Product,
} from "@/lib/api";
import { formatCurrency } from "@/lib/format";
import { ConsoleHeader, ConsolePanel, ConsoleStat, ConsoleEmpty } from "@/components/ConsoleKit";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";

interface ProductForm {
  name: string;
  description: string;
  delivery_label: string;
  base_price: number;
  settlement_cost: number;
  warranty_days: number;
  grants_vip: boolean;
  vip_days: number;
  is_active: boolean;
  allow_white_account_delivery: boolean;
}

const emptyForm: ProductForm = {
  name: "", description: "", delivery_label: "", base_price: 0, settlement_cost: 0,
  warranty_days: 30, grants_vip: false, vip_days: 0, is_active: true,
  allow_white_account_delivery: true,
};

export default function AdminProducts() {
  const queryClient = useQueryClient();
  const { data: products, isLoading } = useQuery({ queryKey: ["admin-products"], queryFn: getAdminProducts });
  const [editing, setEditing] = useState<Product | null>(null);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState<ProductForm>(emptyForm);

  const refresh = () => queryClient.invalidateQueries({ queryKey: ["admin-products"] });

  const saveMut = useMutation({
    mutationFn: () => {
      const body = { ...form, is_combo: true, points_redeem_price: null };
      return editing ? updateProduct(editing.id, body) : createProduct(body as Partial<Product> & { name: string; base_price: number });
    },
    onSuccess: () => {
      toast.success(editing ? "商品已更新" : "商品已创建");
      setEditing(null); setCreating(false); refresh();
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const toggleMut = useMutation({
    mutationFn: (p: Product) => updateProduct(p.id, { is_active: !p.is_active }),
    onSuccess: (_, p) => { toast.success(p.is_active ? `「${p.name}」已下架` : `「${p.name}」已上架`); refresh(); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const deleteMut = useMutation({
    mutationFn: (id: number) => deleteProduct(id),
    onSuccess: () => { toast.success("商品已删除"); refresh(); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const openEdit = (p: Product) => {
    setForm({
      name: p.name, description: p.description, delivery_label: p.delivery_label,
      base_price: p.base_price, settlement_cost: p.settlement_cost, warranty_days: p.warranty_days,
      grants_vip: p.grants_vip, vip_days: p.vip_days, is_active: p.is_active,
      allow_white_account_delivery: p.allow_white_account_delivery,
    });
    setEditing(p);
  };

  const activeCount = (products ?? []).filter((p) => p.is_active).length;
  const avgPrice = products && products.length > 0
    ? products.reduce((s, p) => s + p.base_price, 0) / products.length : 0;

  return (
    <div>
      <ConsoleHeader title="商品管理" description="维护代刷套餐的定价、结算成本、质保与发货配置" />

      <div className="mb-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <ConsoleStat label="商品总数" value={products?.length ?? 0} />
        <ConsoleStat label="上架中" value={activeCount} tone="red" />
        <ConsoleStat label="已下架" value={(products?.length ?? 0) - activeCount} />
        <ConsoleStat label="平均售价" value={formatCurrency(avgPrice)} />
      </div>

      <ConsolePanel>
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm font-semibold text-[var(--cx-text)]">
            <Package className="size-4" /> 套餐列表
          </div>
          <Button size="sm" onClick={() => { setForm(emptyForm); setCreating(true); }}>
            <Plus className="size-4" /> 新建商品
          </Button>
        </div>
        {isLoading ? (
          <div className="py-10 text-center text-sm text-[var(--cx-muted)]">正在加载...</div>
        ) : !products || products.length === 0 ? (
          <ConsoleEmpty title="暂无商品" />
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>商品</TableHead>
                <TableHead>售价</TableHead>
                <TableHead>结算成本</TableHead>
                <TableHead>质保</TableHead>
                <TableHead>赠送会员</TableHead>
                <TableHead>状态</TableHead>
                <TableHead className="text-right">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {products.map((p) => (
                <TableRow key={p.id}>
                  <TableCell>
                    <div className="font-medium text-[var(--cx-text)]">{p.name}</div>
                    <div className="max-w-[280px] truncate text-xs text-[var(--cx-muted)]">{p.delivery_label || p.description || "—"}</div>
                  </TableCell>
                  <TableCell className="font-semibold text-[var(--cx-text)]">{formatCurrency(p.base_price)}</TableCell>
                  <TableCell className="text-[var(--cx-muted)]">{formatCurrency(p.settlement_cost)}</TableCell>
                  <TableCell>{p.warranty_days > 0 ? `${p.warranty_days} 天` : "无"}</TableCell>
                  <TableCell>
                    {p.grants_vip ? <Badge>会员 {p.vip_days} 天</Badge> : <span className="text-[var(--cx-muted)]">—</span>}
                  </TableCell>
                  <TableCell>
                    {p.is_active
                      ? <Badge className="border-emerald-500/30 bg-emerald-500/10 text-emerald-400">上架中</Badge>
                      : <Badge variant="outline" className="text-[var(--cx-muted)]">已下架</Badge>}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Button size="icon" variant="ghost" title={p.is_active ? "下架" : "上架"} onClick={() => toggleMut.mutate(p)}>
                        {p.is_active ? <EyeSlash className="size-4" /> : <Eye className="size-4" />}
                      </Button>
                      <Button size="icon" variant="ghost" title="编辑" onClick={() => openEdit(p)}>
                        <Pencil className="size-4" />
                      </Button>
                      <Button size="icon" variant="ghost" title="删除"
                        onClick={() => { if (confirm(`确定删除商品「${p.name}」？`)) deleteMut.mutate(p.id); }}>
                        <Trash className="size-4 text-red-400" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </ConsolePanel>

      <Dialog open={creating || !!editing} onOpenChange={(o) => { if (!o) { setCreating(false); setEditing(null); } }}>
        <DialogContent className="max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{creating ? "新建商品" : `编辑商品 · ${editing?.name}`}</DialogTitle></DialogHeader>
          <div className="flex flex-col gap-3">
            <div className="flex flex-col gap-1.5">
              <Label>商品名称</Label>
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="如：八刷" />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>发货内容说明</Label>
              <Input value={form.delivery_label} onChange={(e) => setForm({ ...form, delivery_label: e.target.value })} placeholder="组合套餐：银币 + 金币 + 满级 + 全图" />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>商品描述</Label>
              <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={2} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="flex flex-col gap-1.5">
                <Label>售价（元）</Label>
                <Input type="number" value={form.base_price} onChange={(e) => setForm({ ...form, base_price: Number(e.target.value) })} />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label>结算成本（元）</Label>
                <Input type="number" value={form.settlement_cost} onChange={(e) => setForm({ ...form, settlement_cost: Number(e.target.value) })} />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label>质保天数</Label>
                <Input type="number" value={form.warranty_days} onChange={(e) => setForm({ ...form, warranty_days: Number(e.target.value) })} />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label>赠送会员天数</Label>
                <Input type="number" value={form.vip_days} onChange={(e) => setForm({ ...form, vip_days: Number(e.target.value) })} disabled={!form.grants_vip} />
              </div>
            </div>
            <div className="flex flex-col gap-2.5 rounded-lg border border-[var(--cx-line)] p-3">
              <label className="flex items-center justify-between text-sm">
                <span>购买赠送 VIP 会员</span>
                <Switch checked={form.grants_vip} onCheckedChange={(v) => setForm({ ...form, grants_vip: v })} />
              </label>
              <label className="flex items-center justify-between text-sm">
                <span>支持白号发货</span>
                <Switch checked={form.allow_white_account_delivery} onCheckedChange={(v) => setForm({ ...form, allow_white_account_delivery: v })} />
              </label>
              <label className="flex items-center justify-between text-sm">
                <span>立即上架</span>
                <Switch checked={form.is_active} onCheckedChange={(v) => setForm({ ...form, is_active: v })} />
              </label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setCreating(false); setEditing(null); }}>取消</Button>
            <Button disabled={!form.name || form.base_price <= 0 || saveMut.isPending} onClick={() => saveMut.mutate()}>
              {saveMut.isPending ? "保存中..." : "保存"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
