import { useQuery } from "@tanstack/react-query";
import { Wallet, Receipt, Hand, TrendUp, Clock } from "phosphor-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";
import { getAgentDashboard, getAgentSalesTrend } from "@/lib/api";
import { orderStatusMeta } from "@/lib/status";
import { formatCurrency, formatDateTime } from "@/lib/format";
import { ConsoleHeader, ConsolePanel, ConsoleStat } from "@/components/ConsoleKit";
import { Badge } from "@/components/ui/badge";

export default function AgentOverview() {
  const { data: stats, isLoading } = useQuery({ queryKey: ["agent-dashboard"], queryFn: getAgentDashboard });
  const { data: trend } = useQuery({ queryKey: ["agent-sales-trend"], queryFn: getAgentSalesTrend });

  if (isLoading || !stats) {
    return <div className="py-16 text-center text-sm text-[var(--cx-muted)]">正在加载...</div>;
  }

  return (
    <div>
      <ConsoleHeader
        title="数据总览"
        description={`代理 ${stats.agent_code} · 开业于 ${stats.business_start_date}`}
      />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <ConsoleStat label="今日订单" value={stats.today_orders_count} icon={<Receipt className="size-5" />} tone="blue" hint={`净利 ${formatCurrency(stats.today_net_profit)}`} />
        <ConsoleStat label="本月净利" value={formatCurrency(stats.month_net_profit)} icon={<TrendUp className="size-5" />} tone="green" hint={`本月订单 ${stats.month_orders_count} 笔`} />
        <ConsoleStat label="当前欠款" value={formatCurrency(stats.amount_owed)} icon={<Hand className="size-5" />} tone="red" hint={`授信额度 ${formatCurrency(stats.max_debt_limit)}`} />
        <ConsoleStat label="今日待结算" value={formatCurrency(stats.today_pending_settlement)} icon={<Clock className="size-5" />} tone="amber" hint={`剩余额度 ${formatCurrency(stats.remaining_debt_limit)}`} />
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-3">
        <ConsolePanel className="lg:col-span-2">
          <h3 className="mb-4 text-sm font-semibold text-[var(--cx-text)]">近 7 日营收趋势</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trend ?? []} margin={{ left: 0, right: 8, top: 8 }}>
                <defs>
                  <linearGradient id="agentSales" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="var(--cx-red)" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="var(--cx-red)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--cx-line)" />
                <XAxis dataKey="date" fontSize={12} tickLine={false} axisLine={false} stroke="var(--cx-muted)" />
                <YAxis fontSize={12} tickLine={false} axisLine={false} stroke="var(--cx-muted)" />
                <Tooltip contentStyle={{ background: "var(--cx-panel-strong)", border: "1px solid var(--cx-line)", borderRadius: 8, fontSize: 12, color: "var(--cx-text)" }} />
                <Area type="monotone" dataKey="sales" stroke="var(--cx-red)" fill="url(#agentSales)" strokeWidth={2} name="营收" />
                <Area type="monotone" dataKey="orders" stroke="var(--cx-blue)" fill="none" strokeWidth={2} name="订单" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </ConsolePanel>

        <ConsolePanel>
          <h3 className="mb-3 text-sm font-semibold text-[var(--cx-text)]">今日订单</h3>
          <div className="flex flex-col divide-y divide-[var(--cx-line)]">
            {stats.orders.length === 0 && (
              <div className="py-8 text-center text-xs text-[var(--cx-muted)]">今日暂无订单</div>
            )}
            {stats.orders.map((o) => (
              <div key={o.order_id} className="flex items-center justify-between gap-2 py-2.5">
                <div className="min-w-0">
                  <div className="truncate text-sm font-medium text-[var(--cx-text)]">{o.product_name}</div>
                  <div className="truncate text-xs text-[var(--cx-muted)]">{o.customer_username}</div>
                </div>
                <div className="flex shrink-0 flex-col items-end gap-1">
                  <span className="text-xs font-semibold text-[var(--cx-text)]">{formatCurrency(o.selling_price)}</span>
                  <Badge variant="outline" className={orderStatusMeta[o.status].className}>{orderStatusMeta[o.status].label}</Badge>
                </div>
              </div>
            ))}
          </div>
        </ConsolePanel>
      </div>

      <div className="mt-5">
        <ConsolePanel>
          <div className="flex items-center gap-2 text-sm text-[var(--cx-muted)]">
            <Wallet className="size-4" />
            上次结算时间：{stats.last_settlement_at ? formatDateTime(stats.last_settlement_at) : "暂无结算记录"}
          </div>
        </ConsolePanel>
      </div>
    </div>
  );
}
