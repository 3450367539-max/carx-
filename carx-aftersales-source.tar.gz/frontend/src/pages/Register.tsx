import { useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { Car, Loader2 } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { register, getPublicDisplayConfig, getErrorMessage } from "@/lib/api";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { SliderCaptcha } from "@/components/SliderCaptcha";

export default function Register() {
  const { user, login: authLogin } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [inviteCode, setInviteCode] = useState("");
  const [captchaToken, setCaptchaToken] = useState("");
  const [captchaPassed, setCaptchaPassed] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const { data: config } = useQuery({
    queryKey: ["public-display-config-register"],
    queryFn: getPublicDisplayConfig,
  });

  const inviteRequired = config?.registration_invite_required ?? false;

  if (user) {
    return <Navigate to="/console" replace />;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!captchaPassed || !captchaToken) {
      toast.error("请先拖动滑块完成验证");
      return;
    }
    if (!email || !password) {
      toast.error("请输入邮箱与密码");
      return;
    }
    if (inviteRequired && !inviteCode) {
      toast.error("请输入邀请码");
      return;
    }
    setSubmitting(true);
    try {
      const res = await register({
        carx_email: email,
        carx_password: password,
        invite_code: inviteRequired ? inviteCode : undefined,
        captcha_token: captchaToken,
        captcha_value: 100,
      });
      authLogin(res.token, res.user);
      toast.success("注册成功，已为您登录");
      navigate("/console", { replace: true });
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-zinc-900 via-zinc-800 to-theme-red/40 p-4">
      <div className="w-full max-w-md rounded-2xl border bg-card p-8 shadow-xl">
        <div className="mb-6 flex flex-col items-center text-center">
          <div className="flex size-12 items-center justify-center rounded-xl bg-theme-red text-white">
            <Car className="size-6" />
          </div>
          <h1 className="mt-4 text-2xl font-bold">注册 CARX 账号</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            创建账号以享受完整的售后服务中心
          </p>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div className="flex flex-col gap-2">
            <Label htmlFor="email">邮箱</Label>
            <Input
              id="email"
              type="email"
              autoComplete="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>

          <div className="flex flex-col gap-2">
            <Label htmlFor="password">密码</Label>
            <Input
              id="password"
              type="password"
              autoComplete="new-password"
              placeholder="至少 6 位"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>

          {inviteRequired && (
            <div className="flex flex-col gap-2">
              <Label htmlFor="invite">邀请码</Label>
              <Input
                id="invite"
                placeholder="CARX2024"
                value={inviteCode}
                onChange={(e) => setInviteCode(e.target.value)}
              />
            </div>
          )}

          <div className="flex flex-col gap-2">
            <Label>安全验证</Label>
            <SliderCaptcha
              onChange={(token, passed) => {
                setCaptchaToken(token);
                setCaptchaPassed(passed);
              }}
            />
          </div>

          <Button
            type="submit"
            className="mt-2 bg-theme-red text-white hover:bg-theme-red/90"
            disabled={submitting}
          >
            {submitting && <Loader2 className="size-4 animate-spin" />}
            注册并登录
          </Button>
        </form>

        <p className="mt-6 text-center text-sm text-muted-foreground">
          已有账号？
          <Link to="/login" className="ml-1 text-theme-red hover:underline">
            去登录
          </Link>
        </p>
      </div>
    </div>
  );
}
