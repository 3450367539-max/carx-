import { useQuery } from "@tanstack/react-query";
import { GameController, ShieldCheck, Database } from "phosphor-react";
import { useAuth } from "@/lib/auth";
import { getVipStatus, getVipBackups } from "@/lib/api";
import { formatDateTime } from "@/lib/format";
import { Badge } from "@/components/ui/badge";

export default function MemberGame() {
  const { user } = useAuth();
  const { data: vip } = useQuery({ queryKey: ["vip-status"], queryFn: getVipStatus });
  const { data: backups } = useQuery({ queryKey: ["vip-backups"], queryFn: getVipBackups });

  const latest = backups?.items?.[0];

  return (
    <div className="flex flex-col gap-5">
      <div>
        <h1 className="text-xl font-bold text-[var(--vip-text)]">游戏数据</h1>
        <p className="mt-1 text-sm text-[var(--vip-muted)]">查看当前绑定的游戏账号与数据保护状态</p>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        {/* 游戏账号 */}
        <div className="rounded-[var(--vip-radius)] border border-[var(--vip-line)] bg-[var(--vip-surface)] p-5 shadow-[var(--vip-shadow)]">
          <h3 className="flex items-center gap-2 text-sm font-semibold text-[var(--vip-text)]">
            <GameController className="size-4 text-[var(--vip-blue)]" /> 游戏账号
          </h3>
          {user?.has_carx_bound ? (
            <div className="mt-4 flex flex-col gap-3 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-[var(--vip-muted)]">绑定状态</span>
                <Badge className="border-emerald-300 bg-emerald-50 text-[var(--vip-green)]">已绑定</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[var(--vip-muted)]">游戏邮箱</span>
                <span className="font-mono text-xs text-[var(--vip-text)]">{user.carx_email}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[var(--vip-muted)]">数据状态</span>
                <span className="text-[var(--vip-green)]">
                  {vip?.has_backup ? "数据安全，最近备份成功" : "尚未创建备份"}
                </span>
              </div>
            </div>
          ) : (
            <div className="mt-6 flex flex-col items-center gap-2 py-6 text-center">
              <GameController className="size-8 text-[var(--vip-muted)]/40" />
              <div className="text-sm text-[var(--vip-muted)]">暂无游戏账号</div>
            </div>
          )}
        </div>

        {/* 数据保护 */}
        <div className="rounded-[var(--vip-radius)] border border-[var(--vip-line)] bg-[var(--vip-surface)] p-5 shadow-[var(--vip-shadow)]">
          <h3 className="flex items-center gap-2 text-sm font-semibold text-[var(--vip-text)]">
            <ShieldCheck className="size-4 text-[var(--vip-blue)]" /> 数据保护
          </h3>
          <div className="mt-4 flex flex-col gap-3 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-[var(--vip-muted)]">备份状态</span>
              {vip?.has_backup ? (
                <Badge className="border-emerald-300 bg-emerald-50 text-[var(--vip-green)]">备份可用</Badge>
              ) : (
                <Badge variant="outline" className="text-[var(--vip-muted)]">暂无备份</Badge>
              )}
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[var(--vip-muted)]">备份数量</span>
              <span className="text-[var(--vip-text)]">{vip?.backup_count ?? 0} / {vip?.backup_limit ?? 7}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[var(--vip-muted)]">最近备份</span>
              <span className="text-xs text-[var(--vip-text)]">
                {latest ? formatDateTime(latest.created_at) : "—"}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 最近备份记录 */}
      <div className="rounded-[var(--vip-radius)] border border-[var(--vip-line)] bg-[var(--vip-surface)] p-5 shadow-[var(--vip-shadow)]">
        <h3 className="flex items-center gap-2 text-sm font-semibold text-[var(--vip-text)]">
          <Database className="size-4 text-[var(--vip-blue)]" /> 最近备份
        </h3>
        {(backups?.items ?? []).length === 0 ? (
          <div className="mt-4 text-sm text-[var(--vip-muted)]">暂无备份记录</div>
        ) : (
          <div className="mt-3 flex flex-col divide-y divide-[var(--vip-line)]">
            {(backups?.items ?? []).slice(0, 5).map((b) => (
              <div key={b.id} className="flex items-center justify-between py-3">
                <div>
                  <div className="text-sm font-medium text-[var(--vip-text)]">备份 #{b.id}</div>
                  <div className="text-xs text-[var(--vip-muted)]">{formatDateTime(b.created_at)}</div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-[var(--vip-muted)]">{b.backup_type_label}</Badge>
                  <Badge className="border-emerald-300 bg-emerald-50 text-[var(--vip-green)]">{b.status_label}</Badge>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
