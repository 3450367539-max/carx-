import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Wallet, Ticket, Info } from "phosphor-react";
import { getMyRedemptions, redeemCard, getErrorMessage } from "@/lib/api";
import { cardStatusMeta } from "@/lib/status";
import { formatDateTime } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

export default function MemberRedeem() {
  const queryClient = useQueryClient();
  const [code, setCode] = useState("");
  const { data: redemptions, isLoading } = useQuery({
    queryKey: ["my-redemptions"],
    queryFn: getMyRedemptions,
  });

  const redeemMutation = useMutation({
    mutationFn: (c: string) => redeemCard(c),
    onSuccess: (r) => {
      toast.success(`兑换成功：${r.sku_name}`);
      setCode("");
      queryClient.invalidateQueries({ queryKey: ["my-redemptions"] });
      queryClient.invalidateQueries({ queryKey: ["vip-status"] });
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim()) {
      toast.error("请输入卡密");
      return;
    }
    redeemMutation.mutate(code.trim());
  };

  return (
    <div className="flex flex-col gap-5">
      <div>
        <h1 className="text-xl font-bold text-[var(--vip-text)]">卡密兑换</h1>
        <p className="mt-1 text-sm text-[var(--vip-muted)]">使用卡密兑换会员或服务</p>
      </div>

      <div className="grid gap-5 lg:grid-cols-5">
        {/* 兑换卡 */}
        <div className="lg:col-span-2 flex flex-col gap-5">
          <div className="rounded-[var(--vip-radius)] border border-[var(--vip-line)] bg-[var(--vip-surface)] p-5 shadow-[var(--vip-shadow)]">
            <h3 className="flex items-center gap-2 text-sm font-semibold text-[var(--vip-text)]">
              <Ticket className="size-4 text-[var(--vip-blue)]" /> 输入卡密
            </h3>
            <form onSubmit={submit} className="mt-4 flex flex-col gap-3">
              <Input
                placeholder="请输入卡密（区分大小写）"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="font-mono"
              />
              <Button
                type="submit"
                className="bg-[var(--vip-blue)] text-white hover:bg-[var(--vip-blue-hover)]"
                disabled={redeemMutation.isPending}
              >
                {redeemMutation.isPending ? "兑换中..." : "立即兑换"}
              </Button>
              <p className="text-xs text-[var(--vip-muted)]">
                输入卡密后自动发货，兑换结果会同步保存到订单记录。
              </p>
            </form>
          </div>

          {/* 兑换须知 */}
          <div className="rounded-[var(--vip-radius)] border border-[var(--vip-line)] bg-[var(--vip-soft)] p-5">
            <h3 className="flex items-center gap-2 text-sm font-semibold text-[var(--vip-text)]">
              <Info className="size-4 text-[var(--vip-blue)]" weight="fill" /> 兑换须知
            </h3>
            <ul className="mt-3 flex flex-col gap-2 text-xs leading-relaxed text-[var(--vip-muted)]">
              <li>· 卡密一经兑换，无法退换或二次使用；</li>
              <li>· 兑换成功后，内容将自动发放到账户；</li>
              <li>· 请妥善保管卡密信息，避免泄露；</li>
              <li>· 如遇问题，可在购买记录中申请售后。</li>
            </ul>
          </div>
        </div>

        {/* 兑换记录 */}
        <div className="lg:col-span-3 rounded-[var(--vip-radius)] border border-[var(--vip-line)] bg-[var(--vip-surface)] shadow-[var(--vip-shadow)]">
          <div className="border-b border-[var(--vip-line)] px-5 py-4">
            <h3 className="flex items-center gap-2 text-sm font-semibold text-[var(--vip-text)]">
              <Wallet className="size-4 text-[var(--vip-blue)]" /> 最近兑换记录
            </h3>
          </div>
          {isLoading ? (
            <div className="py-14 text-center text-sm text-[var(--vip-muted)]">正在加载...</div>
          ) : (redemptions ?? []).length === 0 ? (
            <div className="flex flex-col items-center gap-2 py-14 text-center">
              <Ticket className="size-8 text-[var(--vip-muted)]/40" />
              <div className="text-sm text-[var(--vip-muted)]">暂无兑换记录</div>
            </div>
          ) : (
            <div className="flex flex-col divide-y divide-[var(--vip-line)]">
              {(redemptions ?? []).map((c) => (
                <div key={c.id} className="flex items-center justify-between gap-3 px-5 py-3.5">
                  <div className="min-w-0">
                    <div className="font-mono text-sm font-medium text-[var(--vip-text)]">{c.code}</div>
                    <div className="text-xs text-[var(--vip-muted)]">{c.sku_name}</div>
                  </div>
                  <div className="flex shrink-0 flex-col items-end gap-1">
                    <Badge variant="outline" className={cardStatusMeta[c.status].className}>
                      {cardStatusMeta[c.status].label}
                    </Badge>
                    <span className="text-xs text-[var(--vip-muted)]">
                      兑换时间 {formatDateTime(c.redeemed_at ?? undefined)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
