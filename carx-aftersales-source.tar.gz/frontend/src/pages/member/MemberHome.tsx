import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import {
  ShieldCheck,
  Wallet,
  Receipt,
  Storefront,
  Megaphone,
  ArrowRight,
  Database,
  ArrowCounterClockwise,
  Prohibit,
  X,
  Crown,
} from "phosphor-react";
import {
  getVipStatus,
  getMyOrders,
  getActiveAnnouncements,
  createBackup,
  restoreBackup,
  banRecover,
  markAnnouncementRead,
  getErrorMessage,
  type Announcement,
} from "@/lib/api";
import { orderStatusMeta } from "@/lib/status";
import { formatDateTime } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";

const actionCards = [
  { key: "redeem", title: "卡密兑换", desc: "使用卡密兑换会员或服务", icon: Wallet, to: "/console/redeem" },
  { key: "orders", title: "订单记录", desc: "查看订单与处理进度", icon: Receipt, to: "/console/orders" },
  { key: "points", title: "积分商城", desc: "使用积分兑换好礼", icon: Storefront, to: "/console/points" },
  { key: "backup", title: "数据备份", desc: "定期备份游戏数据，防止数据丢失", icon: ShieldCheck, to: "/console/backup" },
];

export default function MemberHome() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [announcement, setAnnouncement] = useState<Announcement | null>(null);
  const [confirm, setConfirm] = useState<"backup" | "restore" | "ban" | null>(null);

  const { data: vip } = useQuery({ queryKey: ["vip-status"], queryFn: getVipStatus });
  const { data: orders } = useQuery({ queryKey: ["my-orders"], queryFn: getMyOrders });
  const { data: announcements } = useQuery({ queryKey: ["announcements-active"], queryFn: getActiveAnnouncements });

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["vip-status"] });
    queryClient.invalidateQueries({ queryKey: ["vip-backups"] });
    queryClient.invalidateQueries({ queryKey: ["my-warranty"] });
  };

  const backupMutation = useMutation({
    mutationFn: createBackup,
    onSuccess: () => { toast.success("备份创建成功"); setConfirm(null); invalidate(); },
    onError: (e) => { toast.error(getErrorMessage(e)); setConfirm(null); },
  });
  const restoreMutation = useMutation({
    mutationFn: () => restoreBackup(),
    onSuccess: (r) => { toast.success(r.message || "恢复任务已提交"); setConfirm(null); invalidate(); },
    onError: (e) => { toast.error(getErrorMessage(e)); setConfirm(null); },
  });
  const banMutation = useMutation({
    mutationFn: banRecover,
    onSuccess: () => { toast.success("封禁恢复已提交"); setConfirm(null); invalidate(); },
    onError: (e) => { toast.error(getErrorMessage(e)); setConfirm(null); },
  });

  const activeAnnouncement = (announcements ?? [])[0];
  const recent = (orders ?? []).slice(0, 5);
  const busy = backupMutation.isPending || restoreMutation.isPending || banMutation.isPending;

  return (
    <div className="flex flex-col gap-5">
      {/* Hero */}
      <section className="flex items-center justify-between rounded-[var(--vip-radius)] border border-[var(--vip-line)] bg-gradient-to-br from-[var(--vip-surface)] to-[var(--vip-blue-soft)] p-6 shadow-[var(--vip-shadow)]">
        <div>
          <h1 className="text-2xl font-bold text-[var(--vip-text)]">账号服务中心</h1>
          <p className="mt-1 text-sm text-[var(--vip-muted)]">兑换、会员、订单与售后统一管理</p>
        </div>
        <ShieldCheck className="size-12 text-[var(--vip-blue)]/30" weight="duotone" />
      </section>

      {/* 公告条 */}
      {activeAnnouncement && (
        <button
          onClick={() => setAnnouncement(activeAnnouncement)}
          className="flex items-center gap-3 rounded-[var(--vip-radius)] border border-[var(--vip-line)] bg-[var(--vip-surface)] px-4 py-3 text-left shadow-[var(--vip-shadow)] transition hover:border-[var(--vip-blue)]/40"
        >
          <Megaphone className="size-5 shrink-0 text-[var(--vip-blue)]" weight="fill" />
          <span className="min-w-0 flex-1 truncate text-sm">
            <strong className="font-semibold text-[var(--vip-text)]">{activeAnnouncement.title}</strong>
            <span className="ml-2 text-[var(--vip-muted)]">{activeAnnouncement.content.split("\n")[0]}</span>
          </span>
          <ArrowRight className="size-4 shrink-0 text-[var(--vip-muted)]" />
        </button>
      )}

      {/* 操作卡 */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {actionCards.map((c) => (
          <button
            key={c.key}
            onClick={() => navigate(c.to)}
            className="group flex flex-col gap-3 rounded-[var(--vip-radius)] border border-[var(--vip-line)] bg-[var(--vip-surface)] p-5 text-left shadow-[var(--vip-shadow)] transition hover:-translate-y-0.5 hover:border-[var(--vip-blue)]/40"
          >
            <div className="flex size-11 items-center justify-center rounded-[10px] bg-[var(--vip-blue-soft)] text-[var(--vip-blue)]">
              <c.icon className="size-6" weight="duotone" />
            </div>
            <div>
              <div className="text-sm font-semibold text-[var(--vip-text)]">{c.title}</div>
              <div className="mt-0.5 text-xs text-[var(--vip-muted)]">{c.desc}</div>
            </div>
          </button>
        ))}
      </div>

      {/* 主网格：备份面板 + 最近订单 */}
      <div className="grid gap-5 lg:grid-cols-2">
        {/* 数据备份面板 */}
        <div className="rounded-[var(--vip-radius)] border border-[var(--vip-line)] bg-[var(--vip-surface)] p-5 shadow-[var(--vip-shadow)]">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="flex items-center gap-2 text-sm font-semibold text-[var(--vip-text)]">
              <Database className="size-4 text-[var(--vip-blue)]" /> 数据备份
            </h3>
            {vip?.is_vip ? (
              <Badge className="border-amber-300 bg-amber-50 text-amber-600">
                <Crown className="mr-1 size-3" weight="fill" /> VIP
              </Badge>
            ) : (
              <Badge variant="outline" className="text-[var(--vip-muted)]">未开通</Badge>
            )}
          </div>

          <div className="mb-4 grid grid-cols-3 gap-3">
            <div className="rounded-[10px] bg-[var(--vip-soft)] p-3">
              <div className="text-xs text-[var(--vip-muted)]">备份状态</div>
              <div className="mt-1 text-sm font-semibold text-[var(--vip-green)]">
                {vip?.has_backup ? "备份正常" : "暂无备份"}
              </div>
            </div>
            <div className="rounded-[10px] bg-[var(--vip-soft)] p-3">
              <div className="text-xs text-[var(--vip-muted)]">备份数量</div>
              <div className="mt-1 text-sm font-semibold text-[var(--vip-text)]">
                {vip?.backup_count ?? 0} / {vip?.backup_limit ?? 7}
              </div>
            </div>
            <div className="rounded-[10px] bg-[var(--vip-soft)] p-3">
              <div className="text-xs text-[var(--vip-muted)]">会员有效期</div>
              <div className="mt-1 text-sm font-semibold text-[var(--vip-text)]">
                {vip?.is_vip ? `${vip.days_remaining} 天` : "未开通"}
              </div>
            </div>
          </div>

          <div className="mb-4 text-xs text-[var(--vip-muted)]">
            最新备份时间：{vip?.last_backup ? formatDateTime(vip.last_backup) : "尚未创建备份"}
          </div>

          <div className="flex flex-wrap gap-2">
            <Button
              size="sm"
              className="bg-[var(--vip-blue)] text-white hover:bg-[var(--vip-blue-hover)]"
              disabled={!vip?.is_vip || busy}
              onClick={() => setConfirm("backup")}
            >
              <Database className="size-4" /> 立即备份
            </Button>
            <Button
              size="sm"
              variant="outline"
              disabled={!vip?.is_vip || !vip?.has_backup || busy}
              onClick={() => setConfirm("restore")}
            >
              <ArrowCounterClockwise className="size-4" /> 恢复数据
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="border-[var(--vip-red)]/40 text-[var(--vip-red)] hover:bg-[var(--vip-red)]/5"
              disabled={!vip?.is_vip || !vip?.has_backup || busy}
              onClick={() => setConfirm("ban")}
            >
              <Prohibit className="size-4" /> 封禁恢复
            </Button>
          </div>
          <p className="mt-3 text-xs text-[var(--vip-muted)]">
            会员可保留最多 7 个备份点，封禁恢复默认使用最新可用备份。
          </p>
        </div>

        {/* 最近订单面板 */}
        <div className="rounded-[var(--vip-radius)] border border-[var(--vip-line)] bg-[var(--vip-surface)] p-5 shadow-[var(--vip-shadow)]">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="flex items-center gap-2 text-sm font-semibold text-[var(--vip-text)]">
              <Receipt className="size-4 text-[var(--vip-blue)]" /> 最近订单
            </h3>
            <Button variant="ghost" size="sm" className="text-[var(--vip-blue)]" onClick={() => navigate("/console/orders")}>
              查看全部 <ArrowRight className="size-4" />
            </Button>
          </div>
          {recent.length === 0 ? (
            <div className="flex flex-col items-center gap-2 py-10 text-center">
              <Receipt className="size-8 text-[var(--vip-muted)]/40" />
              <div className="text-sm text-[var(--vip-muted)]">暂无订单</div>
            </div>
          ) : (
            <div className="flex flex-col divide-y divide-[var(--vip-line)]">
              {recent.map((o) => (
                <div key={o.order_id} className="flex items-center justify-between gap-3 py-3">
                  <div className="min-w-0">
                    <div className="truncate text-sm font-medium text-[var(--vip-text)]">{o.product_name}</div>
                    <div className="text-xs text-[var(--vip-muted)]">订单号：{o.display_no}</div>
                  </div>
                  <Badge variant="outline" className={orderStatusMeta[o.status].className}>
                    {orderStatusMeta[o.status].label}
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* 公告弹窗 */}
      <Dialog open={!!announcement} onOpenChange={(o) => !o && setAnnouncement(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Megaphone className="size-5 text-[var(--vip-blue)]" weight="fill" />
              {announcement?.title}
            </DialogTitle>
          </DialogHeader>
          <DialogDescription asChild>
            <p className="whitespace-pre-line text-sm leading-relaxed text-[var(--vip-text)]">
              {announcement?.content}
            </p>
          </DialogDescription>
          <DialogFooter>
            <Button
              className="bg-[var(--vip-blue)] text-white hover:bg-[var(--vip-blue-hover)]"
              onClick={() => {
                if (announcement) markAnnouncementRead(announcement.id).catch(() => {});
                setAnnouncement(null);
              }}
            >
              <X className="size-4" /> 我知道了
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 操作确认弹窗 */}
      <Dialog open={!!confirm} onOpenChange={(o) => !o && setConfirm(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>请确认本次操作</DialogTitle>
            <DialogDescription>
              {confirm === "backup" && "系统将立即为您的游戏账号创建一个新的数据备份点。"}
              {confirm === "restore" && "默认选择最新可用备份恢复数据，不会影响平台账号。"}
              {confirm === "ban" && "账号被封禁或删除时，使用最新备份申请恢复，解除屏蔽。"}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirm(null)}>取消</Button>
            <Button
              className="bg-[var(--vip-blue)] text-white hover:bg-[var(--vip-blue-hover)]"
              disabled={busy}
              onClick={() => {
                if (confirm === "backup") backupMutation.mutate();
                else if (confirm === "restore") restoreMutation.mutate();
                else if (confirm === "ban") banMutation.mutate();
              }}
            >
              {busy ? "处理中..." : "确认"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
