import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  ShieldCheck,
  Database,
  ArrowCounterClockwise,
  Prohibit,
  Crown,
} from "phosphor-react";
import {
  getVipStatus,
  getVipBackups,
  createBackup,
  restoreBackup,
  banRecover,
  getErrorMessage,
} from "@/lib/api";
import { formatDateTime } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function MemberBackup() {
  const queryClient = useQueryClient();
  const [confirm, setConfirm] = useState<"backup" | "restore" | "ban" | null>(null);
  const [selectedBackup, setSelectedBackup] = useState<number | null>(null);

  const { data: vip } = useQuery({ queryKey: ["vip-status"], queryFn: getVipStatus });
  const { data: backups, isLoading } = useQuery({ queryKey: ["vip-backups"], queryFn: getVipBackups });

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["vip-status"] });
    queryClient.invalidateQueries({ queryKey: ["vip-backups"] });
    queryClient.invalidateQueries({ queryKey: ["my-warranty"] });
  };

  const backupMutation = useMutation({
    mutationFn: createBackup,
    onSuccess: () => { toast.success("备份创建成功"); setConfirm(null); invalidate(); },
    onError: (e) => { toast.error(getErrorMessage(e)); setConfirm(null); },
  });
  const restoreMutation = useMutation({
    mutationFn: (id?: number) => restoreBackup(id),
    onSuccess: (r) => { toast.success(r.message || "恢复任务已提交"); setConfirm(null); invalidate(); },
    onError: (e) => { toast.error(getErrorMessage(e)); setConfirm(null); },
  });
  const banMutation = useMutation({
    mutationFn: banRecover,
    onSuccess: () => { toast.success("封禁恢复已提交"); setConfirm(null); invalidate(); },
    onError: (e) => { toast.error(getErrorMessage(e)); setConfirm(null); },
  });

  const busy = backupMutation.isPending || restoreMutation.isPending || banMutation.isPending;
  const items = backups?.items ?? [];

  return (
    <div className="flex flex-col gap-5">
      <div>
        <h1 className="text-xl font-bold text-[var(--vip-text)]">数据备份</h1>
        <p className="mt-1 text-sm text-[var(--vip-muted)]">定期备份游戏数据，防止数据丢失，支持一键恢复或封禁恢复</p>
      </div>

      {/* 状态卡 */}
      <div className="grid gap-4 sm:grid-cols-3">
        <div className="rounded-[var(--vip-radius)] border border-[var(--vip-line)] bg-[var(--vip-surface)] p-5 shadow-[var(--vip-shadow)]">
          <div className="flex items-center justify-between">
            <span className="text-xs text-[var(--vip-muted)]">VIP 状态</span>
            {vip?.is_vip ? (
              <Badge className="border-amber-300 bg-amber-50 text-amber-600">
                <Crown className="mr-1 size-3" weight="fill" /> 至臻会员
              </Badge>
            ) : (
              <Badge variant="outline" className="text-[var(--vip-muted)]">未开通</Badge>
            )}
          </div>
          <div className="mt-2 text-xl font-bold text-[var(--vip-text)]">
            {vip?.is_vip ? `剩余 ${vip.days_remaining} 天` : "—"}
          </div>
          <div className="mt-1 text-xs text-[var(--vip-muted)]">
            {vip?.expires_at ? `到期时间：${vip.expires_at.slice(0, 10)}` : "购买代刷套餐即赠 VIP"}
          </div>
        </div>

        <div className="rounded-[var(--vip-radius)] border border-[var(--vip-line)] bg-[var(--vip-surface)] p-5 shadow-[var(--vip-shadow)]">
          <div className="text-xs text-[var(--vip-muted)]">备份状态</div>
          <div className="mt-2 text-xl font-bold text-[var(--vip-green)]">
            {vip?.has_backup ? "备份正常" : "暂无备份"}
          </div>
          <div className="mt-1 text-xs text-[var(--vip-muted)]">
            最新备份：{vip?.last_backup ? formatDateTime(vip.last_backup) : "尚未创建备份"}
          </div>
        </div>

        <div className="rounded-[var(--vip-radius)] border border-[var(--vip-line)] bg-[var(--vip-surface)] p-5 shadow-[var(--vip-shadow)]">
          <div className="text-xs text-[var(--vip-muted)]">备份数量</div>
          <div className="mt-2 text-xl font-bold text-[var(--vip-text)]">
            {vip?.backup_count ?? 0} / {vip?.backup_limit ?? 7}
          </div>
          <div className="mt-1 text-xs text-[var(--vip-muted)]">最多保留 7 个备份点</div>
        </div>
      </div>

      {/* 操作按钮 */}
      <div className="flex flex-wrap gap-2">
        <Button
          className="bg-[var(--vip-blue)] text-white hover:bg-[var(--vip-blue-hover)]"
          disabled={!vip?.is_vip || busy}
          onClick={() => setConfirm("backup")}
        >
          <Database className="size-4" /> 立即备份
        </Button>
        <Button
          variant="outline"
          disabled={!vip?.is_vip || !vip?.has_backup || busy}
          onClick={() => { setSelectedBackup(null); setConfirm("restore"); }}
        >
          <ArrowCounterClockwise className="size-4" /> 恢复数据
        </Button>
        <Button
          variant="outline"
          className="border-[var(--vip-red)]/40 text-[var(--vip-red)] hover:bg-[var(--vip-red)]/5"
          disabled={!vip?.is_vip || !vip?.has_backup || busy}
          onClick={() => setConfirm("ban")}
        >
          <Prohibit className="size-4" /> 封禁恢复
        </Button>
      </div>

      {/* 备份记录表 */}
      <div className="rounded-[var(--vip-radius)] border border-[var(--vip-line)] bg-[var(--vip-surface)] shadow-[var(--vip-shadow)]">
        <div className="border-b border-[var(--vip-line)] px-5 py-4">
          <h3 className="flex items-center gap-2 text-sm font-semibold text-[var(--vip-text)]">
            <ShieldCheck className="size-4 text-[var(--vip-blue)]" /> 备份记录
          </h3>
        </div>
        {isLoading ? (
          <div className="py-14 text-center text-sm text-[var(--vip-muted)]">正在加载...</div>
        ) : items.length === 0 ? (
          <div className="flex flex-col items-center gap-2 py-14 text-center">
            <Database className="size-8 text-[var(--vip-muted)]/40" />
            <div className="text-sm text-[var(--vip-muted)]">暂无备份记录</div>
            <div className="text-xs text-[var(--vip-muted)]">温馨提示：建议定期备份数据，以确保在遇到问题时可以快速恢复</div>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>备份编号</TableHead>
                <TableHead>备份类型</TableHead>
                <TableHead>备份时间</TableHead>
                <TableHead>大小</TableHead>
                <TableHead>备份状态</TableHead>
                <TableHead>备注</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((b) => (
                <TableRow key={b.id}>
                  <TableCell className="font-mono text-xs">
                    #{b.id} {b.is_latest && <Badge className="ml-1 border-[var(--vip-blue)]/40 bg-[var(--vip-blue-soft)] text-[var(--vip-blue)]">最新</Badge>}
                  </TableCell>
                  <TableCell>{b.backup_type_label}</TableCell>
                  <TableCell className="text-xs text-[var(--vip-muted)]">{formatDateTime(b.created_at)}</TableCell>
                  <TableCell className="text-xs">{Math.round(b.size_bytes / 1024)} KB</TableCell>
                  <TableCell>
                    <Badge className="border-emerald-300 bg-emerald-50 text-[var(--vip-green)]">{b.status_label}</Badge>
                  </TableCell>
                  <TableCell className="text-xs text-[var(--vip-muted)]">{b.note}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>

      {/* 确认弹窗 */}
      <Dialog open={!!confirm} onOpenChange={(o) => !o && setConfirm(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>请确认本次操作</DialogTitle>
            <DialogDescription>
              {confirm === "backup" && "系统将立即为您的游戏账号创建一个新的数据备份点。最多保留 7 个备份点，新备份会自动淘汰最旧记录。"}
              {confirm === "restore" && "默认选择最新可用备份恢复数据，不会影响平台账号。"}
              {confirm === "ban" && "账号被封禁或删除时，使用最新备份申请恢复，解除屏蔽。"}
            </DialogDescription>
          </DialogHeader>
          {confirm === "restore" && items.length > 0 && (
            <div className="flex flex-col gap-2">
              <div className="text-xs font-medium text-[var(--vip-muted)]">选择备份点（默认最新）</div>
              <div className="flex max-h-48 flex-col gap-1 overflow-y-auto">
                {items.map((b) => (
                  <button
                    key={b.id}
                    onClick={() => setSelectedBackup(b.id)}
                    className={`flex items-center justify-between rounded-[8px] border px-3 py-2 text-left text-sm transition ${
                      (selectedBackup ?? items[0].id) === b.id
                        ? "border-[var(--vip-blue)] bg-[var(--vip-blue-soft)]"
                        : "border-[var(--vip-line)] hover:border-[var(--vip-blue)]/40"
                    }`}
                  >
                    <span className="text-[var(--vip-text)]">备份 #{b.id}</span>
                    <span className="text-xs text-[var(--vip-muted)]">{formatDateTime(b.created_at)}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirm(null)}>取消</Button>
            <Button
              className="bg-[var(--vip-blue)] text-white hover:bg-[var(--vip-blue-hover)]"
              disabled={busy}
              onClick={() => {
                if (confirm === "backup") backupMutation.mutate();
                else if (confirm === "restore") restoreMutation.mutate(selectedBackup ?? undefined);
                else if (confirm === "ban") banMutation.mutate();
              }}
            >
              {busy ? "处理中..." : "确认"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
