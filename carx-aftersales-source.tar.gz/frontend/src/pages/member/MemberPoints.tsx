import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Storefront, Car, Gift, MagnifyingGlass, Coins } from "phosphor-react";
import {
  getPointsCatalog,
  getPointsCarCatalog,
  redeemPoints,
  getErrorMessage,
} from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export default function MemberPoints() {
  const queryClient = useQueryClient();
  const [tab, setTab] = useState<"car" | "product">("car");
  const [category, setCategory] = useState<string>("all");
  const [search, setSearch] = useState("");
  const [pendingId, setPendingId] = useState<string | null>(null);

  const { data: carCatalog, isLoading: loadingCars } = useQuery({
    queryKey: ["points-cars"],
    queryFn: getPointsCarCatalog,
  });
  const { data: prodCatalog, isLoading: loadingProds } = useQuery({
    queryKey: ["points-products"],
    queryFn: getPointsCatalog,
  });

  const redeemMutation = useMutation({
    mutationFn: redeemPoints,
    onSuccess: (r) => {
      toast.success(`兑换成功，剩余积分 ${r.remaining_points}`);
      queryClient.invalidateQueries({ queryKey: ["my-orders"] });
      queryClient.invalidateQueries({ queryKey: ["points-cars"] });
      queryClient.invalidateQueries({ queryKey: ["points-products"] });
    },
    onError: (e) => toast.error(getErrorMessage(e)),
    onSettled: () => setPendingId(null),
  });

  const balance = tab === "car" ? carCatalog?.points_balance ?? 0 : prodCatalog?.points_balance ?? 0;

  const carCategories = carCatalog?.categories ?? [];
  const filteredCars = useMemo(() => {
    let list = carCatalog?.cars ?? [];
    if (category !== "all") list = list.filter((c) => c.category === category);
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      list = list.filter((c) => c.name.toLowerCase().includes(q) || c.car_id.includes(q) || c.category.toLowerCase().includes(q));
    }
    return list;
  }, [carCatalog, category, search]);

  const prodCategories = prodCatalog?.categories ?? [];
  const filteredProds = useMemo(() => {
    let list = prodCatalog?.products ?? [];
    if (category !== "all") list = list.filter((p) => p.category === category);
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      list = list.filter((p) => p.name.toLowerCase().includes(q) || p.category.toLowerCase().includes(q));
    }
    return list;
  }, [prodCatalog, category, search]);

  const redeem = (kind: "product" | "car", id: number | string) => {
    setPendingId(`${kind}-${id}`);
    redeemMutation.mutate({ kind, id: Number(id) });
  };

  const switchTab = (t: "car" | "product") => {
    setTab(t);
    setCategory("all");
    setSearch("");
  };

  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-[var(--vip-text)]">积分商城</h1>
          <p className="mt-1 text-sm text-[var(--vip-muted)]">使用积分兑换车辆与平台商品</p>
        </div>
        <div className="flex items-center gap-2 rounded-[10px] border border-[var(--vip-line)] bg-[var(--vip-surface)] px-4 py-2 shadow-[var(--vip-shadow)]">
          <Coins className="size-4 text-[var(--vip-blue)]" weight="fill" />
          <span className="text-sm text-[var(--vip-muted)]">当前积分</span>
          <span className="text-lg font-bold text-[var(--vip-blue)]">{balance}</span>
        </div>
      </div>

      {/* 车辆/商品切换 + 搜索 */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex gap-1 rounded-[10px] border border-[var(--vip-line)] bg-[var(--vip-surface)] p-1">
          <button
            onClick={() => switchTab("car")}
            className={cn("flex items-center gap-1.5 rounded-[8px] px-3.5 py-1.5 text-sm font-medium transition",
              tab === "car" ? "bg-[var(--vip-blue)] text-white" : "text-[var(--vip-muted)] hover:text-[var(--vip-text)]")}
          >
            <Car className="size-4" /> 车辆兑换
          </button>
          <button
            onClick={() => switchTab("product")}
            className={cn("flex items-center gap-1.5 rounded-[8px] px-3.5 py-1.5 text-sm font-medium transition",
              tab === "product" ? "bg-[var(--vip-blue)] text-white" : "text-[var(--vip-muted)] hover:text-[var(--vip-text)]")}
          >
            <Gift className="size-4" /> 平台商品
          </button>
        </div>
        <div className="relative ml-auto">
          <MagnifyingGlass className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-[var(--vip-muted)]" />
          <Input
            placeholder={tab === "car" ? "搜索车辆序号 / 名称 / 分类" : "搜索商品名称 / 分类"}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-64 pl-9"
          />
        </div>
      </div>

      {/* 分类 chips */}
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => setCategory("all")}
          className={cn("rounded-full border px-3.5 py-1.5 text-xs font-medium transition",
            category === "all" ? "border-[var(--vip-blue)] bg-[var(--vip-blue)] text-white" : "border-[var(--vip-line)] bg-[var(--vip-surface)] text-[var(--vip-muted)] hover:border-[var(--vip-blue)]/40")}
        >
          全部
        </button>
        {(tab === "car" ? carCategories.map((c) => c.category) : prodCategories).map((cat) => (
          <button
            key={cat}
            onClick={() => setCategory(cat)}
            className={cn("rounded-full border px-3.5 py-1.5 text-xs font-medium transition",
              category === cat ? "border-[var(--vip-blue)] bg-[var(--vip-blue)] text-white" : "border-[var(--vip-line)] bg-[var(--vip-surface)] text-[var(--vip-muted)] hover:border-[var(--vip-blue)]/40")}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* 内容网格 */}
      {tab === "car" ? (
        loadingCars ? (
          <div className="py-14 text-center text-sm text-[var(--vip-muted)]">正在加载积分商城</div>
        ) : filteredCars.length === 0 ? (
          <EmptyShop text="暂无可兑换车辆" />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {filteredCars.map((c) => (
              <div key={c.id} className="overflow-hidden rounded-[var(--vip-radius)] border border-[var(--vip-line)] bg-[var(--vip-surface)] shadow-[var(--vip-shadow)]">
                <div className="flex h-28 items-center justify-center bg-[var(--vip-soft)]">
                  {c.image_url ? (
                    <img src={c.image_url} alt={c.name} className="h-full w-full object-cover" />
                  ) : (
                    <Car className="size-10 text-[var(--vip-muted)]/30" weight="duotone" />
                  )}
                </div>
                <div className="p-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-semibold text-[var(--vip-text)]">{c.name}</span>
                    <Badge variant="outline" className="text-[var(--vip-muted)]">{c.category}</Badge>
                  </div>
                  <div className="mt-0.5 text-xs text-[var(--vip-muted)]">车辆序号 #{c.car_id}</div>
                  <div className="mt-3 flex items-center justify-between">
                    <span className="flex items-center gap-1 text-sm font-bold text-[var(--vip-blue)]">
                      <Coins className="size-4" weight="fill" /> {c.price} 积分
                    </span>
                    <Button
                      size="sm"
                      className="bg-[var(--vip-blue)] text-white hover:bg-[var(--vip-blue-hover)]"
                      disabled={pendingId === `car-${c.id}` || !c.can_afford}
                      onClick={() => redeem("car", c.id)}
                    >
                      {pendingId === `car-${c.id}` ? "兑换中" : c.can_afford ? "兑换" : "积分不足"}
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )
      ) : loadingProds ? (
        <div className="py-14 text-center text-sm text-[var(--vip-muted)]">正在加载积分商城</div>
      ) : filteredProds.length === 0 ? (
        <EmptyShop text="暂无可兑换商品" />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {filteredProds.map((p) => (
            <div key={p.id} className="flex flex-col rounded-[var(--vip-radius)] border border-[var(--vip-line)] bg-[var(--vip-surface)] p-4 shadow-[var(--vip-shadow)]">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold text-[var(--vip-text)]">{p.name}</span>
                <Badge variant="outline" className="text-[var(--vip-muted)]">{p.category}</Badge>
              </div>
              <p className="mt-1 flex-1 text-xs text-[var(--vip-muted)]">{p.package_summary || p.description}</p>
              <div className="mt-3 flex items-center justify-between">
                <span className="flex items-center gap-1 text-sm font-bold text-[var(--vip-blue)]">
                  <Coins className="size-4" weight="fill" /> {p.price} 积分
                </span>
                <Button
                  size="sm"
                  className="bg-[var(--vip-blue)] text-white hover:bg-[var(--vip-blue-hover)]"
                  disabled={pendingId === `product-${p.id}` || !p.can_afford}
                  onClick={() => redeem("product", p.id)}
                >
                  {pendingId === `product-${p.id}` ? "兑换中" : p.can_afford ? "兑换" : "积分不足"}
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function EmptyShop({ text }: { text: string }) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-[var(--vip-radius)] border border-dashed border-[var(--vip-line)] py-14 text-center">
      <Storefront className="size-8 text-[var(--vip-muted)]/40" />
      <div className="text-sm text-[var(--vip-muted)]">{text}</div>
    </div>
  );
}
