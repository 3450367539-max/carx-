import { useQuery } from "@tanstack/react-query";
import { Crown, GameController, Coins, ShieldCheck, User as UserIcon } from "phosphor-react";
import { useAuth } from "@/lib/auth";
import { getVipStatus } from "@/lib/api";
import { formatDateTime } from "@/lib/format";
import { Badge } from "@/components/ui/badge";

export default function MemberAccount() {
  const { user } = useAuth();
  const { data: vip } = useQuery({ queryKey: ["vip-status"], queryFn: getVipStatus });

  return (
    <div className="flex flex-col gap-5">
      <div>
        <h1 className="text-xl font-bold text-[var(--vip-text)]">账号信息</h1>
        <p className="mt-1 text-sm text-[var(--vip-muted)]">查看平台账号、会员和游戏账号绑定状态</p>
      </div>

      <div className="grid gap-5 lg:grid-cols-3">
        {/* 平台账号卡 */}
        <div className="rounded-[var(--vip-radius)] border border-[var(--vip-line)] bg-[var(--vip-surface)] p-5 shadow-[var(--vip-shadow)]">
          <div className="flex items-center gap-3">
            <div className="flex size-12 items-center justify-center rounded-full bg-[var(--vip-blue-soft)] text-[var(--vip-blue)]">
              <UserIcon className="size-6" weight="duotone" />
            </div>
            <div className="min-w-0">
              <div className="truncate text-sm font-semibold text-[var(--vip-text)]">{user?.username}</div>
              <div className="text-xs text-[var(--vip-muted)]">平台账号</div>
            </div>
          </div>
          <div className="mt-4 flex flex-col gap-3 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-[var(--vip-muted)]">账号角色</span>
              <Badge variant="outline" className="text-[var(--vip-text)]">
                {user?.role === "agent" ? "代理用户" : user?.role === "admin" ? "管理员" : "普通用户"}
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[var(--vip-muted)]">信用分</span>
              <span className="font-medium text-[var(--vip-text)]">{user?.credit_score}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[var(--vip-muted)]">注册时间</span>
              <span className="text-xs text-[var(--vip-text)]">{formatDateTime(user?.createdAt)}</span>
            </div>
          </div>
        </div>

        {/* 会员 / 游戏账号 / 积分 摘要卡 */}
        <div className="lg:col-span-2 grid gap-4 sm:grid-cols-3">
          <div className="rounded-[var(--vip-radius)] border border-[var(--vip-line)] bg-[var(--vip-surface)] p-5 shadow-[var(--vip-shadow)]">
            <div className="flex size-10 items-center justify-center rounded-[10px] bg-amber-50 text-amber-500">
              <Crown className="size-5" weight="duotone" />
            </div>
            <div className="mt-3 text-xs text-[var(--vip-muted)]">会员到期</div>
            <div className="mt-1 text-lg font-bold text-[var(--vip-text)]">
              {vip?.is_vip ? `${vip.days_remaining} 天` : "未开通"}
            </div>
            <div className="mt-1 text-xs text-[var(--vip-muted)]">
              {vip?.expires_at ? `到期时间：${vip.expires_at.slice(0, 10)}` : "至臻会员"}
            </div>
          </div>

          <div className="rounded-[var(--vip-radius)] border border-[var(--vip-line)] bg-[var(--vip-surface)] p-5 shadow-[var(--vip-shadow)]">
            <div className="flex size-10 items-center justify-center rounded-[10px] bg-[var(--vip-blue-soft)] text-[var(--vip-blue)]">
              <Coins className="size-5" weight="duotone" />
            </div>
            <div className="mt-3 text-xs text-[var(--vip-muted)]">当前积分</div>
            <div className="mt-1 text-lg font-bold text-[var(--vip-text)]">{user?.single_car_points ?? 0}</div>
            <div className="mt-1 text-xs text-[var(--vip-muted)]">用于兑换车辆和平台商品</div>
          </div>

          <div className="rounded-[var(--vip-radius)] border border-[var(--vip-line)] bg-[var(--vip-surface)] p-5 shadow-[var(--vip-shadow)]">
            <div className="flex size-10 items-center justify-center rounded-[10px] bg-emerald-50 text-[var(--vip-green)]">
              <GameController className="size-5" weight="duotone" />
            </div>
            <div className="mt-3 text-xs text-[var(--vip-muted)]">游戏数据</div>
            <div className="mt-1">
              {user?.has_carx_bound ? (
                <Badge className="border-emerald-300 bg-emerald-50 text-[var(--vip-green)]">已绑定</Badge>
              ) : (
                <Badge variant="outline" className="text-[var(--vip-muted)]">未绑定</Badge>
              )}
            </div>
            <div className="mt-1 truncate font-mono text-xs text-[var(--vip-muted)]">{user?.carx_email || "—"}</div>
          </div>
        </div>
      </div>

      {/* 数据保护提示 */}
      <div className="flex items-start gap-3 rounded-[var(--vip-radius)] border border-[var(--vip-line)] bg-[var(--vip-surface)] p-5 shadow-[var(--vip-shadow)]">
        <ShieldCheck className="mt-0.5 size-5 shrink-0 text-[var(--vip-blue)]" weight="duotone" />
        <div>
          <div className="text-sm font-semibold text-[var(--vip-text)]">数据保护</div>
          <p className="mt-1 text-sm text-[var(--vip-muted)]">
            温馨提示：建议定期备份数据，以确保在遇到问题时可以快速恢复。请勿修改游戏密码，修改游戏密码等于自动放弃售后。
          </p>
        </div>
      </div>
    </div>
  );
}
