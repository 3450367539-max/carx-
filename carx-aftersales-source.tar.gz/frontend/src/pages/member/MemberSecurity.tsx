import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { LockKey, ShieldCheck, SignOut, CheckCircle } from "phosphor-react";
import { useAuth } from "@/lib/auth";
import { changePassword, getErrorMessage } from "@/lib/api";
import { useNavigate } from "react-router-dom";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function MemberSecurity() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [oldPw, setOldPw] = useState("");
  const [newPw, setNewPw] = useState("");
  const [confirmPw, setConfirmPw] = useState("");

  const pwMutation = useMutation({
    mutationFn: () => changePassword(oldPw, newPw),
    onSuccess: () => {
      toast.success("密码已更新");
      setOldPw(""); setNewPw(""); setConfirmPw("");
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPw.length < 6) { toast.error("新密码至少 6 位"); return; }
    if (newPw !== confirmPw) { toast.error("两次输入的新密码不一致"); return; }
    pwMutation.mutate();
  };

  const handleLogout = () => {
    logout();
    queryClient.clear();
    navigate("/login");
  };

  return (
    <div className="flex flex-col gap-5">
      <div>
        <h1 className="text-xl font-bold text-[var(--vip-text)]">安全设置</h1>
        <p className="mt-1 text-sm text-[var(--vip-muted)]">查看当前登录状态并管理账号会话</p>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        {/* 会话状态 */}
        <div className="rounded-[var(--vip-radius)] border border-[var(--vip-line)] bg-[var(--vip-surface)] p-5 shadow-[var(--vip-shadow)]">
          <h3 className="flex items-center gap-2 text-sm font-semibold text-[var(--vip-text)]">
            <ShieldCheck className="size-4 text-[var(--vip-blue)]" weight="duotone" /> 当前会话
          </h3>
          <div className="mt-4 flex items-center gap-2 text-sm text-[var(--vip-green)]">
            <CheckCircle className="size-4" weight="fill" /> 当前会话正常
          </div>
          <p className="mt-2 text-xs text-[var(--vip-muted)]">
            账号已通过安全验证，退出后需要重新登录。
          </p>
          <div className="mt-4 border-t border-[var(--vip-line)] pt-4">
            <div className="flex items-center justify-between text-sm">
              <span className="text-[var(--vip-muted)]">登录账号</span>
              <span className="text-[var(--vip-text)]">{user?.username}</span>
            </div>
            <Button
              variant="outline"
              className="mt-4 w-full border-[var(--vip-red)]/40 text-[var(--vip-red)] hover:bg-[var(--vip-red)]/5"
              onClick={handleLogout}
            >
              <SignOut className="size-4" /> 退出登录
            </Button>
          </div>
        </div>

        {/* 修改密码 */}
        <div className="rounded-[var(--vip-radius)] border border-[var(--vip-line)] bg-[var(--vip-surface)] p-5 shadow-[var(--vip-shadow)]">
          <h3 className="flex items-center gap-2 text-sm font-semibold text-[var(--vip-text)]">
            <LockKey className="size-4 text-[var(--vip-blue)]" weight="duotone" /> 修改密码
          </h3>
          <form onSubmit={submit} className="mt-4 flex flex-col gap-3">
            <div className="flex flex-col gap-1.5">
              <Label>原密码</Label>
              <Input type="password" value={oldPw} onChange={(e) => setOldPw(e.target.value)} autoComplete="current-password" />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>新密码</Label>
              <Input type="password" value={newPw} onChange={(e) => setNewPw(e.target.value)} autoComplete="new-password" />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>确认新密码</Label>
              <Input type="password" value={confirmPw} onChange={(e) => setConfirmPw(e.target.value)} autoComplete="new-password" />
            </div>
            <Button
              type="submit"
              className="bg-[var(--vip-blue)] text-white hover:bg-[var(--vip-blue-hover)]"
              disabled={pwMutation.isPending}
            >
              {pwMutation.isPending ? "提交中..." : "保存修改"}
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
