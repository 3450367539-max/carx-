import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Receipt, MagnifyingGlass, ShoppingBag, X } from "phosphor-react";
import {
  getMyOrders,
  getPublicProducts,
  createOrder,
  selfClaim,
  getErrorMessage,
  type Order,
} from "@/lib/api";
import { orderStatusMeta, orderFilterTabs } from "@/lib/status";
import { formatCurrency, formatDateTime } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function MemberOrders() {
  const queryClient = useQueryClient();
  const [filter, setFilter] = useState<string>("all");
  const [search, setSearch] = useState("");
  const [detail, setDetail] = useState<Order | null>(null);
  const [claimOrder, setClaimOrder] = useState<Order | null>(null);
  const [claimNote, setClaimNote] = useState("");
  const [newEmail, setNewEmail] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [buyOpen, setBuyOpen] = useState(false);

  const { data: orders, isLoading } = useQuery({ queryKey: ["my-orders"], queryFn: getMyOrders });
  const { data: products } = useQuery({ queryKey: ["public-products"], queryFn: getPublicProducts });

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ["my-orders"] });

  const buyMutation = useMutation({
    mutationFn: (id: number) => createOrder(id),
    onSuccess: () => { toast.success("下单成功，套餐正在发货中"); setBuyOpen(false); invalidate(); queryClient.invalidateQueries({ queryKey: ["vip-status"] }); },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const claimMutation = useMutation({
    mutationFn: selfClaim,
    onSuccess: () => {
      toast.success("理赔已提交，客服将尽快处理");
      setClaimOrder(null); setClaimNote(""); setNewEmail(""); setNewPassword("");
      queryClient.invalidateQueries({ queryKey: ["my-warranty"] });
    },
    onError: (e) => toast.error(getErrorMessage(e)),
  });

  const filtered = useMemo(() => {
    let list = orders ?? [];
    if (filter === "pending") list = list.filter((o) => o.status === "PENDING" || o.status === "PROCESSING");
    else if (filter === "completed") list = list.filter((o) => o.status === "COMPLETED");
    else if (filter === "warranty") list = list.filter((o) => o.warranty_expires_at && !o.is_expired);
    else if (filter === "expired") list = list.filter((o) => o.is_expired);
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      list = list.filter((o) => o.product_name.toLowerCase().includes(q) || o.display_no.toLowerCase().includes(q));
    }
    return list;
  }, [orders, filter, search]);

  const buyableProducts = (products ?? []).filter((p) => p.base_price > 0);

  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-[var(--vip-text)]">购买记录</h1>
          <p className="mt-1 text-sm text-[var(--vip-muted)]">查看您的订单状态、下单时间和售后入口</p>
        </div>
        <Button className="bg-[var(--vip-blue)] text-white hover:bg-[var(--vip-blue-hover)]" onClick={() => setBuyOpen(true)}>
          <ShoppingBag className="size-4" /> 购买套餐
        </Button>
      </div>

      {/* 筛选 + 搜索 */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex gap-1 rounded-[10px] border border-[var(--vip-line)] bg-[var(--vip-surface)] p-1">
          {orderFilterTabs.map((t) => (
            <button
              key={t.key}
              onClick={() => setFilter(t.key)}
              className={cn(
                "rounded-[8px] px-3.5 py-1.5 text-sm font-medium transition",
                filter === t.key
                  ? "bg-[var(--vip-blue)] text-white"
                  : "text-[var(--vip-muted)] hover:text-[var(--vip-text)]"
              )}
            >
              {t.label}
            </button>
          ))}
        </div>
        <div className="relative ml-auto">
          <MagnifyingGlass className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-[var(--vip-muted)]" />
          <Input
            placeholder="请输入订单号或商品名称"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-64 pl-9"
          />
        </div>
      </div>

      {/* 订单表 */}
      <div className="rounded-[var(--vip-radius)] border border-[var(--vip-line)] bg-[var(--vip-surface)] shadow-[var(--vip-shadow)]">
        {isLoading ? (
          <div className="py-14 text-center text-sm text-[var(--vip-muted)]">正在加载...</div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center gap-2 py-14 text-center">
            <Receipt className="size-8 text-[var(--vip-muted)]/40" />
            <div className="text-sm text-[var(--vip-muted)]">
              {filter === "all" && !search ? "暂无订单" : "暂无符合条件的订单"}
            </div>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>订单号</TableHead>
                <TableHead>商品</TableHead>
                <TableHead>商品类型</TableHead>
                <TableHead>金额</TableHead>
                <TableHead>订单状态</TableHead>
                <TableHead>下单时间</TableHead>
                <TableHead className="text-right">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((o) => (
                <TableRow key={o.order_id}>
                  <TableCell className="font-mono text-xs">{o.display_no}</TableCell>
                  <TableCell className="font-medium text-[var(--vip-text)]">{o.product_name}</TableCell>
                  <TableCell><Badge variant="outline" className="text-[var(--vip-muted)]">{o.order_type_label}</Badge></TableCell>
                  <TableCell>{o.amount > 0 ? formatCurrency(o.amount) : "—"}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className={orderStatusMeta[o.status].className}>
                      {orderStatusMeta[o.status].label}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-xs text-[var(--vip-muted)]">{formatDateTime(o.created_at)}</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm" className="text-[var(--vip-blue)]" onClick={() => setDetail(o)}>
                      查看详情
                    </Button>
                    {o.warranty_expires_at && !o.is_expired && o.status === "COMPLETED" && (
                      <Button variant="ghost" size="sm" className="text-[var(--vip-amber)]" onClick={() => setClaimOrder(o)}>
                        申请售后
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </div>

      {/* 购买套餐弹窗 */}
      <Dialog open={buyOpen} onOpenChange={setBuyOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>购买代刷套餐</DialogTitle>
            <DialogDescription>选择套餐下单，发货完成后开始计算保修期</DialogDescription>
          </DialogHeader>
          <div className="grid max-h-96 gap-3 overflow-y-auto sm:grid-cols-2">
            {buyableProducts.map((p) => (
              <div key={p.id} className="flex flex-col rounded-[10px] border border-[var(--vip-line)] p-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-semibold text-[var(--vip-text)]">{p.name}</span>
                  {p.grants_vip && <Badge className="border-amber-300 bg-amber-50 text-amber-600">赠 VIP</Badge>}
                </div>
                <p className="mt-1 flex-1 text-xs text-[var(--vip-muted)]">{p.delivery_label || p.description}</p>
                <div className="mt-3 flex items-center justify-between">
                  <span className="text-base font-bold text-[var(--vip-blue)]">{formatCurrency(p.base_price)}</span>
                  <Button
                    size="sm"
                    className="bg-[var(--vip-blue)] text-white hover:bg-[var(--vip-blue-hover)]"
                    disabled={buyMutation.isPending}
                    onClick={() => buyMutation.mutate(p.id)}
                  >
                    立即购买
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* 订单详情弹窗 */}
      <Dialog open={!!detail} onOpenChange={(o) => !o && setDetail(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>订单详情</DialogTitle>
          </DialogHeader>
          {detail && (
            <div className="flex flex-col gap-3 text-sm">
              <div className="flex justify-between"><span className="text-[var(--vip-muted)]">订单号</span><span className="font-mono text-xs">{detail.display_no}</span></div>
              <div className="flex justify-between"><span className="text-[var(--vip-muted)]">商品</span><span className="font-medium">{detail.product_name}</span></div>
              <div className="flex justify-between"><span className="text-[var(--vip-muted)]">商品类型</span><span>{detail.order_type_label}</span></div>
              <div className="flex justify-between"><span className="text-[var(--vip-muted)]">金额</span><span>{formatCurrency(detail.amount)}</span></div>
              <div className="flex justify-between"><span className="text-[var(--vip-muted)]">订单状态</span>
                <Badge variant="outline" className={orderStatusMeta[detail.status].className}>{orderStatusMeta[detail.status].label}</Badge>
              </div>
              <div className="flex justify-between"><span className="text-[var(--vip-muted)]">下单时间</span><span className="text-xs">{formatDateTime(detail.created_at)}</span></div>
              <div className="flex justify-between"><span className="text-[var(--vip-muted)]">保修到期</span>
                <span className="text-xs">{detail.warranty_expires_at ? (detail.is_expired ? "已过期" : detail.warranty_expires_at.slice(0, 10)) : "—"}</span>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDetail(null)}>
              <X className="size-4" /> 关闭订单详情
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 申请售后/理赔弹窗 */}
      <Dialog open={!!claimOrder} onOpenChange={(o) => !o && setClaimOrder(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>申请售后理赔</DialogTitle>
            <DialogDescription>
              系统会把理赔补发内容转移到你现在填写的新游戏账号。请确认新账号可正常登录。
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-3">
            <div className="rounded-[8px] bg-[var(--vip-soft)] p-3 text-xs text-[var(--vip-muted)]">
              涉及商品：<span className="font-medium text-[var(--vip-text)]">{claimOrder?.product_name}</span>（订单号：{claimOrder?.display_no}）
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>新游戏邮箱</Label>
              <Input placeholder="输入新的游戏邮箱" value={newEmail} onChange={(e) => setNewEmail(e.target.value)} />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>新游戏密码</Label>
              <Input placeholder="输入新的游戏密码" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>备注</Label>
              <Textarea placeholder="请描述您遇到的问题…" value={claimNote} onChange={(e) => setClaimNote(e.target.value)} rows={3} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setClaimOrder(null)}>取消</Button>
            <Button
              className="bg-[var(--vip-blue)] text-white hover:bg-[var(--vip-blue-hover)]"
              disabled={claimMutation.isPending}
              onClick={() => {
                if (!claimOrder) return;
                claimMutation.mutate({
                  claim_type: "warranty",
                  order_id: claimOrder.order_id,
                  note: claimNote,
                  new_carx_email: newEmail,
                  new_carx_password: newPassword,
                });
              }}
            >
              {claimMutation.isPending ? "提交中..." : "确认提交理赔"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
