import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import {
  ShoppingBag,
  KeyRound,
  Crown,
  Coins,
  ArrowRight,
  Menu,
  Gamepad2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { getPublicDisplayConfig, getPublicProducts } from "@/lib/api";
import { formatCurrency } from "@/lib/format";

const features = [
  {
    icon: ShoppingBag,
    title: "代刷套餐",
    desc: "四刷 / 六刷 / 八刷 / 全付费车，银币金币满级全图，一键到账。",
  },
  {
    icon: KeyRound,
    title: "成品号与卡密",
    desc: "已代刷完成的成品号与客户端授权 CDK，即买即用。",
  },
  {
    icon: Crown,
    title: "VIP 售后",
    desc: "每日凌晨自动备份账号数据，封禁一键恢复，售后无忧。",
  },
  {
    icon: Coins,
    title: "积分商城",
    desc: "单车轮点数兑换游戏内车辆与道具，海量涂装车随心换。",
  },
];

export default function Index() {
  const { data: config } = useQuery({
    queryKey: ["public-display-config"],
    queryFn: getPublicDisplayConfig,
  });
  const { data: products } = useQuery({
    queryKey: ["public-products"],
    queryFn: getPublicProducts,
  });

  const siteName = config?.site_name || "CARX 售后中心";
  const slogan = config?.slogan || "专业 · 透明 · 高效 的游戏账号售后平台";
  const images = config?.showroom_background_images ?? [];

  const [index, setIndex] = useState(0);

  useEffect(() => {
    if (images.length <= 1) return;
    const timer = setInterval(() => {
      setIndex((i) => (i + 1) % images.length);
    }, 7000);
    return () => clearInterval(timer);
  }, [images.length]);

  const showcase = (products ?? []).filter((p) => p.base_price > 0).slice(0, 3);

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Top navigation */}
      <header className="absolute inset-x-0 top-0 z-30">
        <div className="container flex h-16 items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Gamepad2 className="size-6 text-white" />
            <span className="text-xl font-black tracking-tight text-white">CARX</span>
            <span className="hidden text-sm text-white/70 sm:inline">售后中心</span>
          </Link>
          <nav className="flex items-center gap-2">
            <Button
              asChild
              variant="ghost"
              className="hidden text-white hover:bg-white/10 hover:text-white sm:inline-flex"
            >
              <Link to="/register">注册账号</Link>
            </Button>
            <Button asChild className="bg-theme-red text-white hover:bg-theme-red/90">
              <Link to="/login">进入会员中心</Link>
            </Button>
            <Button
              asChild
              variant="ghost"
              size="icon"
              className="text-white hover:bg-white/10 hover:text-white sm:hidden"
            >
              <Link to="/login">
                <Menu className="size-5" />
              </Link>
            </Button>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <section className="relative flex min-h-screen items-center overflow-hidden bg-gradient-to-br from-zinc-950 via-zinc-900 to-theme-red/30">
        <div className="absolute inset-0 bg-gradient-to-br from-zinc-950 via-zinc-900 to-theme-red/30" />
        {images.length > 0
          ? images.map((src, i) => (
              <div
                key={src}
                className="absolute inset-0 bg-cover bg-center transition-opacity duration-1000"
                style={{ backgroundImage: `url(${src})`, opacity: i === index ? 1 : 0 }}
              />
            ))
          : null}
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/70" />

        <div className="container relative z-10 text-center">
          <div className="mx-auto max-w-3xl">
            <span className="inline-block rounded-full border border-white/30 bg-white/10 px-4 py-1 text-xs font-medium tracking-widest text-white/90">
              {siteName}
            </span>
            <h1 className="mt-6 text-5xl font-black tracking-tight text-white sm:text-7xl">
              CARX
            </h1>
            <p className="mx-auto mt-4 max-w-xl text-lg text-white/85 sm:text-xl">
              {slogan}
            </p>
            <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <Button asChild size="lg" className="bg-theme-red text-white hover:bg-theme-red/90">
                <Link to="/login">
                  进入会员中心
                  <ArrowRight className="size-4" />
                </Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-white/40 bg-transparent text-white hover:bg-white/10 hover:text-white"
              >
                <Link to="/register">注册账号</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Product showcase */}
      {showcase.length > 0 && (
        <section className="container py-16">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-3xl font-bold tracking-tight">热门代刷套餐</h2>
            <p className="mt-3 text-muted-foreground">
              银币 · 金币 · 满级 · 全图 · 全付费车，一站式代刷服务。
            </p>
          </div>
          <div className="mt-10 grid gap-6 sm:grid-cols-3">
            {showcase.map((p) => (
              <div
                key={p.id}
                className="flex flex-col rounded-xl border bg-card p-6 shadow-sm transition-shadow hover:shadow-md"
              >
                <h3 className="text-lg font-semibold">{p.name}</h3>
                <p className="mt-2 flex-1 text-sm text-muted-foreground">{p.description}</p>
                <div className="mt-4 flex items-center justify-between">
                  <span className="text-xl font-bold text-theme-red">
                    {formatCurrency(p.base_price)}
                  </span>
                  <Button asChild size="sm" variant="outline">
                    <Link to="/login">购买</Link>
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Features */}
      <section className="container py-20">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight">平台服务</h2>
          <p className="mt-3 text-muted-foreground">
            从代刷到售后，为您提供专业、透明、安心的游戏账号服务。
          </p>
        </div>
        <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((f) => (
            <div
              key={f.title}
              className="rounded-xl border bg-card p-6 shadow-sm transition-shadow hover:shadow-md"
            >
              <div className="flex size-12 items-center justify-center rounded-lg bg-theme-red/10 text-theme-red">
                <f.icon className="size-6" />
              </div>
              <h3 className="mt-4 text-lg font-semibold">{f.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-card">
        <div className="container flex flex-col items-center justify-between gap-4 py-8 sm:flex-row">
          <div className="flex items-center gap-2">
            <span className="text-lg font-black tracking-tight">CARX</span>
            <span className="text-sm text-muted-foreground">售后中心</span>
          </div>
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} CARX After-sales Center. 保留所有权利。
          </p>
        </div>
      </footer>
    </div>
  );
}
