import { useState } from "react";
import { Link, Navigate } from "react-router-dom";
import { toast } from "sonner";
import { Gamepad2, Loader2 } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { login, getErrorMessage } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { SliderCaptcha } from "@/components/SliderCaptcha";

export default function Login() {
  const { user, login: authLogin } = useAuth();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(true);
  const [captchaToken, setCaptchaToken] = useState("");
  const [captchaPassed, setCaptchaPassed] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  if (user) {
    return <Navigate to={user.role === "user" ? "/console" : "/admin"} replace />;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!captchaPassed || !captchaToken) {
      toast.error("请先拖动滑块完成验证");
      return;
    }
    if (!username || !password) {
      toast.error("请输入账号与密码");
      return;
    }
    setSubmitting(true);
    try {
      const res = await login({
        username,
        password,
        captcha_token: captchaToken,
        captcha_value: 100,
      });
      authLogin(res.token, res.user);
      toast.success("登录成功");
    } catch (err) {
      toast.error(getErrorMessage(err));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-zinc-900 via-zinc-800 to-theme-red/40 p-4">
      <div className="w-full max-w-md rounded-2xl border bg-card p-8 shadow-xl">
        <div className="mb-6 flex flex-col items-center text-center">
          <div className="flex size-12 items-center justify-center rounded-xl bg-theme-red text-white">
            <Gamepad2 className="size-6" />
          </div>
          <h1 className="mt-4 text-2xl font-bold">CARX 售后中心</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            登录以管理您的游戏账号与售后权益
          </p>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div className="flex flex-col gap-2">
            <Label htmlFor="username">账号 / 邮箱</Label>
            <Input
              id="username"
              autoComplete="username"
              placeholder="游戏账号或邮箱"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
          </div>

          <div className="flex flex-col gap-2">
            <Label htmlFor="password">密码</Label>
            <Input
              id="password"
              type="password"
              autoComplete="current-password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>

          <div className="flex flex-col gap-2">
            <Label>安全验证</Label>
            <SliderCaptcha
              onChange={(token, passed) => {
                setCaptchaToken(token);
                setCaptchaPassed(passed);
              }}
            />
          </div>

          <div className="flex items-center justify-between">
            <label className="flex items-center gap-2 text-sm text-muted-foreground">
              <Checkbox
                checked={remember}
                onCheckedChange={(v) => setRemember(v === true)}
              />
              记住我
            </label>
            <Link to="/register" className="text-sm text-theme-red hover:underline">
              没有账号？注册
            </Link>
          </div>

          <Button
            type="submit"
            className="mt-2 bg-theme-red text-white hover:bg-theme-red/90"
            disabled={submitting}
          >
            {submitting && <Loader2 className="size-4 animate-spin" />}
            登录
          </Button>
        </form>

        <p className="mt-6 rounded-lg bg-muted/60 p-3 text-center text-xs text-muted-foreground">
          测试账号 · 会员 ci3mr3kb9x@gmail.com / ikMfuXl7Mxer · 管理员 lzk323700 /
          Zzk1909..
        </p>
      </div>
    </div>
  );
}
