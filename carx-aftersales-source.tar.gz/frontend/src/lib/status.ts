import type { OrderStatus, WarrantyStatus, CardStatus } from "@/lib/api";

interface StatusMeta {
  label: string;
  className: string;
}

export const orderStatusMeta: Record<OrderStatus, StatusMeta> = {
  PENDING: { label: "待发货", className: "bg-amber-500/10 text-amber-600 border-amber-500/30" },
  PROCESSING: { label: "发货中", className: "bg-sky-500/10 text-sky-600 border-sky-500/30" },
  COMPLETED: { label: "已完成", className: "bg-emerald-500/10 text-emerald-600 border-emerald-500/30" },
  CANCELLED: { label: "已取消", className: "bg-slate-500/10 text-slate-500 border-slate-400/30" },
  REFUNDED: { label: "已理赔/退款", className: "bg-violet-500/10 text-violet-600 border-violet-500/30" },
};

/** 购买记录筛选标签（对齐真实：全部/待发货/已完成/可售后/已过期） */
export const orderFilterTabs = [
  { key: "all", label: "全部" },
  { key: "pending", label: "待发货" },
  { key: "completed", label: "已完成" },
  { key: "warranty", label: "可售后" },
  { key: "expired", label: "已过期" },
] as const;

export const warrantyStatusMeta: Record<WarrantyStatus, StatusMeta> = {
  pending: { label: "待受理", className: "bg-slate-500/10 text-slate-500 border-slate-400/30" },
  processing: { label: "处理中", className: "bg-amber-500/10 text-amber-600 border-amber-500/30" },
  resolved: { label: "已解决", className: "bg-emerald-500/10 text-emerald-600 border-emerald-500/30" },
  rejected: { label: "已驳回", className: "bg-red-500/10 text-red-600 border-red-500/30" },
};

export const cardStatusMeta: Record<CardStatus, StatusMeta> = {
  UNUSED: { label: "未使用", className: "bg-emerald-500/10 text-emerald-600 border-emerald-500/30" },
  REDEEMING: { label: "处理中", className: "bg-amber-500/10 text-amber-600 border-amber-500/30" },
  REDEEMED: { label: "已使用", className: "bg-sky-500/10 text-sky-600 border-sky-500/30" },
  DISABLED: { label: "已停用", className: "bg-slate-500/10 text-slate-500 border-slate-400/30" },
};

export const licenseStatusMeta: Record<string, StatusMeta> = {
  UNUSED: { label: "未激活", className: "bg-emerald-500/10 text-emerald-600 border-emerald-500/30" },
  ACTIVATED: { label: "已激活", className: "bg-sky-500/10 text-sky-600 border-sky-500/30" },
  REVOKED: { label: "已回收", className: "bg-red-500/10 text-red-600 border-red-500/30" },
  EXPIRED: { label: "已过期", className: "bg-slate-500/10 text-slate-500 border-slate-400/30" },
};

export const warrantyTypeLabel: Record<string, string> = {
  ban_recover: "封禁恢复",
  warranty: "保修",
};

export const agentTierLabel: Record<string, string> = {
  standard: "标准代理",
  sales: "销售代理",
  senior: "高级代理",
  aftersales: "售后代理",
};

export const agentStatusLabel: Record<string, string> = {
  active: "启用中",
  suspended: "已停用",
  archived: "已归档",
};
