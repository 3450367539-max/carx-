import { apiClient, getErrorMessage } from "@/lib/api-client";

export { getErrorMessage, apiClient };

/* ============================================================
   实体类型 — CarX 游戏账号 / 代刷 / 授权交易 SaaS
   ============================================================ */

export type Role = "user" | "agent" | "admin";
export type UserStatus = "active" | "disabled" | "banned";

export interface VipBackup {
  id: number;
  created_at: string;
  backup_type: "auto" | "manual";
  backup_type_label: string;
  status: "AVAILABLE" | "EXPIRED";
  status_label: string;
  note: string;
  is_latest: boolean;
  size_bytes: number;
}

export interface User {
  id: number;
  username: string;
  email: string;
  carx_email: string;
  role: Role;
  status: UserStatus;
  credit_score: number;
  single_car_points: number;
  has_carx_bound: boolean;
  agent_code: string;
  amount_owed: number;
  vip_expires_at: string | null;
  vip_backups: VipBackup[];
  createdAt: string;
}

export interface Product {
  id: number;
  name: string;
  description: string;
  icon: string | null;
  color: string | null;
  is_combo: boolean;
  delivery_label: string;
  base_price: number;
  warranty_days: number;
  is_active: boolean;
  points_redeem_price: number | null;
  grants_vip: boolean;
  vip_days: number;
  settlement_cost: number;
  allow_white_account_delivery: boolean;
  createdAt: string;
}

export type OrderStatus = "PENDING" | "PROCESSING" | "COMPLETED" | "CANCELLED" | "REFUNDED";

export interface Order {
  order_id: number;
  display_no: string;
  user_id: number;
  customer_username: string;
  product_name: string;
  amount: number;
  selling_price: number;
  status: OrderStatus;
  order_type: string;
  order_type_label: string;
  source_type: "user" | "agent";
  delivery_mode: string;
  agent_code: string;
  created_at: string;
  warranty_expires_at: string | null;
  is_expired: boolean;
}

export interface Announcement {
  id: number;
  title: string;
  content: string;
  target_role: "all" | "user" | "agent" | "admin";
  is_active: boolean;
  read_by: number[];
  expires_at: string | null;
  createdAt: string;
}

export interface CardSku {
  id: number;
  name: string;
  allow_batch_generation: boolean;
  redeem_enabled: boolean;
  warranty_enabled: boolean;
  grants_vip: boolean;
  warranty_days: number;
  vip_days: number;
  points_value: number;
  notes: string;
  is_active: boolean;
}

export interface CardBatch {
  id: number;
  batch_name: string;
  sku_id: number;
  product_id: number;
  agent_id: number | null;
  quantity: number;
  note: string;
  created_at: string;
}

export type CardStatus = "UNUSED" | "REDEEMING" | "REDEEMED" | "DISABLED";

export interface CardCode {
  id: number;
  code: string;
  sku_id: number;
  batch_id: number;
  status: CardStatus;
  redeemed_by: number | null;
  redeemed_at: string | null;
  sku_name?: string;
}

export interface Agent {
  id: number;
  username: string;
  promo_code: string;
  agent_code: string;
  tier: "standard" | "sales" | "senior" | "aftersales";
  commission_rate: number;
  status: "active" | "suspended" | "archived";
  amount_owed: number;
  max_debt_limit: number;
  max_daily_orders: number;
  business_start_date: string;
  last_settlement_at: string | null;
  createdAt: string;
}

export type WarrantyStatus = "pending" | "processing" | "resolved" | "rejected";

export interface WarrantyClaim {
  id: number;
  user_id: number;
  carx_email: string;
  order_id: number | null;
  claim_type: "ban_recover" | "warranty";
  status: WarrantyStatus;
  note: string;
  new_carx_email: string;
  new_carx_password: string;
  created_at: string;
}

export interface FinishedAccountProfile {
  id: number;
  code: string;
  name: string;
  product_id: number;
  email_prefix: string;
  email_domain: string;
  password_length: number;
  warranty_days_default: number;
  description: string;
  is_active: boolean;
}

export interface FinishedAccountOwnership {
  id: number;
  user_id: number;
  profile_id: number;
  code: string;
  claimed_at: string;
  profile?: FinishedAccountProfile;
}

export interface PointsProduct {
  id: string | number;
  product_id: number | null;
  name: string;
  description: string;
  delivery_label: string;
  package_summary: string;
  category: string;
  price: number;
  icon: string | null;
  color: string | null;
  image_url: string | null;
  type?: string;
  can_afford?: boolean;
}

export interface PointsCar {
  id: string | number;
  car_id: string;
  name: string;
  model: string;
  category: string;
  price: number;
  image_url: string | null;
  type?: string;
  can_afford?: boolean;
}

export interface ClientLicenseCode {
  id: number;
  code: string;
  kind: "version" | "feature";
  kind_label: string;
  status: "UNUSED" | "ACTIVATED" | "REVOKED" | "EXPIRED";
  days: number;
  activated_by: number | null;
  activated_at: string | null;
  created_at: string;
}

/* ============================================================
   显示配置
   ============================================================ */

export interface PublicDisplayConfig {
  site_name: string;
  slogan: string;
  showroom_background_images: string[];
  console_hero_images: string[];
  finished_account_hero_images: string[];
  registration_invite_required: boolean;
}

export interface AdminConfig {
  display: {
    site_name: string;
    slogan: string;
    showroom_background_images: string[];
    console_hero_images: string[];
    finished_account_hero_images: string[];
    registration_invite_required: boolean;
  };
  points_shop_enabled: boolean;
  cards_enabled: boolean;
  agent_application_open: boolean;
}

/* ============================================================
   认证
   ============================================================ */

export interface AuthResponse {
  token: string;
  user: User;
}

export async function getCaptchaChallenge(): Promise<string> {
  const { data } = await apiClient.get<{ token: string }>("/users/captcha/challenge");
  return data.token;
}

export interface LoginPayload {
  username: string;
  password: string;
  captcha_token?: string;
  captcha_value: number;
}

export async function login(payload: LoginPayload): Promise<AuthResponse> {
  const { data } = await apiClient.post<AuthResponse>("/users/login", payload);
  return data;
}

export async function adminLogin(payload: { username: string; password: string }): Promise<AuthResponse> {
  const { data } = await apiClient.post<AuthResponse>("/users/admin-login", payload);
  return data;
}

export interface RegisterPayload {
  carx_email: string;
  carx_password: string;
  invite_code?: string;
  captcha_token?: string;
  captcha_value: number;
}

export async function register(payload: RegisterPayload): Promise<AuthResponse> {
  const { data } = await apiClient.post<AuthResponse>("/users/register", payload);
  return data;
}

export async function getMe(): Promise<User> {
  const { data } = await apiClient.get<User>("/users/me");
  return data;
}

export async function changePassword(old_password: string, new_password: string): Promise<void> {
  await apiClient.post("/users/change-password", { old_password, new_password });
}

/* ============================================================
   公共
   ============================================================ */

export async function getPublicDisplayConfig(): Promise<PublicDisplayConfig> {
  const { data } = await apiClient.get<PublicDisplayConfig>("/public/display-config");
  return data;
}

export async function getActiveAnnouncements(): Promise<Announcement[]> {
  const { data } = await apiClient.get<Announcement[]>("/public/announcements/active");
  return data;
}

export async function getPublicProducts(): Promise<Product[]> {
  const { data } = await apiClient.get<Product[]>("/public/products");
  return data;
}

export async function getFinishedProfiles(): Promise<FinishedAccountProfile[]> {
  const { data } = await apiClient.get<FinishedAccountProfile[]>("/public/finished-accounts/profiles");
  return data;
}

/* ============================================================
   会员中心
   ============================================================ */

export async function getMyOrders(): Promise<Order[]> {
  const { data } = await apiClient.get<Order[]>("/orders/my-orders");
  return data;
}

export async function createOrder(product_id: number): Promise<Order> {
  const { data } = await apiClient.post<Order>("/orders", { product_id });
  return data;
}

export async function getMyRedemptions(): Promise<CardCode[]> {
  const { data } = await apiClient.get<CardCode[]>("/cards/my-redemptions");
  return data;
}

export async function redeemCard(code: string): Promise<{ success: boolean; sku_name: string; redeemed_at: string; user: User }> {
  const { data } = await apiClient.post("/cards/redeem", { code });
  return data;
}

export interface MyFinishedAccounts {
  ownerships: FinishedAccountOwnership[];
  claims: WarrantyClaim[];
}

export async function getMyFinishedAccounts(): Promise<MyFinishedAccounts> {
  const { data } = await apiClient.get<MyFinishedAccounts>("/finished-accounts/my");
  return data;
}

export async function claimFinishedAccount(code: string): Promise<FinishedAccountOwnership> {
  const { data } = await apiClient.post<FinishedAccountOwnership>("/finished-accounts/claim", { code });
  return data;
}

export interface VipStatus {
  is_vip: boolean;
  days_remaining: number;
  expires_at: string | null;
  has_backup: boolean;
  last_backup: string | null;
  latest_backup_id: number | null;
  backup_count: number;
  backup_limit: number;
}

export async function getVipStatus(): Promise<VipStatus> {
  const { data } = await apiClient.get<VipStatus>("/vip/status");
  return data;
}

export async function getVipBackups(): Promise<{ items: VipBackup[] }> {
  const { data } = await apiClient.get<{ items: VipBackup[] }>("/vip/backups");
  return data;
}

export async function createBackup(): Promise<VipBackup> {
  const { data } = await apiClient.post<VipBackup>("/vip/backup");
  return data;
}

export async function restoreBackup(backup_id?: number): Promise<{ success: boolean; backup_id: number; message: string }> {
  const { data } = await apiClient.post("/vip/restore", backup_id ? { backup_id } : {});
  return data;
}

export async function banRecover(): Promise<WarrantyClaim> {
  const { data } = await apiClient.post<WarrantyClaim>("/vip/ban-recover");
  return data;
}

export async function getMyWarrantyClaims(): Promise<WarrantyClaim[]> {
  const { data } = await apiClient.get<WarrantyClaim[]>("/warranty/my-claims");
  return data;
}

export async function selfClaim(input: {
  claim_type: "ban_recover" | "warranty";
  order_id?: number;
  note?: string;
  new_carx_email?: string;
  new_carx_password?: string;
}): Promise<WarrantyClaim> {
  const { data } = await apiClient.post<WarrantyClaim>("/warranty/self-claim", input);
  return data;
}

export interface PointsCatalog {
  points_balance: number;
  price_groups: number[];
  categories: string[];
  products: PointsProduct[];
}

export interface PointsCarCatalog {
  points_balance: number;
  categories: { category: string; price: number; count: number }[];
  cars: PointsCar[];
}

export async function getPointsCatalog(): Promise<PointsCatalog> {
  const { data } = await apiClient.get<PointsCatalog>("/single-car-shop/catalog");
  return data;
}

export async function getPointsCarCatalog(): Promise<PointsCarCatalog> {
  const { data } = await apiClient.get<PointsCarCatalog>("/single-car-shop/car-catalog");
  return data;
}

export async function redeemPoints(input: { kind: "product" | "car"; id: number }): Promise<{ success: boolean; remaining_points: number; order: Order }> {
  const { data } = await apiClient.post("/single-car-shop/redeem", input);
  return data;
}

export async function markAnnouncementRead(id: number): Promise<void> {
  await apiClient.post(`/announcements/${id}/read`);
}

/* ============================================================
   代理商经营中心
   ============================================================ */

export interface AgentDashboardStats {
  agent_code: string;
  today_orders_count: number;
  today_net_profit: number;
  month_orders_count: number;
  month_net_profit: number;
  today_pending_settlement: number;
  amount_owed: number;
  max_debt_limit: number;
  remaining_debt_limit: number;
  last_settlement_at: string | null;
  business_start_date: string;
  failed_today: number;
  orders: { selling_price: number; order_id: number; customer_username: string; product_name: string; status: OrderStatus; created_at: string }[];
}

export interface AgentPrice {
  product_id: number;
  product_name: string;
  base_price: number;
  agent_price: number;
  settlement_cost: number;
  income_space: number;
  has_custom_price: boolean;
  allow_white_account_delivery: boolean;
}

export interface AgentCustomer {
  id: number;
  username: string;
  role: Role;
  carx_email: string;
  credit_score: number;
  is_vip: boolean;
  order_count: number;
  total_spent: number;
  remark: string;
  tags: string[];
}

export interface DebtEntry {
  id: number;
  agent_code: string;
  entry_type: string;
  entry_type_label: string;
  amount_delta: number;
  balance_after: number;
  order_id: number | null;
  order_product_name: string;
  customer_username: string;
  created_at: string;
}

export interface Settlement {
  id: number;
  agent_code: string;
  amount_paid: number;
  previous_debt: number;
  new_debt: number;
  notes: string;
  created_at: string;
}

async function get<T>(url: string): Promise<T> {
  const { data } = await apiClient.get<T>(url);
  return data;
}
async function post<T>(url: string, body?: unknown): Promise<T> {
  const { data } = await apiClient.post<T>(url, body);
  return data;
}
async function put<T>(url: string, body?: unknown): Promise<T> {
  const { data } = await apiClient.put<T>(url, body);
  return data;
}
async function del(url: string): Promise<void> {
  await apiClient.delete(url);
}

export const getAgentDashboard = () => get<AgentDashboardStats>("/agent/dashboard-stats");
export const getAgentSalesTrend = () => get<{ date: string; sales: number; orders: number }[]>("/agent/sales-trend");
export const getAgentPermissions = () => get<Record<string, boolean>>("/agent/my-permissions");
export const getAgentPrices = () => get<AgentPrice[]>("/agent/prices");
export const getAgentCustomers = () => get<{ items: AgentCustomer[] }>("/agent/customers");
export const setCustomerRemark = (b: { user_id: number; remark?: string; tags?: string[] }) => post<{ success: boolean }>("/agent/customers/remark", b);
export const searchAgentOrders = (q?: string) => get<{ items: { order_id: number; customer_username: string; customer_carx_email: string; product_name: string; selling_price: number; status: OrderStatus; created_at: string }[] }>(`/agent/orders/search${q ? `?q=${encodeURIComponent(q)}` : ""}`);
export const getAgentDebtLedger = () => get<{ summary: { amount_owed: number; ledger_count: number }; items: DebtEntry[] }>("/agent/debt-ledger");
export const getAgentSettlements = () => get<Settlement[]>("/agent/settlements");
export const getAgentSingleCars = () => get<{ id: string; file: string; price: number; category: string; name: string; model: string; image_url: string | null }[]>("/agent/single-cars-list");
export const getAgentPlatformCars = () => get<{ id: string; name: string; price: number; description: string }[]>("/agent/platform-cars-list");
export const getAgentCardBatches = () => get<{ items: CardBatch[]; total: number }>("/agent/card-batches");
export const agentInject = (b: { product_id: number; customer_carx_email: string; selling_price?: number }) => post<{ success: boolean; order: Order; amount_owed: number }>("/agent/inject", b);
export const agentUnbanRestore = (carx_email: string) => post<{ success: boolean; message: string }>("/agent/carx-unban-restore", { carx_email });
export const agentCreateCardBatch = (b: { batch_name: string; sku_id: number; quantity: number }) => post<{ batch: CardBatch; codes: CardCode[] }>("/agent/card-batches", b);

/* ============================================================
   超级管理
   ============================================================ */

export interface AdminStats {
  totalUsers: number;
  totalAgents: number;
  totalOrders: number;
  totalProducts: number;
  revenue: number;
  ordersByStatus: Record<string, number>;
  activeCards: number;
  redeemedCards: number;
  pendingWarranty: number;
  vipUsers: number;
  totalPointsIssued: number;
  clientLicenses: number;
  trend: { date: string; orders: number; revenue: number }[];
  recentOrders: Order[];
}

export const getAdminStats = () => get<AdminStats>("/admin/overview-stats");

export interface AdminFinance {
  grossRevenue: number;
  totalCost: number;
  netIncome: number;
  totalCompletedOrders: number;
  totalOwed: number;
  byProduct: { label: string; count: number; amount: number }[];
  agentSettlement: { id: number; agent_code: string; username: string; commission_rate: number; amount_owed: number; max_debt_limit: number }[];
}

export const getAdminFinance = () => get<AdminFinance>("/admin/finance-summary");
export const getAdminUsers = () => get<User[]>("/admin/users");
export const createAdminUser = (b: { username: string; email: string; password: string; role?: Role }) => post<User>("/admin/users", b);
export const updateAdminUser = (id: number, b: Partial<User> & { password?: string }) => put<User>(`/admin/users/${id}`, b);
export const deleteAdminUser = (id: number) => del(`/admin/users/${id}`);
export const getAgents = () => get<Agent[]>("/admin/agents");
export const createAgent = (b: Partial<Agent> & { username: string; password?: string }) => post<Agent>("/admin/agents", b);
export const updateAgent = (id: number, b: Partial<Agent> & { password?: string }) => put<Agent>(`/admin/agents/${id}`, b);
export const deleteAgent = (id: number) => del(`/admin/agents/${id}`);
export const getAdminOrders = () => get<Order[]>("/admin/orders");
export const updateAdminOrder = (id: number, b: { status?: OrderStatus; amount?: number }) => put<Order>(`/admin/orders/${id}`, b);
export const deleteAdminOrder = (id: number) => del(`/admin/orders/${id}`);
export const getAdminProducts = () => get<Product[]>("/admin/products");
export const createProduct = (b: Partial<Product> & { name: string; base_price: number }) => post<Product>("/admin/products", b);
export const updateProduct = (id: number, b: Partial<Product>) => put<Product>(`/admin/products/${id}`, b);
export const deleteProduct = (id: number) => del(`/admin/products/${id}`);
export const getCardSkus = () => get<CardSku[]>("/admin/card-skus");
export const createCardSku = (b: Partial<CardSku> & { name: string }) => post<CardSku>("/admin/card-skus", b);
export const updateCardSku = (id: number, b: Partial<CardSku>) => put<CardSku>(`/admin/card-skus/${id}`, b);
export const deleteCardSku = (id: number) => del(`/admin/card-skus/${id}`);
export const getCardBatches = () => get<CardBatch[]>("/admin/card-batches");
export const createCardBatch = (b: { batch_name: string; sku_id: number; product_id?: number; quantity: number; note?: string }) => post<{ batch: CardBatch; codes: CardCode[] }>("/admin/card-batches", b);
export const getCardCodes = () => get<CardCode[]>("/admin/card-codes");
export const updateCardCode = (id: number, b: { status: CardStatus }) => put<CardCode>(`/admin/card-codes/${id}`, b);
export const deleteCardCode = (id: number) => del(`/admin/card-codes/${id}`);
export const getAdminWarranty = () => get<WarrantyClaim[]>("/admin/warranty");
export const updateAdminWarranty = (id: number, b: { status: WarrantyStatus; note?: string }) => put<WarrantyClaim>(`/admin/warranty/${id}`, b);
export const getAdminAnnouncements = () => get<Announcement[]>("/admin/announcements");
export const createAnnouncement = (b: Partial<Announcement> & { title: string }) => post<Announcement>("/admin/announcements", b);
export const updateAnnouncement = (id: number, b: Partial<Announcement>) => put<Announcement>(`/admin/announcements/${id}`, b);
export const deleteAnnouncement = (id: number) => del(`/admin/announcements/${id}`);
export const getAdminPointsProducts = () => get<PointsProduct[]>("/admin/points-products");
export const createPointsProduct = (b: Partial<PointsProduct> & { name: string; price: number }) => post<PointsProduct>("/admin/points-products", b);
export const updatePointsProduct = (id: number, b: Partial<PointsProduct>) => put<PointsProduct>(`/admin/points-products/${id}`, b);
export const deletePointsProduct = (id: number) => del(`/admin/points-products/${id}`);
export const getAdminPointsCars = () => get<PointsCar[]>("/admin/points-cars");
export const createPointsCar = (b: Partial<PointsCar> & { car_id: string; name: string; price: number }) => post<PointsCar>("/admin/points-cars", b);
export const updatePointsCar = (id: number, b: Partial<PointsCar>) => put<PointsCar>(`/admin/points-cars/${id}`, b);
export const deletePointsCar = (id: number) => del(`/admin/points-cars/${id}`);
export const getAdminFinishedProfiles = () => get<FinishedAccountProfile[]>("/admin/finished-profiles");
export const createFinishedProfile = (b: Partial<FinishedAccountProfile> & { code: string; name: string }) => post<FinishedAccountProfile>("/admin/finished-profiles", b);
export const deleteFinishedProfile = (id: number) => del(`/admin/finished-profiles/${id}`);
export const getClientLicenseCodes = () => get<ClientLicenseCode[]>("/admin/client-license/codes");
export const getClientLicenseOverview = () => get<{ total: number; version_available: number; version_activated: number; feature_available: number; feature_activated: number }>("/admin/client-license/overview");
export const generateClientLicense = (b: { kind: "version" | "feature"; days?: number; quantity?: number }) => post<{ codes: ClientLicenseCode[] }>("/admin/client-license/codes/generate", b);
export const updateClientLicense = (id: number, b: { status: ClientLicenseCode["status"] }) => put<ClientLicenseCode>(`/admin/client-license/codes/${id}`, b);
export const getAdminConfig = () => get<AdminConfig>("/admin/config");

export interface AdminConfigUpdate {
  display?: Partial<AdminConfig["display"]>;
  points_shop_enabled?: boolean;
  cards_enabled?: boolean;
  agent_application_open?: boolean;
}
export const updateAdminConfig = (b: AdminConfigUpdate) => put<AdminConfig>("/admin/config", b);
