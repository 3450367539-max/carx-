import { format, parseISO } from "date-fns";

/** Normalize "YYYY-MM-DD HH:mm:ss" (space) into ISO for date-fns. */
function toISO(value: string): string {
  return value.includes("T") ? value : value.replace(" ", "T");
}

export function formatDate(value?: string | null): string {
  if (!value) return "—";
  try {
    return format(parseISO(toISO(value)), "yyyy-MM-dd");
  } catch {
    return value;
  }
}

export function formatDateTime(value?: string | null): string {
  if (!value) return "—";
  try {
    return format(parseISO(toISO(value)), "yyyy-MM-dd HH:mm");
  } catch {
    return value;
  }
}

export function formatCurrency(value?: number | null): string {
  if (value === undefined || value === null) return "—";
  return `¥ ${value.toLocaleString("zh-CN", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}
