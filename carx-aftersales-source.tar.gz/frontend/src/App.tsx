import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Navigate, Route } from "react-router-dom";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AnimatedRoutes } from "@/components/AnimatedRoutes";
import { PageTransition } from "@/components/PageTransition";
import { AuthProvider, useAuth } from "@/lib/auth";
import { RequireAuth } from "@/components/RequireAuth";
import { MemberLayout } from "@/components/layout/MemberLayout";
import { AgentLayout } from "@/components/layout/AgentLayout";

import Index from "./pages/Index";
import Login from "./pages/Login";
import Register from "./pages/Register";
import NotFound from "./pages/NotFound";

// 会员中心
import MemberHome from "./pages/member/MemberHome";
import MemberAccount from "./pages/member/MemberAccount";
import MemberGame from "./pages/member/MemberGame";
import MemberBackup from "./pages/member/MemberBackup";
import MemberRedeem from "./pages/member/MemberRedeem";
import MemberOrders from "./pages/member/MemberOrders";
import MemberPoints from "./pages/member/MemberPoints";
import MemberSecurity from "./pages/member/MemberSecurity";

// 管理中心（代理/管理）
import AdminOverview from "./pages/agent/AdminOverview";
import AdminUsers from "./pages/agent/AdminUsers";
import AdminAgents from "./pages/agent/AdminAgents";
import AdminOrders from "./pages/agent/AdminOrders";
import AdminProducts from "./pages/agent/AdminProducts";
import AdminCards from "./pages/agent/AdminCards";
import AdminPoints from "./pages/agent/AdminPoints";
import AdminWarranty from "./pages/agent/AdminWarranty";
import AdminLicenses from "./pages/agent/AdminLicenses";
import AdminDelivery from "./pages/agent/AdminDelivery";
import AdminRecords from "./pages/agent/AdminRecords";
import AdminAuditLogs from "./pages/agent/AdminAuditLogs";
import AdminAnnouncements from "./pages/agent/AdminAnnouncements";
import AdminSettings from "./pages/agent/AdminSettings";
import AgentOverview from "./pages/agent/AgentOverview";
import AgentBizHome from "./pages/agent/AgentBizHome";
import AgentDelivery from "./pages/agent/AgentDelivery";
import AgentCustomers from "./pages/agent/AgentCustomers";
import AgentCards from "./pages/agent/AgentCards";
import AgentPrices from "./pages/agent/AgentPrices";
import AgentSingleCar from "./pages/agent/AgentSingleCar";
import AgentUnban from "./pages/agent/AgentUnban";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 60 * 1000,
      gcTime: 5 * 60 * 1000,
      retry: 1,
      refetchOnWindowFocus: false,
      refetchOnReconnect: false,
    },
    mutations: { retry: 1 },
  },
});

/** 管理中心首页：管理员看数据总览，代理商落到经营概览 */
function AdminIndex() {
  const { user } = useAuth();
  if (user?.role !== "admin") return <Navigate to="/admin/biz" replace />;
  return (
    <PageTransition transition="slide-up">
      <AdminOverview />
    </PageTransition>
  );
}

/** 管理员专属页面：代理商访问时引导回经营概览 */
function AdminOnly({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  if (user?.role !== "admin") return <Navigate to="/admin/biz" replace />;
  return <>{children}</>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <BrowserRouter>
            <AnimatedRoutes>
              <Route path="/" data-genie-title="首页" data-genie-key="Home" element={<PageTransition transition="fade"><Index /></PageTransition>} />
              <Route path="/login" data-genie-title="登录" data-genie-key="Login" element={<PageTransition transition="fade"><Login /></PageTransition>} />
              <Route path="/register" data-genie-title="注册" data-genie-key="Register" element={<PageTransition transition="fade"><Register /></PageTransition>} />

              {/* 会员中心（浅色蓝主题） */}
              <Route path="/console" element={<RequireAuth roles={["user", "agent", "admin"]}><MemberLayout /></RequireAuth>}>
                <Route index data-genie-title="首页概览" data-genie-key="MemberHome" element={<PageTransition transition="slide-up"><MemberHome /></PageTransition>} />
                <Route path="account" data-genie-title="账号信息" data-genie-key="MemberAccount" element={<PageTransition transition="slide-up"><MemberAccount /></PageTransition>} />
                <Route path="game" data-genie-title="游戏数据" data-genie-key="MemberGame" element={<PageTransition transition="slide-up"><MemberGame /></PageTransition>} />
                <Route path="backup" data-genie-title="数据备份" data-genie-key="MemberBackup" element={<PageTransition transition="slide-up"><MemberBackup /></PageTransition>} />
                <Route path="redeem" data-genie-title="卡密兑换" data-genie-key="MemberRedeem" element={<PageTransition transition="slide-up"><MemberRedeem /></PageTransition>} />
                <Route path="orders" data-genie-title="购买记录" data-genie-key="MemberOrders" element={<PageTransition transition="slide-up"><MemberOrders /></PageTransition>} />
                <Route path="points" data-genie-title="积分商城" data-genie-key="MemberPoints" element={<PageTransition transition="slide-up"><MemberPoints /></PageTransition>} />
                <Route path="security" data-genie-title="安全设置" data-genie-key="MemberSecurity" element={<PageTransition transition="slide-up"><MemberSecurity /></PageTransition>} />
              </Route>

              {/* 管理中心（深色主题 · 代理/管理） */}
              <Route path="/admin" element={<RequireAuth roles={["agent", "admin"]}><AgentLayout /></RequireAuth>}>
                {/* 核心管理（管理员专属） */}
                <Route index data-genie-title="数据总览" data-genie-key="AdminOverview" element={<AdminIndex />} />
                <Route path="users" data-genie-title="用户管理" data-genie-key="AdminUsers" element={<AdminOnly><PageTransition transition="slide-up"><AdminUsers /></PageTransition></AdminOnly>} />
                <Route path="agents" data-genie-title="代理管理" data-genie-key="AdminAgents" element={<AdminOnly><PageTransition transition="slide-up"><AdminAgents /></PageTransition></AdminOnly>} />
                <Route path="orders" data-genie-title="订单管理" data-genie-key="AdminOrders" element={<AdminOnly><PageTransition transition="slide-up"><AdminOrders /></PageTransition></AdminOnly>} />
                <Route path="products" data-genie-title="商品管理" data-genie-key="AdminProducts" element={<AdminOnly><PageTransition transition="slide-up"><AdminProducts /></PageTransition></AdminOnly>} />
                <Route path="cards" data-genie-title="卡密管理" data-genie-key="AdminCards" element={<AdminOnly><PageTransition transition="slide-up"><AdminCards /></PageTransition></AdminOnly>} />
                <Route path="points" data-genie-title="积分商城" data-genie-key="AdminPoints" element={<AdminOnly><PageTransition transition="slide-up"><AdminPoints /></PageTransition></AdminOnly>} />
                <Route path="warranty" data-genie-title="售后理赔" data-genie-key="AdminWarranty" element={<AdminOnly><PageTransition transition="slide-up"><AdminWarranty /></PageTransition></AdminOnly>} />
                <Route path="licenses" data-genie-title="客户端授权" data-genie-key="AdminLicenses" element={<AdminOnly><PageTransition transition="slide-up"><AdminLicenses /></PageTransition></AdminOnly>} />
                {/* 交付配置 */}
                <Route path="delivery" data-genie-title="交付中心" data-genie-key="AdminDelivery" element={<AdminOnly><PageTransition transition="slide-up"><AdminDelivery /></PageTransition></AdminOnly>} />
                {/* 记录与配置 */}
                <Route path="archives" data-genie-title="历史归档" data-genie-key="AdminRecords" element={<AdminOnly><PageTransition transition="slide-up"><AdminRecords /></PageTransition></AdminOnly>} />
                <Route path="audit-logs" data-genie-title="操作日志" data-genie-key="AdminAuditLogs" element={<AdminOnly><PageTransition transition="slide-up"><AdminAuditLogs /></PageTransition></AdminOnly>} />
                <Route path="announcements" data-genie-title="消息通知" data-genie-key="AdminAnnouncements" element={<AdminOnly><PageTransition transition="slide-up"><AdminAnnouncements /></PageTransition></AdminOnly>} />
                <Route path="settings" data-genie-title="系统配置" data-genie-key="AdminSettings" element={<AdminOnly><PageTransition transition="slide-up"><AdminSettings /></PageTransition></AdminOnly>} />
                {/* 代理经营 */}
                <Route path="biz" data-genie-title="经营概览" data-genie-key="AgentBizHome" element={<PageTransition transition="slide-up"><AgentBizHome /></PageTransition>} />
                <Route path="biz/delivery" data-genie-title="发货操作" data-genie-key="AgentDelivery" element={<PageTransition transition="slide-up"><AgentDelivery /></PageTransition>} />
                <Route path="biz/customers" data-genie-title="客户管理" data-genie-key="AgentCustomers" element={<PageTransition transition="slide-up"><AgentCustomers /></PageTransition>} />
                <Route path="biz/cards" data-genie-title="代销卡密" data-genie-key="AgentCards" element={<PageTransition transition="slide-up"><AgentCards /></PageTransition>} />
                <Route path="biz/prices" data-genie-title="商品价格表" data-genie-key="AgentPrices" element={<PageTransition transition="slide-up"><AgentPrices /></PageTransition>} />
                <Route path="biz/single-car" data-genie-title="单车零售专区" data-genie-key="AgentSingleCar" element={<PageTransition transition="slide-up"><AgentSingleCar /></PageTransition>} />
                {/* 运营操作 */}
                <Route path="biz/unban" data-genie-title="解封账号" data-genie-key="AgentUnban" element={<PageTransition transition="slide-up"><AgentUnban /></PageTransition>} />
                {/* 代理数据总览（备用入口） */}
                <Route path="agent" data-genie-title="代理数据" data-genie-key="AgentOverview" element={<PageTransition transition="slide-up"><AgentOverview /></PageTransition>} />
              </Route>

              <Route path="*" data-genie-key="NotFound" data-genie-title="Not Found" element={<PageTransition transition="fade"><NotFound /></PageTransition>} />
            </AnimatedRoutes>
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
